<?php
/**
 * ============================================================
 *  PENYAJI FILE UPLOAD (foto absen, foto profil, lampiran izin)
 * ============================================================
 * Sebelumnya file di folder uploads/ bisa dibuka siapa saja yang tahu/menebak
 * URL-nya — padahal isinya foto wajah mahasiswa dan surat sakit. Sekarang folder
 * uploads/ ditutup lewat .htaccess, dan SEMUA gambar/lampiran diakses lewat file
 * ini supaya hak aksesnya diperiksa dulu:
 *
 * - mahasiswa  : hanya file miliknya sendiri (foto absennya, lampiran izinnya, foto profilnya),
 * - pembimbing : file mahasiswa bimbingannya (+ foto profil dirinya sendiri),
 * - admin      : semua file.
 *
 * Pemakaian: <img src="<?= urlFileUpload($namaFile) ?>">
 * (lihat urlFileUpload() di includes/functions.php)
 */

require_once __DIR__ . '/includes/auth.php';
requireLogin();

$user = currentUser();
$berkas = $_GET['f'] ?? '';

// ---- Validasi bentuk nama file: hanya "subfolder/namafile.ext" yang dikenal ----
// Blok "..", garis miring ganda, dan path absolut supaya tidak bisa keluar dari folder uploads.
if (!preg_match('#^(absen|izin|profil)/[A-Za-z0-9._-]+$#', $berkas) || strpos($berkas, '..') !== false) {
    http_response_code(400);
    exit('Nama file tidak valid.');
}

$pdo = getDB();

/**
 * Cari siapa pemilik file ini. Mengembalikan id mahasiswa/pengguna pemiliknya,
 * atau null kalau file tidak terdaftar di database (mis. file sisa yang tidak dipakai).
 */
function pemilikFile(PDO $pdo, string $berkas): ?int {
    foreach ([
        "SELECT user_id FROM absensi WHERE foto = ? LIMIT 1",
        "SELECT user_id FROM izin WHERE file_lampiran = ? LIMIT 1",
        "SELECT id FROM users WHERE foto_profil = ? LIMIT 1",
    ] as $sql) {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$berkas]);
        $id = $stmt->fetchColumn();
        if ($id) return (int) $id;
    }
    return null;
}

$pemilikId = pemilikFile($pdo, $berkas);

if ($pemilikId === null) {
    // File tidak tercatat di database → jangan disajikan sama sekali.
    http_response_code(404);
    exit('File tidak ditemukan.');
}

// ---- Pemeriksaan hak akses ----
$boleh = false;
if ($pemilikId === (int) $user['id']) {
    $boleh = true;                              // file milik sendiri (semua role)
} elseif (isAdmin()) {
    $boleh = true;                              // admin: semua file
} elseif (isPembimbing()) {
    $boleh = bolehAksesMahasiswa($pemilikId);   // pembimbing: hanya mahasiswa bimbingannya
}

if (!$boleh) {
    http_response_code(403);
    exit('Kamu tidak berhak membuka file ini.');
}

// ---- Kirim filenya ----
$path = __DIR__ . '/uploads/' . $berkas;
if (!is_file($path)) {
    http_response_code(404);
    exit('File tidak ditemukan.');
}

$tipe = [
    'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
    'gif' => 'image/gif', 'webp' => 'image/webp', 'pdf' => 'application/pdf',
][strtolower(pathinfo($berkas, PATHINFO_EXTENSION))] ?? 'application/octet-stream';

header('Content-Type: ' . $tipe);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: inline; filename="' . basename($berkas) . '"');
// Cache di browser saja (private), jangan di proxy bersama — isinya data pribadi.
header('Cache-Control: private, max-age=600');
header('X-Content-Type-Options: nosniff');
readfile($path);
