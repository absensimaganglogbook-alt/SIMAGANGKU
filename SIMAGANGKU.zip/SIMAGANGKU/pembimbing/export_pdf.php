<?php
/**
 * Panel pembimbing → halaman export_pdf.php.
 * Logika & tampilannya dipakai bersama dengan admin (lihat admin/export_pdf.php), yang
 * sudah otomatis membatasi data hanya ke mahasiswa bimbingan pembimbing yang login.
 * File ini cuma pembungkus supaya URL pembimbing tetap /pembimbing/...
 */
require __DIR__ . '/../admin/export_pdf.php';
