<?php
/**
 * Panel pembimbing → menu Sertifikat.
 * Logika & tampilannya dipakai bersama dengan admin (lihat admin/sertifikat.php),
 * yang sudah otomatis membatasi data ke mahasiswa bimbingan pembimbing yang login.
 */
require __DIR__ . '/../admin/sertifikat.php';
