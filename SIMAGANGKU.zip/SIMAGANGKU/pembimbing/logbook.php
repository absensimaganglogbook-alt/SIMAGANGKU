<?php
/**
 * Panel pembimbing → halaman logbook.php.
 * Logika & tampilannya dipakai bersama dengan admin (lihat admin/logbook.php), yang
 * sudah otomatis membatasi data ke mahasiswa bimbingan di cabang pembimbing yang login.
 * File ini cuma pembungkus supaya URL pembimbing tetap /pembimbing/...
 */
require __DIR__ . '/../admin/logbook.php';
