<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('pembimbing');
redirect('/pembimbing/dashboard.php');
