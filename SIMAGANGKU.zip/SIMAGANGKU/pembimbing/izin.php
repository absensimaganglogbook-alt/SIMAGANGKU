<?php
/**
 * Panel pembimbing → halaman izin.php.
 * Logika & tampilannya dipakai bersama dengan admin (lihat admin/izin.php), yang
 * sudah otomatis membatasi data hanya ke mahasiswa bimbingan pembimbing yang login.
 * File ini cuma pembungkus supaya URL pembimbing tetap /pembimbing/...
 */
require __DIR__ . '/../admin/izin.php';
