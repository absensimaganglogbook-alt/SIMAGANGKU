<?php
/**
 * Panel pembimbing → halaman absen_manual.php.
 * Logika & tampilannya dipakai bersama dengan admin (lihat admin/absen_manual.php), yang
 * sudah otomatis membatasi data hanya ke mahasiswa bimbingan pembimbing yang login.
 * File ini cuma pembungkus supaya URL pembimbing tetap /pembimbing/...
 */
require __DIR__ . '/../admin/absen_manual.php';
