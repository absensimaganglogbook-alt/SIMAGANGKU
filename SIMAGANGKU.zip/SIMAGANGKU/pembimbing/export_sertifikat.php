<?php
/**
 * Panel pembimbing → export rekap sertifikat.
 * Logika & tampilannya dipakai bersama dengan admin (lihat admin/export_sertifikat.php),
 * yang sudah otomatis membatasi data ke mahasiswa bimbingan pembimbing yang login.
 */
require __DIR__ . '/../admin/export_sertifikat.php';
