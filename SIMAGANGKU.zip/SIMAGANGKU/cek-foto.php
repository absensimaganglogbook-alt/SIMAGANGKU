<?php
/**
 * ============================================================
 *  PEMERIKSA FOTO ABSEN
 * ============================================================
 * Membandingkan daftar foto yang tercatat di database dengan berkas yang
 * benar-benar ADA di folder uploads/absen. Dipakai untuk memastikan apakah
 * foto yang tidak tampil di laporan memang sudah hilang dari server, atau
 * sebenarnya masih ada tetapi gagal dimuat browser.
 *
 * Hanya bisa dibuka oleh admin yang sudah login. Tidak mengubah apa pun.
 * HAPUS berkas ini setelah selesai dipakai.
 */
require_once __DIR__ . '/includes/auth.php';
requireLogin('admin');

$pdo = getDB();
$baris = $pdo->query("
    SELECT a.id, a.tanggal, a.jenis, a.foto, u.nama
    FROM absensi a JOIN users u ON u.id = a.user_id
    WHERE a.foto IS NOT NULL
    ORDER BY a.tanggal DESC, a.id DESC
")->fetchAll();

$ada = 0; $hilang = 0; $totalByte = 0; $daftarHilang = [];
foreach ($baris as $b) {
    $path = __DIR__ . '/uploads/' . $b['foto'];
    if (is_file($path)) { $ada++; $totalByte += filesize($path); }
    else { $hilang++; $daftarHilang[] = $b; }
}

// Berkas yang ADA di folder tapi tidak tercatat di database (sisa/yatim).
$diDisk = glob(__DIR__ . '/uploads/absen/*');
$tercatat = array_column($baris, 'foto');
$yatim = [];
foreach ($diDisk ?: [] as $f) {
    if (basename($f) === '.htaccess' || basename($f) === '.gitkeep') continue;
    if (!in_array('absen/' . basename($f), $tercatat, true)) $yatim[] = basename($f);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cek Foto Absen</title>
<style>
  body { font-family: Arial, sans-serif; max-width: 820px; margin: 28px auto; padding: 0 16px; color: #1b2433; line-height: 1.55; }
  table { width: 100%; border-collapse: collapse; margin: 14px 0; }
  th, td { padding: 7px 9px; border-bottom: 1px solid #e3e7ee; text-align: left; font-size: 14px; }
  .kotak { padding: 14px 16px; border-radius: 8px; margin: 14px 0; }
  .hijau { background: #e6f6ee; } .merah { background: #fdecec; } .kuning { background: #fff6e0; }
  code { background: #f1f3f7; padding: 1px 6px; border-radius: 4px; font-size: 13px; }
</style>
</head>
<body>
<h2>Cek Foto Absen</h2>

<?php if ($hilang === 0): ?>
  <div class="kotak hijau">
    <b>✓ Semua foto masih ada di server.</b><br>
    <?= $ada ?> foto tercatat di database dan semuanya ditemukan di folder
    <code>uploads/absen</code> (total <?= round($totalByte / 1048576, 1) ?> MB).<br><br>
    Kalau ada foto yang tidak tampil di laporan, berarti berkasnya <b>gagal dimuat browser</b>,
    bukan hilang. Penyebab umumnya: terlalu banyak gambar dimuat sekaligus pada hosting berbagi.
  </div>
<?php else: ?>
  <div class="kotak merah">
    <b><?= $hilang ?> foto tercatat di database tapi berkasnya TIDAK ADA di server.</b><br>
    Foto yang masih utuh: <?= $ada ?> (total <?= round($totalByte / 1048576, 1) ?> MB).<br>
    Berkas yang hilang tidak bisa dikembalikan kecuali Anda punya cadangan folder <code>uploads</code>.
  </div>
  <table>
    <tr><th>Tanggal</th><th>Nama</th><th>Jenis</th><th>Nama berkas</th></tr>
    <?php foreach (array_slice($daftarHilang, 0, 100) as $h): ?>
      <tr>
        <td><?= e(formatTanggalID($h['tanggal'])) ?></td>
        <td><?= e($h['nama']) ?></td>
        <td><?= e($h['jenis']) ?></td>
        <td><code><?= e($h['foto']) ?></code></td>
      </tr>
    <?php endforeach; ?>
  </table>
  <?php if (count($daftarHilang) > 100): ?>
    <p>…dan <?= count($daftarHilang) - 100 ?> lainnya.</p>
  <?php endif; ?>
<?php endif; ?>

<?php if ($yatim): ?>
  <div class="kotak kuning">
    <b><?= count($yatim) ?> berkas foto ada di folder tapi tidak tercatat di database.</b>
    Biasanya sisa dari data absen yang sudah dihapus. Aman dibiarkan, atau dihapus
    kalau ingin menghemat kuota.
  </div>
<?php endif; ?>

<p style="font-size:13px;color:#5b6778;">
  Halaman ini hanya membaca, tidak mengubah apa pun. <b>Hapus berkas <code>cek-foto.php</code>
  setelah selesai dipakai.</b>
</p>
</body>
</html>
