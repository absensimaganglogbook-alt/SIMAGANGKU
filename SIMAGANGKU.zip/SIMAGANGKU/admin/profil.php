<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin(['admin', 'pembimbing']);
$user = currentUser();
$pdo = getDB();
$errorPass = '';
$successPass = '';

$stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$user['id']]);
$data = $stmt->fetch();

$jumlahBimbingan = $jumlahBimbinganAktif = 0;
if ($data['role'] === 'pembimbing') {
    $stmtBimbingan = $pdo->prepare("SELECT COUNT(*) total, SUM(status='aktif') aktif FROM users WHERE role='mahasiswa' AND pembimbing_id = ?");
    $stmtBimbingan->execute([$user['id']]);
    $rowBimbingan = $stmtBimbingan->fetch();
    $jumlahBimbingan = (int) $rowBimbingan['total'];
    $jumlahBimbinganAktif = (int) $rowBimbingan['aktif'];
}

// ---- Ganti password ----
// Beda dengan mahasiswa: admin & pembimbing BOLEH ganti password sendiri berkali-kali kapan saja
// (bukan cuma sekali), selama tahu password lama-nya. Tidak ada penguncian menu.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ganti_password'])) {
    verifikasiCsrf();
    $lamaPass = $_POST['password_lama'] ?? '';
    $baruPass = $_POST['password_baru'] ?? '';
    $konfirmasi = $_POST['password_konfirmasi'] ?? '';

    if (!password_verify($lamaPass, $data['password'])) {
        $errorPass = 'Kata sandi lama salah.';
    } elseif (($pesanKekuatan = validasiKekuatanPassword($baruPass)) !== null) {
        $errorPass = $pesanKekuatan;
    } elseif ($baruPass !== $konfirmasi) {
        $errorPass = 'Konfirmasi kata sandi baru tidak cocok.';
    } else {
        $hash = password_hash($baruPass, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password=?, harus_ganti_password=0 WHERE id=?");
        $stmt->execute([$hash, $user['id']]);
        $data['harus_ganti_password'] = 0;
        $_SESSION['harus_ganti_password'] = 0;
        // Ganti sesi dengan id baru (praktik umum setelah ganti kata sandi), lalu langsung
        // ke dashboard — pemberitahuan berhasilnya ditampilkan di sana.
        session_regenerate_id(true);
        redirect(berandaRole() . '?sandi_diganti=1');
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Profil — <?= e(labelRole($data['role'])) ?></title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-2">Data akun</p>
      <div class="d-flex justify-content-between small border-bottom py-2"><span class="text-muted">Nama</span><span class="fw-medium"><?= e($data['nama']) ?></span></div>
      <div class="d-flex justify-content-between small border-bottom py-2"><span class="text-muted">Username</span><span class="fw-medium"><?= e($data['identifier']) ?></span></div>
      <div class="d-flex justify-content-between small py-2"><span class="text-muted">Role</span><span class="fw-medium"><?= e(labelRole($data['role'])) ?></span></div>
      <?php if ($data['role'] === 'pembimbing'): ?>
        <div class="d-flex justify-content-between small border-top py-2"><span class="text-muted">Divisi/Bagian</span><span class="fw-medium"><?= e(labelDivisi($data['divisi_id'])) ?></span></div>
        <div class="d-flex justify-content-between small border-top py-2"><span class="text-muted">Cabang</span><span class="fw-medium"><?php $cbPembimbing = $data['cabang_id'] ? ambilCabang($data['cabang_id']) : null; echo e($cbPembimbing['nama_cabang'] ?? 'Belum diatur'); ?></span></div>
        <div class="d-flex justify-content-between small border-top py-2"><span class="text-muted">No. HP</span><span class="fw-medium"><?= e($data['no_hp'] ?: '-') ?></span></div>
        <div class="d-flex justify-content-between small border-top py-2"><span class="text-muted">Mahasiswa bimbingan</span><span class="fw-medium"><?= (int) $jumlahBimbingan ?> orang (<?= (int) $jumlahBimbinganAktif ?> aktif)</span></div>
        <p class="text-muted small mt-2 mb-0">Untuk ganti nama, username, no. HP, divisi, cabang, atau daftar mahasiswa bimbingan, hubungi admin.</p>
      <?php else: ?>
        <p class="text-muted small mt-2 mb-0">Untuk ganti nama/username, minta admin lain mengaturnya lewat menu Kelola Admin.</p>
      <?php endif; ?>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Keamanan</p>
      <h2 class="h6 fw-bold mb-2">Ganti Kata Sandi</h2>

      <?php if (!empty($data['harus_ganti_password'])): ?>
        <?php if (isset($_GET['wajib_ganti'])): ?>
          <div class="alert alert-warning d-flex align-items-start gap-2">
            <span class="ico">🔐</span>
            <div><b>Kamu wajib ganti kata sandi dulu</b><span>Kamu masih pakai kata sandi awal/hasil reset. Ganti dulu sebelum bisa membuka menu lain.</span></div>
          </div>
        <?php endif; ?>
      <?php endif; ?>

      <form method="POST" class="mt-2">
        <?= csrfField() ?>
        <div class="mb-3"><label class="form-label">Kata sandi lama</label><input type="password" name="password_lama" required class="form-control"></div>
        <div class="mb-3">
          <label class="form-label">Kata sandi baru</label>
          <input type="password" name="password_baru" id="passwordBaru" required class="form-control">
          <div id="kekuatanBar" class="mt-2" style="height:4px;border-radius:2px;background:#e9ecef;overflow:hidden;">
            <div id="kekuatanFill" style="height:100%;width:0%;background:#dc3545;transition:width .2s,background .2s;"></div>
          </div>
          <p class="text-muted small mt-1" id="kekuatanLabel"><?= e(syaratPasswordTeks()) ?></p>
        </div>
        <div class="mb-3"><label class="form-label">Konfirmasi kata sandi baru</label><input type="password" name="password_konfirmasi" required class="form-control"></div>
        <?php if ($errorPass): ?><p class="alert alert-danger py-2 small"><?= e($errorPass) ?></p><?php endif; ?>
        <?php if ($successPass): ?><p class="alert alert-success py-2 small"><?= e($successPass) ?></p><?php endif; ?>
        <button type="submit" name="ganti_password" value="1" class="btn btn-primary">Simpan</button>
      </form>
      <p class="text-muted small mt-2 mb-0">Kata sandi bisa diganti kapan saja selama tahu kata sandi lama.</p>

      <script>
      (function () {
        var input = document.getElementById('passwordBaru');
        var fill = document.getElementById('kekuatanFill');
        var label = document.getElementById('kekuatanLabel');
        var SYARAT_PASSWORD = <?= jsonUntukScript(syaratPasswordTeks()) ?>;
        if (!input) return;

        input.addEventListener('input', function () {
          var v = input.value;
          // Syarat wajib (sama dengan validasi di server): minimal 8 karakter,
          // huruf besar, huruf kecil, angka, dan simbol.
          var kurang = [];
          if (v.length < 8) kurang.push('minimal 8 karakter');
          if (!/[A-Z]/.test(v)) kurang.push('huruf besar');
          if (!/[a-z]/.test(v)) kurang.push('huruf kecil');
          if (!/[0-9]/.test(v)) kurang.push('angka');
          if (!/[^A-Za-z0-9]/.test(v)) kurang.push('simbol');
          var skor = 5 - kurang.length;
          if (!kurang.length && v.length >= 12) skor = 6;

          var persen = Math.min(100, (skor / 6) * 100);
          var warna = '#dc3545', teks = 'Lemah';
          if (v.length === 0) {
            persen = 0; teks = '';
          } else if (kurang.length) {
            warna = '#dc3545'; teks = 'Belum memenuhi syarat — kurang: ' + kurang.join(', ');
          } else if (v.length < 12) {
            warna = '#ffc107'; teks = 'Sudah memenuhi syarat — lebih panjang lebih aman';
          } else {
            warna = '#198754'; teks = 'Kuat';
          }
          fill.style.width = persen + '%';
          fill.style.background = warna;
          label.textContent = teks || SYARAT_PASSWORD;
        });
      })();
      </script>
      </div>
    </div>

    <?php if (isAdmin()): // pembimbing tidak punya akses ke halaman Pengaturan, jadi tombolnya tidak ditampilkan ?>
      <a href="pengaturan.php" class="btn btn-outline-secondary mb-3">← Kembali ke Pengaturan</a>
    <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
