<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/laporan_data.php';
requireLogin(['admin', 'pembimbing']);

$dariTanggal = $_GET['dari'] ?? date('Y-m-01');
$sampaiTanggal = $_GET['sampai'] ?? date('Y-m-d');
$mahasiswaId = isset($_GET['mahasiswa']) && $_GET['mahasiswa'] !== '' ? (int)$_GET['mahasiswa'] : null;
// Pembimbing hanya boleh melihat mahasiswa bimbingannya. Kalau id mahasiswa di URL
// bukan wewenangnya, abaikan filter itu (data tetap dibatasi ke bimbingannya sendiri).
if ($mahasiswaId && !bolehAksesMahasiswa($mahasiswaId)) {
    $mahasiswaId = null;
}
$kategoriPilihan = kategoriDariInput($_GET['kategori'] ?? '');
$cabangPilihan = isset($_GET['cabang']) && $_GET['cabang'] !== '' ? (int)$_GET['cabang'] : '';
if ($cabangPilihan && !ambilCabang($cabangPilihan)) {
    $cabangPilihan = '';
}
// Khusus pembimbing: cabang tidak dipilih manual — otomatis memakai cabang pada akunnya
// (sama seperti halaman Absen Manual). -1 dipakai kalau cabang akunnya belum diatur admin,
// supaya tidak ada data yang cocok sampai admin mengaturnya.
$cabangPembimbing = cabangOtomatisPembimbing();
if (isPembimbing()) {
    $cabangPilihan = $cabangPembimbing ? (int) $cabangPembimbing['id'] : -1;
}

$items = ambilDataLaporan($dariTanggal, $sampaiTanggal, $mahasiswaId, $kategoriPilihan ?: null, $cabangPilihan ?: null, idPembimbingScope());
$pengaturan = ambilPengaturan();

$namaMahasiswaTerpilih = null;
// Nama untuk kolom tanda tangan. Kalau laporan disaring per 1 mahasiswa, namanya
// langsung dicetak; kalau laporan gabungan, dibiarkan bergaris kosong untuk diisi manual.
$namaMhsTtd = '.....................................';
$namaPembimbingTtd = '.....................................';
if ($mahasiswaId) {
    $stmt = getDB()->prepare("SELECT u.nama, p.nama AS nama_pembimbing
                              FROM users u LEFT JOIN users p ON p.id = u.pembimbing_id
                              WHERE u.id = ?");
    $stmt->execute([$mahasiswaId]);
    $dataTtd = $stmt->fetch();
    $namaMahasiswaTerpilih = $dataTtd['nama'] ?? null;
    if ($dataTtd) {
        $namaMhsTtd = $dataTtd['nama'];
        $namaPembimbingTtd = $dataTtd['nama_pembimbing'] ?: $namaPembimbingTtd;
    }
} elseif (isPembimbing()) {
    // Laporan gabungan yang dicetak pembimbing: namanya sendiri yang dicantumkan.
    $namaPembimbingTtd = currentUser()['nama'];
}
$namaKategoriTerpilih = $kategoriPilihan ? labelKategori($kategoriPilihan) : null;
$namaCabangTerpilih = null;
if ($cabangPilihan) {
    $cabangObj = ambilCabang($cabangPilihan);
    $namaCabangTerpilih = $cabangObj ? $cabangObj['nama_cabang'] : null;
}
$judulTambahan = $namaMahasiswaTerpilih
    ? '— ' . e($namaMahasiswaTerpilih)
    : (($namaKategoriTerpilih || $namaCabangTerpilih)
        ? '— ' . trim(e($namaKategoriTerpilih) . ' ' . ($namaKategoriTerpilih && $namaCabangTerpilih ? '· ' : '') . e($namaCabangTerpilih))
        : (isPembimbing() ? '— Mahasiswa Bimbingan ' . e(currentUser()['nama']) : 'Mahasiswa Magang'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Laporan Absensi</title>
<style>
  body{font-family: Arial, sans-serif; color:#111; padding:24px; font-size:12px;}
  h1{font-size:16px;margin:0 0 2px;}
  h2{font-size:12px;margin:0 0 16px;color:#555;font-weight:normal;}
  table{width:100%;border-collapse:collapse;margin-top:10px;}
  th,td{border:1px solid #ccc;padding:6px 8px;text-align:left;font-size:11px;}
  th{background:#f0f0f0;}
  img.foto{width:32px;height:32px;object-fit:cover;border-radius:4px;}
  .foto-hilang{display:inline-block;font-size:8px;line-height:1.1;color:#b00;text-align:center;}
  .no-print{margin-bottom:16px;}
  .ttd { margin-top:36px; width:100%; border:none; }
  .ttd td { border:none; text-align:center; width:50%; font-size:12px; vertical-align:top; }
  .tgl-ttd { display:block; margin-bottom:2px; }
  .garis-ttd { display:block; width:220px; margin:70px auto 0; border-top:1px solid #333; padding-top:4px; }
  .ringkasan { margin-bottom:14px; }
  .ringkasan td { text-align:center; font-size:13px; }
  .ringkasan .kecil { font-size:10px; color:#555; }
  @media print{ .no-print{display:none;} body{padding:0;} }
</style>
</head>
<body>
  <div class="no-print">
    <button onclick="window.print()">🖨️ Cetak / Simpan sebagai PDF</button>
  </div>

  <h1>Laporan Absensi & Izin/Sakit <?= $judulTambahan ?></h1>
  <h2><?= e($pengaturan['nama_instansi']) ?> — Periode <?= e(formatTanggalID($dariTanggal)) ?> s/d <?= e(formatTanggalID($sampaiTanggal)) ?></h2>

  <?php $ringkas = ringkasanLaporan($items); ?>
  <table class="ringkasan">
    <tr><th colspan="<?= count(daftarRingkasanLaporan($ringkas)) ?>">Ringkasan periode</th></tr>
    <tr>
      <?php foreach (daftarRingkasanLaporan($ringkas) as [$labelRingkas, $nilai, $warna]): ?>
        <td><b><?= (int) $nilai ?></b><br><span class="kecil"><?= e($labelRingkas) ?></span></td>
      <?php endforeach; ?>
    </tr>
  </table>

  <table>
    <tr>
      <th>Foto</th><th>Tanggal</th><th>Nama</th><th>Jenis</th><th>Jam</th><th>Jarak</th><th>Status</th><th>Keterangan</th>
    </tr>
    <?php foreach ($items as $it): $warna = warnaLaporanCetak($it); ?>
    <tr<?= $warna ? ' style="background-color:'.$warna['bg'].';color:'.$warna['teks'].';"' : '' ?>>
      <td>
        <?php
          // Foto ditanam langsung ke halaman (lihat fotoDataUri) supaya tidak ada
          // puluhan permintaan terpisah yang bisa gagal di hosting berbagi.
          $fotoTertanam = $it['foto'] ? fotoDataUri($it['foto']) : null;
        ?>
        <?php if ($fotoTertanam): ?>
          <img class="foto" src="<?= $fotoTertanam ?>">
        <?php elseif ($it['foto']): ?>
          <span class="foto-hilang" title="<?= e($it['foto']) ?>">foto<br>hilang</span>
        <?php else: ?>-<?php endif; ?>
      </td>
      <td><?= e($it['tanggal_tampil']) ?></td>
      <td><?= e($it['nama']) ?></td>
      <td><?= e($it['jenis']) ?></td>
      <td><?= e($it['jam']) ?></td>
      <td><?= e($it['jarak']) ?></td>
      <td><b><?= e($it['status']) ?></b></td>
      <td><?= e($it['keterangan']) ?></td>
    </tr>
    <?php endforeach; if (empty($items)): ?>
    <tr><td colspan="8" style="text-align:center;color:#888;">Tidak ada data pada periode ini.</td></tr>
    <?php endif; ?>
  </table>

  <script>
    // Otomatis buka dialog print supaya user tinggal pilih "Save as PDF".
    window.onload = () => window.print();
  </script>

<!-- Tempat tanda tangan: sengaja dibuat rata atas dengan tinggi baris "tanggal" yang sama
     di kiri & kanan, supaya garis tanda tangan mahasiswa dan pembimbing sejajar. -->
<table class="ttd">
  <tr>
    <td>
      <span class="tgl-ttd">&nbsp;</span>
      Mahasiswa,
      <div class="garis-ttd"><?= e($namaMhsTtd) ?></div>
    </td>
    <td>
      <span class="tgl-ttd"><?= e(formatTanggalID(date('Y-m-d'))) ?></span>
      Pembimbing,
      <div class="garis-ttd"><?= e($namaPembimbingTtd) ?></div>
    </td>
  </tr>
</table>
</body>
</html>
