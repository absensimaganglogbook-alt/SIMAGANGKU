<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('admin');
$pdo = getDB();
$error = '';
$success = '';

// Pesan setelah pengalihan (Post/Redirect/Get) — hanya tampil sekali, tidak muncul lagi saat refresh.
if ($pesanSekali = ambilPesanSekali()) {
    if (($pesanSekali['tipe'] ?? 'success') === 'success') { $success = $pesanSekali['pesan']; }
    else { $error = $pesanSekali['pesan']; }
}


// ---- Tambah mahasiswa ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    verifikasiCsrf();
    $nama = trim($_POST['nama'] ?? '');
    $nim = trim($_POST['nim'] ?? '');
    $kategori = kategoriDariInput($_POST['kategori'] ?? '');
    $cabangId = (int)($_POST['cabang_id'] ?? 0);
    $pembimbingId = (int)($_POST['pembimbing_id'] ?? 0) ?: null;
    $kampus = trim($_POST['kampus'] ?? '');
    $noHp = trim($_POST['no_hp'] ?? '');
    $tglMulai = $_POST['tanggal_mulai'] ?: null;
    $tglSelesai = $_POST['tanggal_selesai'] ?: null;
    $retensi = retensiFotoDariInput($_POST['retensi_foto_bulan'] ?? '');
    $passwordAwal = trim($_POST['password_awal'] ?? '');
    $passwordDigenerate = false;
    if ($passwordAwal === '') {
        $passwordAwal = bikinPasswordAcak();
        $passwordDigenerate = true;
    }

    if (!$nama || !$nim) {
        $error = 'Nama dan Username wajib diisi.';
    } elseif ($kategori === '') {
        $error = 'Kategori magang wajib dipilih.';
    } elseif (!$retensi['ok']) {
        $error = $retensi['pesan'];
    } elseif (!$cabangId || !ambilCabang($cabangId)) {
        $error = 'Cabang tempat magang wajib dipilih.';
    } elseif (!cabangSudahDiatur(ambilCabang($cabangId))) {
        $error = 'Cabang ini belum diatur jam kerjanya. Atur dulu lewat menu Atur → "Cabang, Lokasi & Jam Kerja" → Edit sebelum bisa mendaftarkan mahasiswa ke cabang ini.';
    } elseif ($pembimbingId && (!($pbCek = ambilPembimbing($pembimbingId)) || $pbCek['status'] !== 'aktif')) {
        $error = 'Pembimbing yang dipilih tidak ditemukan atau sudah nonaktif.';
    } elseif (!$passwordDigenerate && ($pesanKekuatan = validasiKekuatanPassword($passwordAwal)) !== null) {
        $error = $pesanKekuatan;
    } else {
        $cek = $pdo->prepare("SELECT id FROM users WHERE identifier=?");
        $cek->execute([$nim]);
        if ($cek->fetch()) {
            $error = 'Username sudah terdaftar.';
        } else {
            $hash = password_hash($passwordAwal, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (role, nama, identifier, password, kategori_id, cabang_id, pembimbing_id, kampus, no_hp, tanggal_mulai, tanggal_selesai, retensi_foto_bulan, status)
                                    VALUES ('mahasiswa', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'aktif')");
            $stmt->execute([$nama, $nim, $hash, $kategori, $cabangId, $pembimbingId, $kampus ?: null, $noHp ?: null, $tglMulai, $tglSelesai, $retensi['nilai']]);
            catatAktivitas('tambah_akun', 'mahasiswa', $pdo->lastInsertId(), $nama, 'Username: ' . $nim);
            simpanPesanSekali("Mahasiswa berhasil ditambahkan. Password awal: $passwordAwal — catat/salin sekarang, tidak ditampilkan lagi setelah ini. Mahasiswa wajib menggantinya sendiri saat login pertama.");
            redirect('/admin/mahasiswa.php');
        }
    }
}

// ---- Simpan hasil edit mahasiswa ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit'])) {
    verifikasiCsrf();
    $id = (int)$_POST['id'];
    $nama = trim($_POST['nama'] ?? '');
    $nim = trim($_POST['nim'] ?? '');
    $kategori = kategoriDariInput($_POST['kategori'] ?? '');
    $cabangId = (int)($_POST['cabang_id'] ?? 0);
    $pembimbingId = (int)($_POST['pembimbing_id'] ?? 0) ?: null;

    // Pembimbing yang SAAT INI sudah ditetapkan boleh tetap dipertahankan walau akunnya
    // sedang nonaktif (supaya edit data lain tidak gagal); memilih pembimbing BARU wajib yang aktif.
    $stmtPembimbingLama = $pdo->prepare("SELECT pembimbing_id FROM users WHERE id=? AND role='mahasiswa'");
    $stmtPembimbingLama->execute([$id]);
    $pembimbingLamaId = (int) $stmtPembimbingLama->fetchColumn() ?: null;
    $pembimbingDipilih = $pembimbingId ? ambilPembimbing($pembimbingId) : null;
    $kampus = trim($_POST['kampus'] ?? '');
    $noHp = trim($_POST['no_hp'] ?? '');
    $tglMulai = $_POST['tanggal_mulai'] ?: null;
    $tglSelesai = $_POST['tanggal_selesai'] ?: null;
    $retensi = retensiFotoDariInput($_POST['retensi_foto_bulan'] ?? '');

    if (!$nama || !$nim) {
        $error = 'Nama dan Username wajib diisi.';
    } elseif ($kategori === '') {
        $error = 'Kategori magang wajib dipilih.';
    } elseif (!$retensi['ok']) {
        $error = $retensi['pesan'];
    } elseif (!$cabangId || !ambilCabang($cabangId)) {
        $error = 'Cabang tempat magang wajib dipilih.';
    } elseif (!cabangSudahDiatur(ambilCabang($cabangId))) {
        $error = 'Cabang ini belum diatur jam kerjanya. Atur dulu lewat menu Atur → "Cabang, Lokasi & Jam Kerja" → Edit sebelum bisa memindahkan mahasiswa ke cabang ini.';
    } elseif ($pembimbingId && (!$pembimbingDipilih || ($pembimbingDipilih['status'] !== 'aktif' && $pembimbingId !== $pembimbingLamaId))) {
        $error = 'Pembimbing yang dipilih tidak ditemukan atau sudah nonaktif.';
    } else {
        // Username tidak boleh sama dengan mahasiswa lain (selain dirinya sendiri)
        $cek = $pdo->prepare("SELECT id FROM users WHERE identifier=? AND id<>?");
        $cek->execute([$nim, $id]);
        if ($cek->fetch()) {
            $error = 'Username sudah dipakai mahasiswa lain.';
        } else {
            $stmt = $pdo->prepare("UPDATE users SET nama=?, identifier=?, kategori_id=?, cabang_id=?, pembimbing_id=?, kampus=?, no_hp=?, tanggal_mulai=?, tanggal_selesai=?, retensi_foto_bulan=?
                                    WHERE id=? AND role='mahasiswa'");
            $stmt->execute([$nama, $nim, $kategori, $cabangId, $pembimbingId, $kampus ?: null, $noHp ?: null, $tglMulai, $tglSelesai, $retensi['nilai'], $id]);
            catatAktivitas('ubah_akun', 'mahasiswa', $id, $nama, 'Username: ' . $nim);
            // Jalankan ulang pembersihan foto di request berikutnya supaya retensi baru langsung diterapkan.
            unset($_SESSION['_terakhir_bersihkan_foto']);
            redirect('/admin/mahasiswa.php?tersimpan=1');
        }
    }
}

if (isset($_GET['status_diubah'])) {
    $success = 'Status aktif/nonaktif mahasiswa berhasil diubah.';
}
if (($_GET['sertifikat'] ?? '') === 'ok') {
    $success = 'Status sertifikat berhasil diperbarui.';
}
if (($_GET['sertifikat'] ?? '') === 'gagal') {
    $error = 'Status sertifikat gagal diperbarui.';
}
if (isset($_GET['dihapus'])) {
    $success = 'Akun mahasiswa beserta riwayat absen & izinnya berhasil dihapus.';
}
if (isset($_GET['tersimpan'])) {
    $success = 'Perubahan data mahasiswa berhasil disimpan.';
}

// ---- Data mahasiswa yang sedang diedit (kalau ada) ----
$editData = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id=? AND role='mahasiswa'");
    $stmt->execute([(int)$_GET['edit']]);
    $editData = $stmt->fetch();
}

// ---- Ubah status aktif/nonaktif ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle'])) {
    verifikasiCsrf();
    $stmt = $pdo->prepare("UPDATE users SET status = IF(status='aktif','nonaktif','aktif') WHERE id=? AND role='mahasiswa'");
    $idToggle = (int)$_POST['toggle'];
    $stmtNama = $pdo->prepare("SELECT nama, identifier, status FROM users WHERE id=? AND role='mahasiswa'");
    $stmtNama->execute([$idToggle]);
    $mhsToggle = $stmtNama->fetch();
    $stmt->execute([$idToggle]);
    if ($mhsToggle) {
        catatAktivitas('ubah_status', 'mahasiswa', $idToggle, $mhsToggle['nama'],
            'Status ' . $mhsToggle['status'] . ' → ' . ($mhsToggle['status'] === 'aktif' ? 'nonaktif' : 'aktif'));
    }
    redirect('/admin/mahasiswa.php?status_diubah=1');
}

// ---- Reset password ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset'])) {
    verifikasiCsrf();
    $idReset = (int)($_POST['reset_id'] ?? 0);
    $passwordBaru = trim($_POST['password_baru'] ?? '');
    $passwordDigenerate = false;
    if ($passwordBaru === '') {
        $passwordBaru = bikinPasswordAcak();
        $passwordDigenerate = true;
    }

    if (!$idReset) {
        $error = 'Mahasiswa tidak ditemukan.';
    } elseif (!$passwordDigenerate && ($pesanKekuatan = validasiKekuatanPassword($passwordBaru)) !== null) {
        $error = $pesanKekuatan;
    } else {
        $hash = password_hash($passwordBaru, PASSWORD_DEFAULT);
        $stmtNamaReset = $pdo->prepare("SELECT nama FROM users WHERE id=? AND role='mahasiswa'");
        $stmtNamaReset->execute([$idReset]);
        $namaReset = $stmtNamaReset->fetchColumn();
        $stmt = $pdo->prepare("UPDATE users SET password=?, harus_ganti_password=1 WHERE id=? AND role='mahasiswa'");
        $stmt->execute([$hash, $idReset]);
        catatAktivitas('reset_password', 'mahasiswa', $idReset, $namaReset ?: null);
        simpanPesanSekali("Password berhasil direset ke: $passwordBaru — catat/salin sekarang, tidak ditampilkan lagi setelah ini. Mahasiswa bisa ganti password sendiri sekali lagi lewat menu Profil.");
        redirect('/admin/mahasiswa.php');
    }
}

// ---- Hapus akun ----
// Tandai / batalkan tanda "sertifikat sudah dibuat".
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sertifikat_id'])) {
    verifikasiCsrf();
    $galat = ubahStatusSertifikat($_POST['sertifikat_id'], ($_POST['sertifikat_aksi'] ?? '') === 'tandai');
    redirect('/admin/mahasiswa.php' . ($galat ? '?sertifikat=gagal' : '?sertifikat=ok'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {
    verifikasiCsrf();
    $stmt = $pdo->prepare("DELETE FROM users WHERE id=? AND role='mahasiswa'");
    $idHapus = (int)$_POST['hapus'];
    $stmtNama = $pdo->prepare("SELECT nama, identifier FROM users WHERE id=? AND role='mahasiswa'");
    $stmtNama->execute([$idHapus]);
    $mhsHapus = $stmtNama->fetch();
    // Hapus dulu file fisiknya (foto absen, lampiran izin, foto profil) supaya tidak
    // tertinggal sebagai file yatim setelah barisnya hilang dari database.
    $jumlahBerkas = hapusBerkasMilikUser($idHapus);
    $stmt->execute([$idHapus]);
    if ($mhsHapus) {
        catatAktivitas('hapus_akun', 'mahasiswa', $idHapus, $mhsHapus['nama'],
            'Username: ' . $mhsHapus['identifier'] . ' — beserta seluruh riwayat absen, izin & log book-nya'
            . ($jumlahBerkas ? " ($jumlahBerkas file foto/lampiran ikut dihapus)" : ''));
    }
    redirect('/admin/mahasiswa.php?dihapus=1');
}

// ---- Cari & filter kategori/cabang untuk daftar mahasiswa ----
$cari = trim($_GET['cari'] ?? '');
// '' = semua kategori, 'none' = belum diatur, angka = id kategori tertentu
$filterKategori = ($_GET['kategori'] ?? '') === 'none' ? 'none' : kategoriDariInput($_GET['kategori'] ?? '');
$filterCabang = isset($_GET['cabang']) && $_GET['cabang'] !== '' ? (int)$_GET['cabang'] : '';
// '' = semua, 'none' = belum ada pembimbing, angka = id pembimbing tertentu
$filterPembimbing = $_GET['pembimbing'] ?? '';
if ($filterPembimbing !== 'none') {
    $filterPembimbing = ctype_digit((string)$filterPembimbing) ? (int)$filterPembimbing : '';
}

$sqlDaftar = "SELECT u.*, c.nama_cabang, p.nama AS nama_pembimbing, p.status AS status_pembimbing, dv.nama AS divisi_pembimbing FROM users u LEFT JOIN cabang c ON c.id = u.cabang_id LEFT JOIN users p ON p.id = u.pembimbing_id LEFT JOIN divisi dv ON dv.id = p.divisi_id WHERE u.role='mahasiswa'";
$paramsDaftar = [];
if ($cari !== '') {
    $sqlDaftar .= " AND (u.nama LIKE ? OR u.identifier LIKE ?)";
    $paramsDaftar[] = "%$cari%";
    $paramsDaftar[] = "%$cari%";
}
if ($filterKategori === 'none') {
    $sqlDaftar .= " AND u.kategori_id IS NULL";
} elseif ($filterKategori !== '') {
    $sqlDaftar .= " AND u.kategori_id = ?";
    $paramsDaftar[] = $filterKategori;
}
if ($filterCabang !== '') {
    $sqlDaftar .= " AND u.cabang_id = ?";
    $paramsDaftar[] = $filterCabang;
}
if ($filterPembimbing === 'none') {
    $sqlDaftar .= " AND u.pembimbing_id IS NULL";
} elseif ($filterPembimbing !== '') {
    $sqlDaftar .= " AND u.pembimbing_id = ?";
    $paramsDaftar[] = $filterPembimbing;
}
$sqlDaftar .= " ORDER BY u.nama ASC";

// ---- Pagination: hitung total dulu (dengan filter yang sama), baru ambil 1 halaman ----
$sqlHitung = str_replace('SELECT u.*, c.nama_cabang, p.nama AS nama_pembimbing, p.status AS status_pembimbing, dv.nama AS divisi_pembimbing', 'SELECT COUNT(*) c', $sqlDaftar);
$stmtHitung = $pdo->prepare($sqlHitung);
$stmtHitung->execute($paramsDaftar);
$totalDaftar = (int)$stmtHitung->fetch()['c'];

$pg = paginasi($totalDaftar, $_GET['halaman'] ?? 1, 20);
$sqlDaftar .= " LIMIT {$pg['perHalaman']} OFFSET {$pg['offset']}";

$stmtDaftar = $pdo->prepare($sqlDaftar);
$stmtDaftar->execute($paramsDaftar);
$daftar = $stmtDaftar->fetchAll();

$daftarCabang = daftarCabang();
$daftarPembimbingSemua = daftarPembimbing();
$adaFilter = $cari !== '' || $filterKategori !== '' || $filterCabang !== '' || $filterPembimbing !== '';
?>
<?php
$defaultRetensiFoto = (int) (ambilPengaturan()['retensi_foto_bulan'] ?? 0);

/**
 * Field "Retensi foto absen" + perkiraan tanggal hapus (dihitung JS dari tanggal selesai magang).
 * $nilai: null = ikuti default, 0 = selamanya, 1..60 = bulan.
 */
function fieldRetensiFoto($akhiran, $nilai, $defaultRetensiFoto) {
    $pilihan = pilihanRetensiFoto();
    if ($nilai !== null && (int) $nilai > 0 && !in_array((int) $nilai, $pilihan, true)) {
        $pilihan[] = (int) $nilai;
        sort($pilihan);
    }
    ob_start(); ?>
          <div class="mb-3">
            <label class="form-label">Simpan foto absen setelah magang selesai</label>
            <select name="retensi_foto_bulan" class="form-select pilih-retensi" data-tanggal-selesai="tanggalSelesai<?= $akhiran ?>" data-info="infoRetensi<?= $akhiran ?>">
              <option value="" <?= $nilai === null ? 'selected' : '' ?>>Ikuti default (<?= e(labelRetensiFoto($defaultRetensiFoto)) ?>)</option>
              <?php foreach ($pilihan as $bulan): ?>
                <option value="<?= $bulan ?>" <?= $nilai !== null && (int) $nilai === $bulan ? 'selected' : '' ?>><?= $bulan ?> bulan</option>
              <?php endforeach; ?>
              <option value="0" <?= $nilai !== null && (int) $nilai === 0 ? 'selected' : '' ?>>Simpan selamanya (tidak dihapus otomatis)</option>
            </select>
            <p class="text-muted small mt-1 mb-0" id="infoRetensi<?= $akhiran ?>"></p>
            <p class="text-muted small mt-1 mb-0">Hanya file fotonya yang dihapus; data absen & laporan tetap tersimpan.</p>
          </div>
    <?php return ob_get_clean();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Kelola Mahasiswa — Admin</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>

<div class="container pb-5">
  <h1 class="h4 fw-bold mb-3">Kelola Mahasiswa</h1>

  <?php if (!daftarKategori()): ?>
    <div class="alert alert-danger">⚠️ Belum ada kategori magang. Tambahkan minimal 1 kategori dulu lewat menu <a href="kategori.php" class="alert-link">Kategori</a> sebelum bisa membuat akun mahasiswa.</div>
  <?php endif; ?>
  <?php if (!$daftarCabang): ?>
    <div class="alert alert-danger">⚠️ Belum ada cabang yang ditambahkan. Tambahkan minimal 1 cabang dulu lewat menu <b>Atur (Pengaturan)</b> sebelum bisa membuat akun mahasiswa.</div>
  <?php elseif (!array_filter($daftarCabang, 'cabangSudahDiatur')): ?>
    <div class="alert alert-danger">⚠️ Semua cabang yang ada belum diatur jam kerjanya. Atur dulu lewat menu <a href="pengaturan.php#cabang" class="alert-link">Atur → Cabang, Lokasi & Jam Kerja</a> sebelum bisa membuat akun mahasiswa.</div>
  <?php endif; ?>

  <div class="card mb-3">
    <div class="card-body">
      <?php if ($editData): ?>
        <p class="text-primary fw-semibold small mb-1">Edit akun</p>
        <h2 class="h6 fw-bold mb-3">Ubah Data: <?= e($editData['nama']) ?></h2>
        <form method="POST">
          <?= csrfField() ?>
          <input type="hidden" name="id" value="<?= $editData['id'] ?>">
          <div class="mb-3"><label class="form-label">Nama lengkap</label><input type="text" name="nama" class="form-control" value="<?= e($editData['nama']) ?>" required></div>
          <div class="mb-3">
            <label class="form-label">Kategori magang <a href="kategori.php" class="small fw-normal ms-1">(kelola kategori)</a></label>
            <select name="kategori" id="kategoriEdit" class="form-select" required onchange="document.getElementById('btnGenerateEdit').disabled = !this.value;">
              <option value="">— Pilih kategori —</option>
              <?php foreach (daftarKategori() as $kode => $label): ?>
                <option value="<?= e($kode) ?>" <?= (int)$editData['kategori_id'] === $kode ? 'selected' : '' ?>><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Username (dipakai untuk login)</label>
            <div class="input-group">
              <input type="text" name="nim" id="nimEdit" class="form-control" value="<?= e($editData['identifier']) ?>" required>
              <button type="button" class="btn btn-outline-secondary" id="btnGenerateEdit" <?= $editData['kategori_id'] ? '' : 'disabled' ?> onclick="generateKode('kategoriEdit','nimEdit',this)">🔀 Generate Otomatis</button>
            </div>
            <p class="text-muted small mt-1 mb-0">Hati-hati mengganti kode yang sudah dipakai mahasiswa — dia perlu tahu kode barunya untuk login berikutnya.</p>
          </div>
          <div class="mb-3">
            <label class="form-label">Cabang tempat magang</label>
            <select name="cabang_id" class="form-select" required>
              <option value="">— Pilih cabang —</option>
              <?php foreach ($daftarCabang as $c): $bisaDipilih = cabangSudahDiatur($c); ?>
                <option value="<?= $c['id'] ?>" <?= $editData['cabang_id'] == $c['id'] ? 'selected' : '' ?> <?= $bisaDipilih ? '' : 'disabled' ?>><?= e($c['nama_cabang']) ?><?= $bisaDipilih ? '' : ' — jam kerja belum diatur' ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Pembimbing</label>
            <select name="pembimbing_id" class="form-select">
              <option value="">— Belum ada pembimbing —</option>
              <?php foreach ($daftarPembimbingSemua as $pb): $pbTerpilih = (int)$editData['pembimbing_id'] === (int)$pb['id']; ?>
                <?php if ($pb['status'] !== 'aktif' && !$pbTerpilih) continue; ?>
                <option value="<?= $pb['id'] ?>" <?= $pbTerpilih ? 'selected' : '' ?>><?= e($pb['nama']) ?><?= $pb['nama_divisi'] ? ' — ' . e($pb['nama_divisi']) : '' ?><?= $pb['nama_cabang'] ? ' · ' . e($pb['nama_cabang']) : '' ?> (<?= e($pb['identifier']) ?>)<?= $pb['status'] !== 'aktif' ? ' — nonaktif' : '' ?></option>
              <?php endforeach; ?>
            </select>
            <p class="text-muted small mt-1 mb-0">Pembimbing bisa memantau & memproses data mahasiswa ini.</p>
          </div>
          <div class="mb-3"><label class="form-label">Asal kampus</label><input type="text" name="kampus" class="form-control" value="<?= e($editData['kampus']) ?>"></div>
          <div class="mb-3"><label class="form-label">No. HP</label><input type="text" name="no_hp" class="form-control" value="<?= e($editData['no_hp']) ?>"></div>
          <div class="mb-3"><label class="form-label">Tanggal mulai magang</label><input type="date" name="tanggal_mulai" class="form-control" value="<?= e($editData['tanggal_mulai']) ?>"></div>
          <div class="mb-3"><label class="form-label">Tanggal selesai magang</label><input type="date" name="tanggal_selesai" id="tanggalSelesaiEdit" class="form-control" value="<?= e($editData['tanggal_selesai']) ?>"></div>
          <?= fieldRetensiFoto('Edit', $editData['retensi_foto_bulan'] === null ? null : (int) $editData['retensi_foto_bulan'], $defaultRetensiFoto) ?>
          <p class="text-muted small">Untuk ganti password, gunakan tombol "Reset Password" di daftar bawah, bukan lewat form ini.</p>

          <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= e($error) ?></div><?php endif; ?>

          <div class="d-flex gap-2">
            <button type="submit" name="edit" value="1" class="btn btn-primary">Simpan Perubahan</button>
            <a href="mahasiswa.php" class="btn btn-secondary">Batal</a>
          </div>
        </form>
      <?php else: ?>
        <p class="text-primary fw-semibold small mb-1">Tambah akun</p>
        <h2 class="h6 fw-bold mb-3">Mahasiswa Magang Baru</h2>
        <form method="POST">
          <?= csrfField() ?>
          <div class="mb-3"><label class="form-label">Nama lengkap</label><input type="text" name="nama" class="form-control" required></div>
          <div class="mb-3">
            <label class="form-label">Kategori magang <a href="kategori.php" class="small fw-normal ms-1">(kelola kategori)</a></label>
            <select name="kategori" id="kategoriTambah" class="form-select" required onchange="document.getElementById('btnGenerateTambah').disabled = !this.value;">
              <option value="">— Pilih kategori —</option>
              <?php foreach (daftarKategori() as $kode => $label): ?>
                <option value="<?= e($kode) ?>"><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Username (dipakai untuk login)</label>
            <div class="input-group">
              <input type="text" name="nim" id="nimTambah" class="form-control" required>
              <button type="button" class="btn btn-outline-secondary" id="btnGenerateTambah" disabled onclick="generateKode('kategoriTambah','nimTambah',this)">🔀 Generate Otomatis</button>
            </div>
            <p class="text-muted small mt-1 mb-0">Isi NIM/NISN, atau pakai tombol "Generate Otomatis" untuk username berurutan (mis. PKL001).</p>
          </div>
          <div class="mb-3">
            <label class="form-label">Cabang tempat magang</label>
            <select name="cabang_id" class="form-select" required>
              <option value="">— Pilih cabang —</option>
              <?php foreach ($daftarCabang as $c): $bisaDipilih = cabangSudahDiatur($c); ?>
                <option value="<?= $c['id'] ?>" <?= $bisaDipilih ? '' : 'disabled' ?>><?= e($c['nama_cabang']) ?><?= $bisaDipilih ? '' : ' — jam kerja belum diatur' ?></option>
              <?php endforeach; ?>
            </select>
            <p class="text-muted small mt-1 mb-0">Validasi jarak GPS mengikuti koordinat cabang ini. Cabang yang jam kerjanya belum diatur tidak bisa dipilih.</p>
          </div>
          <div class="mb-3">
            <label class="form-label">Pembimbing</label>
            <select name="pembimbing_id" class="form-select">
              <option value="">— Belum ada pembimbing —</option>
              <?php foreach ($daftarPembimbingSemua as $pb): if ($pb['status'] !== 'aktif') continue; ?>
                <option value="<?= $pb['id'] ?>"><?= e($pb['nama']) ?><?= $pb['nama_divisi'] ? ' — ' . e($pb['nama_divisi']) : '' ?><?= $pb['nama_cabang'] ? ' · ' . e($pb['nama_cabang']) : '' ?> (<?= e($pb['identifier']) ?>)</option>
              <?php endforeach; ?>
            </select>
            <p class="text-muted small mt-1 mb-0">Opsional, bisa diatur belakangan lewat Edit. Akun pembimbing dibuat lewat menu Atur → <a href="kelola_pembimbing.php">Kelola Pembimbing</a>.</p>
          </div>
          <div class="mb-3"><label class="form-label">Asal kampus</label><input type="text" name="kampus" class="form-control"></div>
          <div class="mb-3"><label class="form-label">No. HP</label><input type="text" name="no_hp" class="form-control"></div>
          <div class="mb-3"><label class="form-label">Tanggal mulai magang</label><input type="date" name="tanggal_mulai" class="form-control"></div>
          <div class="mb-3"><label class="form-label">Tanggal selesai magang</label><input type="date" name="tanggal_selesai" id="tanggalSelesaiTambah" class="form-control"></div>
          <?= fieldRetensiFoto('Tambah', null, $defaultRetensiFoto) ?>
          <div class="mb-3"><label class="form-label">Password awal (kosongkan = digenerate otomatis secara acak)</label><input type="text" name="password_awal" class="form-control" placeholder="Kosongkan untuk password acak otomatis"></div>
          <p class="text-muted small mt-n2">Kalau diisi manual: min. 8 karakter, memuat huruf besar, kecil, angka & simbol. Ditampilkan <b>sekali saja</b>.</p>

          <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= e($error) ?></div><?php endif; ?>
          <?php if ($success): ?><div class="alert alert-success py-2 small"><?= e($success) ?></div><?php endif; ?>

          <button type="submit" name="tambah" value="1" class="btn btn-primary">Tambah Mahasiswa</button>
        </form>
      <?php endif; ?>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Daftar</p>
      <h2 class="h6 fw-bold mb-3">Semua Mahasiswa (<?= $totalDaftar ?>)</h2>

      <form method="GET" class="row g-2 align-items-end mb-3">
        <div class="col-12 col-md-3">
          <label class="form-label small">Cari nama / username</label>
          <input type="text" name="cari" class="form-control" value="<?= e($cari) ?>" placeholder="Ketik nama atau username...">
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small">Kategori</label>
          <select name="kategori" class="form-select">
            <option value="">— Semua kategori —</option>
            <option value="none" <?= $filterKategori === 'none' ? 'selected' : '' ?>>Belum diatur</option>
            <?php foreach (daftarKategori() as $kode => $label): ?>
              <option value="<?= e($kode) ?>" <?= $filterKategori === $kode ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-2">
          <label class="form-label small">Cabang</label>
          <select name="cabang" class="form-select">
            <option value="">— Semua cabang —</option>
            <?php foreach ($daftarCabang as $c): ?>
              <option value="<?= $c['id'] ?>" <?= $filterCabang == $c['id'] ? 'selected' : '' ?>><?= e($c['nama_cabang']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-2">
          <label class="form-label small">Pembimbing</label>
          <select name="pembimbing" class="form-select">
            <option value="">— Semua —</option>
            <option value="none" <?= $filterPembimbing === 'none' ? 'selected' : '' ?>>Belum ada pembimbing</option>
            <?php foreach ($daftarPembimbingSemua as $pb): ?>
              <option value="<?= $pb['id'] ?>" <?= $filterPembimbing === (int)$pb['id'] ? 'selected' : '' ?>><?= e($pb['nama']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 col-md-2 d-flex gap-2">
          <button type="submit" class="btn btn-secondary flex-fill">Terapkan</button>
          <?php if ($adaFilter): ?>
            <a href="mahasiswa.php" class="btn btn-outline-secondary flex-fill">Reset</a>
          <?php endif; ?>
        </div>
      </form>

      <div class="list-group list-group-flush" style="max-height:520px;overflow-y:auto;">
        <?php if (empty($daftar)): ?>
          <div class="text-muted small text-center py-3"><?= $adaFilter ? 'Tidak ada mahasiswa yang cocok dengan pencarian/filter.' : 'Belum ada data mahasiswa.' ?></div>
        <?php else: foreach ($daftar as $m): ?>
          <div class="list-group-item px-0">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <div class="d-flex align-items-center gap-2">
                <img src="<?= e(urlAvatar($m['foto_profil'], $m['nama'], 44)) ?>" class="rounded-circle" style="width:28px;height:28px;object-fit:cover;">
                <b class="small"><?= e($m['nama']) ?></b>
              </div>
              <span class="badge text-bg-<?= $m['status']==='aktif' ? 'success' : 'danger' ?>"><?= $m['status']==='aktif' ? 'Aktif' : 'Nonaktif' ?></span>
            </div>
            <div class="small text-muted">Username: <?= e($m['identifier']) ?> <?= $m['kampus'] ? '· '.e($m['kampus']) : '' ?></div>
            <div class="small text-muted">Kategori: <b><?= e(labelKategori($m['kategori_id'])) ?></b></div>
            <div class="small text-muted">Cabang: <b><?= $m['nama_cabang'] ? e($m['nama_cabang']) : 'Belum diatur' ?></b></div>
            <div class="small text-muted">Pembimbing: <b><?= $m['nama_pembimbing'] ? e($m['nama_pembimbing']) : 'Belum ada' ?></b><?= $m['divisi_pembimbing'] ? ' (' . e($m['divisi_pembimbing']) . ')' : '' ?><?= ($m['nama_pembimbing'] && $m['status_pembimbing'] !== 'aktif') ? ' <span class="text-danger">(akun nonaktif)</span>' : '' ?></div>
            <?php if ($m['tanggal_mulai'] || $m['tanggal_selesai']): ?>
              <div class="small text-muted">
                Periode magang: <?= $m['tanggal_mulai'] ? e(formatTanggalID($m['tanggal_mulai'])) : '-' ?> – <?= $m['tanggal_selesai'] ? e(formatTanggalID($m['tanggal_selesai'])) : '-' ?>
                <?php if ($m['tanggal_selesai'] && magangSudahSelesai($m['tanggal_selesai'])): ?>
                  <span class="text-danger">· sudah berakhir</span>
                <?php endif; ?>
              </div>
            <?php endif; ?>
            <?php if ($m['tanggal_selesai']): ?>
              <div class="small text-muted">
                Sertifikat:
                <?php if ($m['sertifikat_selesai_tgl']): ?>
                  <span class="badge text-bg-success">✓ <?= e(labelStatusSertifikat($m['sertifikat_selesai_tgl'])) ?></span>
                <?php else: ?>
                  <span class="badge text-bg-<?= magangSudahSelesai($m['tanggal_selesai']) ? 'danger' : 'secondary' ?>">Belum dibuat</span>
                <?php endif; ?>
                <form method="POST" class="d-inline m-0"
                      data-konfirmasi="<?= $m['sertifikat_selesai_tgl']
                          ? 'Batalkan tanda sertifikat ' . e($m['nama']) . '? Dia akan muncul lagi di daftar pengingat.'
                          : 'Tandai sertifikat ' . e($m['nama']) . ' sudah dibuat?' ?>"
                      data-konfirmasi-judul="Status sertifikat"
                      data-konfirmasi-ya="<?= $m['sertifikat_selesai_tgl'] ? 'Ya, batalkan' : 'Ya, sudah dibuat' ?>">
                  <?= csrfField() ?>
                  <input type="hidden" name="sertifikat_id" value="<?= (int) $m['id'] ?>">
                  <input type="hidden" name="sertifikat_aksi" value="<?= $m['sertifikat_selesai_tgl'] ? 'batal' : 'tandai' ?>">
                  <button type="submit" class="btn btn-link btn-sm p-0 align-baseline">
                    <?= $m['sertifikat_selesai_tgl'] ? 'batalkan' : 'tandai sudah dibuat' ?>
                  </button>
                </form>
              </div>
            <?php endif; ?>
            <?php
              $bulanRetensi = retensiFotoBerlaku($m['retensi_foto_bulan']);
              $tglHapusFoto = tanggalHapusFotoAbsen($m['tanggal_selesai'], $m['retensi_foto_bulan']);
            ?>
            <div class="small text-muted">
              Foto absen: <b><?= e(labelRetensiFoto($bulanRetensi)) ?></b><?= $m['retensi_foto_bulan'] === null ? ' (default)' : '' ?>
              <?php if ($tglHapusFoto): ?>
                · <?= $tglHapusFoto <= date('Y-m-d') ? '<span class="text-danger">sudah/segera dihapus</span>' : 'dihapus mulai ' . e(formatTanggalID($tglHapusFoto)) ?>
              <?php endif; ?>
            </div>
            <div class="d-flex flex-wrap gap-2 mt-2">
              <a href="mahasiswa.php?edit=<?= $m['id'] ?>" class="btn btn-outline-primary btn-sm">✏️ Edit</a>
              <form method="POST" class="m-0" data-konfirmasi="<?= ($m['status']!=='aktif' && $m['tanggal_selesai'] && magangSudahSelesai($m['tanggal_selesai'])) ? 'Masa magang mahasiswa ini sudah lewat, kalau diaktifkan akan otomatis nonaktif lagi kecuali kamu perpanjang dulu tanggal selesainya lewat Edit. Lanjutkan?' : 'Ubah status aktif/nonaktif mahasiswa ini?' ?>" data-konfirmasi-judul="Ubah status mahasiswa" data-konfirmasi-ya="Ya, ubah">
                <?= csrfField() ?>
                <input type="hidden" name="toggle" value="<?= $m['id'] ?>">
                <button type="submit" class="btn btn-outline-secondary btn-sm"><?= $m['status']==='aktif' ? 'Nonaktifkan' : 'Aktifkan' ?></button>
              </form>
              <button type="button" class="btn btn-outline-primary btn-sm btn-reset-pass" data-id="<?= $m['id'] ?>" data-nama="<?= e($m['nama']) ?>">Reset Password</button>
              <form method="POST" class="m-0" data-konfirmasi="Hapus akun <?= e($m['nama']) ?> beserta SELURUH riwayat absen, izin, log book, dan fotonya? Tindakan ini tidak bisa dibatalkan. Unduh dulu arsipnya lewat tautan di bawah kalau masih dibutuhkan."
                    data-konfirmasi-tautan="<?php
                      // Arsip yang sebaiknya diunduh dulu sebelum data mahasiswa hilang permanen.
                      $dariArsip = $m['tanggal_mulai'] ?: date('Y-m-d', strtotime('-1 year'));
                      $sampaiArsip = $m['tanggal_selesai'] ?: date('Y-m-d');
                      if ($sampaiArsip > date('Y-m-d')) $sampaiArsip = date('Y-m-d');
                      $qsArsip = 'dari=' . urlencode($dariArsip) . '&sampai=' . urlencode($sampaiArsip) . '&mahasiswa=' . (int) $m['id'];
                      echo e('📄 Unduh laporan absensi (PDF)|' . BASE_URL . '/admin/export_pdf.php?' . $qsArsip
                           . '||📊 Unduh laporan absensi (Excel)|' . BASE_URL . '/admin/export_excel.php?' . $qsArsip
                           . '||📓 Unduh log book (PDF)|' . BASE_URL . '/mahasiswa/export_logbook.php?' . $qsArsip);
                    ?>" data-konfirmasi-judul="Hapus akun mahasiswa" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1">
                <?= csrfField() ?>
                <input type="hidden" name="hapus" value="<?= $m['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
              </form>
            </div>
            <div class="mt-2">
              <a href="laporan.php?mahasiswa=<?= $m['id'] ?>&dari=<?= $m['tanggal_mulai'] ?: date('Y-m-01') ?>&sampai=<?= date('Y-m-d') ?>" class="btn btn-outline-secondary btn-sm">📄 Lihat Laporan Mahasiswa Ini</a>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <?php if ($pg['totalHalaman'] > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
          <?php if ($pg['halaman'] > 1): ?>
            <a href="<?= urlHalaman($pg['halaman'] - 1) ?>" class="btn btn-outline-secondary btn-sm">← Sebelumnya</a>
          <?php else: ?><span></span><?php endif; ?>
          <span class="text-muted small">Halaman <?= $pg['halaman'] ?> dari <?= $pg['totalHalaman'] ?></span>
          <?php if ($pg['halaman'] < $pg['totalHalaman']): ?>
            <a href="<?= urlHalaman($pg['halaman'] + 1) ?>" class="btn btn-outline-secondary btn-sm">Berikutnya →</a>
          <?php else: ?><span></span><?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Form tersembunyi untuk kirim reset password beserta password baru yang diketik admin -->
<form id="formReset" method="POST" style="display:none;">
  <?= csrfField() ?>
  <input type="hidden" name="reset" value="1">
  <input type="hidden" name="reset_id" id="resetId" value="">
  <input type="hidden" name="password_baru" id="resetPasswordBaru" value="">
</form>

<?php include __DIR__ . '/../includes/foot.php'; ?>
<script>
// Perkiraan tanggal foto absen dihapus, dihitung dengan aturan yang sama dengan server
// (tanggal yang tidak ada di bulan tujuan dibulatkan ke akhir bulan).
(function () {
  var DEFAULT_RETENSI = <?= (int) $defaultRetensiFoto ?>;
  var NAMA_BULAN = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

  function tambahBulan(iso, n) {
    var p = iso.split('-').map(Number);
    var total = p[0] * 12 + (p[1] - 1) + n;
    var y = Math.floor(total / 12), m = total % 12;
    var hariMaks = new Date(y, m + 1, 0).getDate();
    return { y: y, m: m, d: Math.min(p[2], hariMaks) };
  }

  document.querySelectorAll('.pilih-retensi').forEach(function (select) {
    var inputSelesai = document.getElementById(select.dataset.tanggalSelesai);
    var info = document.getElementById(select.dataset.info);
    function perbarui() {
      var bulan = select.value === '' ? DEFAULT_RETENSI : parseInt(select.value, 10);
      if (bulan <= 0) {
        info.textContent = 'Foto absen mahasiswa ini tidak akan dihapus otomatis.';
      } else if (!inputSelesai || !inputSelesai.value) {
        info.textContent = 'Foto akan dihapus ' + bulan + ' bulan setelah tanggal selesai magang (isi tanggal selesai untuk melihat perkiraannya).';
      } else {
        var t = tambahBulan(inputSelesai.value, bulan);
        info.textContent = '🗑️ Perkiraan foto absen mulai dihapus: ' + t.d + ' ' + NAMA_BULAN[t.m] + ' ' + t.y + '.';
      }
    }
    select.addEventListener('change', perbarui);
    if (inputSelesai) inputSelesai.addEventListener('input', perbarui);
    perbarui();
  });
})();

async function generateKode(idSelectKategori, idInputNim, btn) {
  const kategori = document.getElementById(idSelectKategori).value;
  if (!kategori) {
    Dialog.info('Pilih kategori magang dulu, karena username otomatis mengikuti prefiks kategori.', 'Kategori belum dipilih');
    return;
  }
  const teksAsli = btn.textContent;
  btn.disabled = true; btn.textContent = 'Membuat…';
  try {
    const res = await fetch('generate_kode.php?kategori=' + encodeURIComponent(kategori));
    const data = await res.json();
    if (data.ok) {
      document.getElementById(idInputNim).value = data.kode;
    } else {
      Dialog.error(data.message || 'Gagal membuat username otomatis.');
    }
  } catch (e) {
    Dialog.error('Terjadi kesalahan jaringan. Coba lagi.');
  }
  btn.disabled = false; btn.textContent = teksAsli;
}

document.querySelectorAll('.btn-reset-pass').forEach(function (btn) {
  btn.addEventListener('click', async function () {
    var id = btn.dataset.id;
    var nama = btn.dataset.nama;
    // Input & konfirmasi memakai popup tengah layar (lihat includes/dialog.php)
    var pass = await Dialog.prompt({
      judul: 'Reset password',
      pesan: 'Password baru untuk ' + nama + ':\n(Kosongkan lalu klik Lanjutkan untuk digenerate otomatis secara acak)',
      placeholder: 'Kosongkan = password acak otomatis'
    });
    if (pass === null || pass === false) return; // dibatalkan
    pass = pass.trim();
    if (pass) {
      var kurangSyarat = [];
      if (pass.length < 8) kurangSyarat.push('minimal 8 karakter');
      if (!/[A-Z]/.test(pass)) kurangSyarat.push('huruf besar');
      if (!/[a-z]/.test(pass)) kurangSyarat.push('huruf kecil');
      if (!/[0-9]/.test(pass)) kurangSyarat.push('angka');
      if (!/[^A-Za-z0-9]/.test(pass)) kurangSyarat.push('simbol');
      if (kurangSyarat.length) {
        await Dialog.error('Kata sandi kurang: ' + kurangSyarat.join(', ') + '. Kosongkan saja kalau mau digenerate otomatis.', 'Password terlalu lemah');
        return;
      }
    }
    var lanjutReset = await Dialog.konfirmasi({
      judul: 'Reset password',
      pesan: pass
        ? ('Reset password ' + nama + ' ke "' + pass + '"?')
        : ('Reset password ' + nama + ' ke password acak baru? Password barunya ditampilkan sekali setelah ini.'),
      labelYa: 'Ya, reset'
    });
    if (!lanjutReset) return;
    document.getElementById('resetId').value = id;
    document.getElementById('resetPasswordBaru').value = pass;
    document.getElementById('formReset').submit();
  });
});
</script>
</body>
</html>
