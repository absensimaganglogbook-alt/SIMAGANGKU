<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('admin');
$pdo = getDB();
$error = '';
$success = '';

// Pesan setelah pengalihan (Post/Redirect/Get) — hanya tampil sekali, tidak muncul lagi saat refresh.
if ($pesanSekali = ambilPesanSekali()) {
    if (($pesanSekali['tipe'] ?? 'success') === 'success') { $success = $pesanSekali['pesan']; }
    else { $error = $pesanSekali['pesan']; }
}


/**
 * Kelola akun pembimbing (khusus admin).
 * Pembimbing hanya bisa mengakses data mahasiswa bimbingannya, jadi akun ini jauh
 * lebih terbatas dibanding admin. Mahasiswa bimbingan ditetapkan dari menu
 * Mahasiswa → Edit (kolom "Pembimbing").
 */

// ---- Tambah pembimbing ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    verifikasiCsrf();
    $nama = trim($_POST['nama'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $noHp = trim($_POST['no_hp'] ?? '');
    $divisiId = divisiDariInput($_POST['divisi_id'] ?? '');
    $cabangIdInput = (int) ($_POST['cabang_id'] ?? 0);
    $cabangValid = $cabangIdInput && ambilCabang($cabangIdInput) ? $cabangIdInput : '';
    $passwordAwal = trim($_POST['password_awal'] ?? '');
    $passwordDigenerate = false;
    if ($passwordAwal === '') {
        $passwordAwal = bikinPasswordAcak();
        $passwordDigenerate = true;
    }

    if (!$nama || !$username) {
        $error = 'Nama dan username wajib diisi.';
    } elseif ($divisiId === '' && daftarDivisi()) {
        $error = 'Divisi/bagian wajib dipilih.';
    } elseif ($cabangValid === '' && daftarCabang()) {
        $error = 'Cabang tempat pembimbing bertugas wajib dipilih.';
    } elseif (!$passwordDigenerate && ($pesanKekuatan = validasiKekuatanPassword($passwordAwal)) !== null) {
        $error = $pesanKekuatan;
    } else {
        $cek = $pdo->prepare("SELECT id FROM users WHERE identifier=?");
        $cek->execute([$username]);
        if ($cek->fetch()) {
            $error = 'Username sudah dipakai akun lain (admin, pembimbing, atau mahasiswa). Pilih username lain.';
        } else {
            $hash = password_hash($passwordAwal, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (role, nama, identifier, password, no_hp, divisi_id, cabang_id, status, harus_ganti_password)
                                    VALUES ('pembimbing', ?, ?, ?, ?, ?, ?, 'aktif', 1)");
            $stmt->execute([$nama, $username, $hash, $noHp ?: null, $divisiId ?: null, $cabangValid ?: null]);
            catatAktivitas('tambah_akun', 'pembimbing', $pdo->lastInsertId(), $nama, 'Username: ' . $username);
            simpanPesanSekali("Pembimbing berhasil ditambahkan. Password awal: $passwordAwal — catat/salin sekarang, tidak ditampilkan lagi setelah ini. Pembimbing wajib menggantinya saat login pertama.");
            redirect('/admin/kelola_pembimbing.php');
        }
    }
}

// ---- Simpan hasil edit pembimbing ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit'])) {
    verifikasiCsrf();
    $id = (int) ($_POST['id'] ?? 0);
    $nama = trim($_POST['nama'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $noHp = trim($_POST['no_hp'] ?? '');
    $divisiId = divisiDariInput($_POST['divisi_id'] ?? '');
    $cabangIdInput = (int) ($_POST['cabang_id'] ?? 0);
    $cabangValid = $cabangIdInput && ambilCabang($cabangIdInput) ? $cabangIdInput : '';

    if (!ambilPembimbing($id)) {
        $error = 'Pembimbing tidak ditemukan.';
    } elseif (!$nama || !$username) {
        $error = 'Nama dan username wajib diisi.';
    } elseif ($divisiId === '' && daftarDivisi()) {
        $error = 'Divisi/bagian wajib dipilih.';
    } elseif ($cabangValid === '' && daftarCabang()) {
        $error = 'Cabang tempat pembimbing bertugas wajib dipilih.';
    } else {
        $cek = $pdo->prepare("SELECT id FROM users WHERE identifier=? AND id<>?");
        $cek->execute([$username, $id]);
        if ($cek->fetch()) {
            $error = 'Username sudah dipakai akun lain. Pilih username lain.';
        } else {
            $stmt = $pdo->prepare("UPDATE users SET nama=?, identifier=?, no_hp=?, divisi_id=?, cabang_id=? WHERE id=? AND role='pembimbing'");
            $stmt->execute([$nama, $username, $noHp ?: null, $divisiId ?: null, $cabangValid ?: null, $id]);
            catatAktivitas('ubah_akun', 'pembimbing', $id, $nama, 'Username: ' . $username);
            redirect('/admin/kelola_pembimbing.php?tersimpan=1');
        }
    }
}

if (isset($_GET['tersimpan'])) {
    $success = 'Perubahan data pembimbing berhasil disimpan.';
}

// ---- Reset password ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset'])) {
    verifikasiCsrf();
    $idReset = (int) ($_POST['reset_id'] ?? 0);
    $passwordBaru = trim($_POST['password_baru'] ?? '');
    $passwordDigenerate = false;
    if ($passwordBaru === '') {
        $passwordBaru = bikinPasswordAcak();
        $passwordDigenerate = true;
    }

    if (!ambilPembimbing($idReset)) {
        $error = 'Pembimbing tidak ditemukan.';
    } elseif (!$passwordDigenerate && ($pesanKekuatan = validasiKekuatanPassword($passwordBaru)) !== null) {
        $error = $pesanKekuatan;
    } else {
        $hash = password_hash($passwordBaru, PASSWORD_DEFAULT);
        $pembimbingReset = ambilPembimbing($idReset);
        $stmt = $pdo->prepare("UPDATE users SET password=?, harus_ganti_password=1 WHERE id=? AND role='pembimbing'");
        $stmt->execute([$hash, $idReset]);
        catatAktivitas('reset_password', 'pembimbing', $idReset, $pembimbingReset['nama'] ?? null);
        simpanPesanSekali("Password berhasil direset ke: $passwordBaru — catat/salin sekarang, tidak ditampilkan lagi setelah ini.");
        redirect('/admin/kelola_pembimbing.php');
    }
}

// ---- Ubah status aktif/nonaktif ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle'])) {
    verifikasiCsrf();
    $stmt = $pdo->prepare("UPDATE users SET status = IF(status='aktif','nonaktif','aktif') WHERE id=? AND role='pembimbing'");
    $idToggle = (int) $_POST['toggle'];
    $pembimbingToggle = ambilPembimbing($idToggle);
    $stmt->execute([$idToggle]);
    if ($pembimbingToggle) {
        catatAktivitas('ubah_status', 'pembimbing', $idToggle, $pembimbingToggle['nama'],
            'Status ' . $pembimbingToggle['status'] . ' → ' . ($pembimbingToggle['status'] === 'aktif' ? 'nonaktif' : 'aktif'));
    }
    redirect('/admin/kelola_pembimbing.php?status_diubah=1');
}

// ---- Hapus pembimbing ----
// Akun pembimbing TIDAK bisa dihapus selama masih ada mahasiswa AKTIF yang memakainya —
// mahasiswa tersebut harus dialihkan ke pembimbing lain dulu (menu Mahasiswa → Edit),
// supaya tidak ada mahasiswa aktif yang tiba-tiba kehilangan pembimbing.
// Kalau yang tersisa cuma mahasiswa nonaktif (magang sudah selesai), penghapusan
// diizinkan: data mahasiswanya tetap utuh, hanya kolom pembimbing_id yang jadi NULL
// (foreign key ON DELETE SET NULL).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {
    verifikasiCsrf();
    $idHapus = (int) $_POST['hapus'];
    $pembimbingHapus = ambilPembimbing($idHapus);
    $bimbinganHapus = jumlahBimbingan($idHapus);

    if (!$pembimbingHapus) {
        $error = 'Pembimbing tidak ditemukan.';
    } elseif ($bimbinganHapus['aktif'] > 0) {
        $error = 'Akun "' . $pembimbingHapus['nama'] . '" belum bisa dihapus karena masih dipakai '
               . $bimbinganHapus['aktif'] . ' mahasiswa aktif. Alihkan dulu mahasiswa tersebut ke pembimbing lain '
               . '(menu Mahasiswa → Edit → kolom Pembimbing), baru akun ini bisa dihapus. '
               . 'Kalau pembimbing ini hanya berhenti bertugas sementara, gunakan tombol Nonaktifkan.';
    } else {
        hapusBerkasMilikUser($idHapus);
        $pdo->prepare("DELETE FROM users WHERE id=? AND role='pembimbing'")->execute([$idHapus]);
        catatAktivitas('hapus_akun', 'pembimbing', $idHapus, $pembimbingHapus['nama'],
            'Username: ' . $pembimbingHapus['identifier'] . ' — ' . $bimbinganHapus['total'] . ' mahasiswa jadi tanpa pembimbing');
        redirect('/admin/kelola_pembimbing.php?terhapus=1');
    }
}

if (isset($_GET['status_diubah'])) {
    $success = 'Status aktif/nonaktif pembimbing berhasil diubah.';
}
if (isset($_GET['terhapus'])) {
    $success = 'Akun pembimbing berhasil dihapus.';
}

// ---- Data pembimbing yang sedang diedit ----
$editData = isset($_GET['edit']) ? ambilPembimbing((int) $_GET['edit']) : null;

// ---- Daftar pembimbing + jumlah mahasiswa bimbingannya ----
// Filter divisi: '' = semua, 'none' = divisi belum diatur, angka = id divisi tertentu.
$filterDivisi = ($_GET['divisi'] ?? '') === 'none' ? 'none' : divisiDariInput($_GET['divisi'] ?? '');
$whereDivisi = '';
$paramDivisi = [];
if ($filterDivisi === 'none') {
    $whereDivisi = " AND p.divisi_id IS NULL";
} elseif ($filterDivisi !== '') {
    $whereDivisi = " AND p.divisi_id = ?";
    $paramDivisi[] = $filterDivisi;
}

$stmtTotal = $pdo->prepare("SELECT COUNT(*) c FROM users p WHERE p.role='pembimbing'{$whereDivisi}");
$stmtTotal->execute($paramDivisi);
$totalPembimbing = (int) $stmtTotal->fetch()['c'];
$pg = paginasi($totalPembimbing, $_GET['halaman'] ?? 1, 20);
$stmtDaftar = $pdo->prepare("
    SELECT p.*, d.nama AS nama_divisi, c.nama_cabang,
           COUNT(m.id) AS jumlah_bimbingan,
           COALESCE(SUM(m.status = 'aktif'), 0) AS jumlah_bimbingan_aktif
    FROM users p
    LEFT JOIN users m ON m.pembimbing_id = p.id AND m.role = 'mahasiswa'
    LEFT JOIN divisi d ON d.id = p.divisi_id
    LEFT JOIN cabang c ON c.id = p.cabang_id
    WHERE p.role = 'pembimbing'{$whereDivisi}
    GROUP BY p.id
    ORDER BY p.nama ASC
    LIMIT {$pg['perHalaman']} OFFSET {$pg['offset']}
");
$stmtDaftar->execute($paramDivisi);
$daftar = $stmtDaftar->fetchAll();

$jumlahTanpaPembimbing = (int) $pdo->query("SELECT COUNT(*) c FROM users WHERE role='mahasiswa' AND status='aktif' AND pembimbing_id IS NULL")->fetch()['c'];
?>
<?php
/**
 * Field pilihan cabang tempat pembimbing bertugas (informasi penempatan; pembimbing
 * tidak melakukan absen, jadi cabang yang jam kerjanya belum diatur pun boleh dipilih).
 */
function fieldCabangPembimbing($nilai) {
    $daftarCabangPb = daftarCabang();
    ob_start(); ?>
          <div class="mb-3">
            <label class="form-label">Cabang tempat bertugas <a href="pengaturan.php#cabang" class="small fw-normal ms-1">(kelola cabang)</a></label>
            <?php if (!$daftarCabangPb): ?>
              <p class="alert alert-warning py-2 small mb-0">Belum ada cabang. Tambahkan dulu lewat menu <a href="pengaturan.php#cabang" class="alert-link">Atur → Cabang, Lokasi & Jam Kerja</a>.</p>
            <?php else: ?>
              <select name="cabang_id" class="form-select" required>
                <option value="">— Pilih cabang —</option>
                <?php foreach ($daftarCabangPb as $cb): ?>
                  <option value="<?= $cb['id'] ?>" <?= $nilai !== '' && (int) $nilai === (int) $cb['id'] ? 'selected' : '' ?>><?= e($cb['nama_cabang']) ?></option>
                <?php endforeach; ?>
              </select>
              <p class="text-muted small mt-1 mb-0">Sebagai informasi penempatan; pembimbing tetap bisa membimbing mahasiswa cabang lain.</p>
            <?php endif; ?>
          </div>
    <?php return ob_get_clean();
}

/**
 * Field pilihan divisi/bagian untuk form tambah & edit pembimbing.
 * Wajib dipilih selama sudah ada minimal 1 divisi; kalau daftar divisi masih kosong,
 * field-nya diganti tautan ke menu Kelola Divisi.
 */
function fieldDivisi($nilai) {
    $daftarDivisi = daftarDivisi();
    ob_start(); ?>
          <div class="mb-3">
            <label class="form-label">Divisi/Bagian <a href="divisi.php" class="small fw-normal ms-1">(kelola divisi)</a></label>
            <?php if (!$daftarDivisi): ?>
              <p class="alert alert-warning py-2 small mb-0">Belum ada divisi. Tambahkan dulu lewat menu <a href="divisi.php" class="alert-link">Kelola Divisi</a>, lalu divisinya bisa dipilih di sini.</p>
            <?php else: ?>
              <select name="divisi_id" class="form-select" required>
                <option value="">— Pilih divisi/bagian —</option>
                <?php foreach ($daftarDivisi as $id => $namaDivisi): ?>
                  <option value="<?= $id ?>" <?= $nilai !== '' && (int) $nilai === $id ? 'selected' : '' ?>><?= e($namaDivisi) ?></option>
                <?php endforeach; ?>
              </select>
              <p class="text-muted small mt-1 mb-0">Ditampilkan di daftar pembimbing dan di menu Profil mahasiswa bimbingannya.</p>
            <?php endif; ?>
          </div>
    <?php return ob_get_clean();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Kelola Pembimbing — Admin</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
    <div class="alert alert-info small mb-3">
      👥 Pembimbing hanya bisa memantau & memproses mahasiswa bimbingannya, tanpa akses pengaturan.
      Mahasiswa bimbingan ditetapkan lewat menu <a href="mahasiswa.php" class="alert-link">Mahasiswa</a> → Edit.
    </div>

    <?php if ($jumlahTanpaPembimbing > 0): ?>
      <div class="alert alert-warning small mb-3">
        ⚠️ Ada <b><?= $jumlahTanpaPembimbing ?></b> mahasiswa aktif yang belum punya pembimbing.
        <a href="mahasiswa.php?pembimbing=none" class="alert-link">Lihat daftarnya</a>.
      </div>
    <?php endif; ?>

    <div class="card mb-3">
      <div class="card-body">
      <?php if ($error && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])): ?>
        <div class="alert alert-danger small"><?= e($error) ?></div>
      <?php endif; ?>
      <?php if ($success && isset($_GET['terhapus'])): ?>
        <div class="alert alert-success small"><?= e($success) ?></div>
      <?php endif; ?>
      <?php if ($editData): ?>
        <p class="text-primary fw-semibold small mb-1">Edit akun</p>
        <h2 class="h6 fw-bold mb-2">Ubah Data: <?= e($editData['nama']) ?></h2>
        <form method="POST" style="margin-top:12px;">
          <?= csrfField() ?>
          <input type="hidden" name="id" value="<?= $editData['id'] ?>">
          <div class="mb-3"><label class="form-label">Nama lengkap</label><input type="text" name="nama" value="<?= e($editData['nama']) ?>" required class="form-control"></div>
          <div class="mb-3"><label class="form-label">Username (dipakai untuk login)</label><input type="text" name="username" value="<?= e($editData['identifier']) ?>" required class="form-control"></div>
          <div class="mb-3"><label class="form-label">No. HP (opsional, ditampilkan ke mahasiswa bimbingan)</label><input type="text" name="no_hp" value="<?= e($editData['no_hp']) ?>" class="form-control"></div>
          <?= fieldDivisi($editData['divisi_id'] === null ? '' : (int) $editData['divisi_id']) ?>
          <?= fieldCabangPembimbing($editData['cabang_id'] === null ? '' : (int) $editData['cabang_id']) ?>

          <?php if ($error): ?><p class="alert alert-danger py-2 small"><?= e($error) ?></p><?php endif; ?>

          <div class="d-flex gap-2">
            <button type="submit" name="edit" value="1" class="btn btn-primary">Simpan Perubahan</button>
            <a href="kelola_pembimbing.php" class="btn btn-secondary">Batal</a>
          </div>
        </form>
      <?php else: ?>
        <p class="text-primary fw-semibold small mb-1">Tambah akun</p>
        <h2 class="h6 fw-bold mb-2">Pembimbing Baru</h2>
        <form method="POST" style="margin-top:12px;">
          <?= csrfField() ?>
          <div class="mb-3"><label class="form-label">Nama lengkap</label><input type="text" name="nama" required class="form-control"></div>
          <div class="mb-3"><label class="form-label">Username (dipakai untuk login)</label><input type="text" name="username" required class="form-control"></div>
          <div class="mb-3"><label class="form-label">No. HP (opsional, ditampilkan ke mahasiswa bimbingan)</label><input type="text" name="no_hp" class="form-control"></div>
          <?= fieldDivisi('') ?>
          <?= fieldCabangPembimbing('') ?>
          <div class="mb-3">
            <label class="form-label">Password awal (kosongkan = digenerate otomatis secara acak)</label>
            <input type="text" name="password_awal" placeholder="Kosongkan untuk password acak otomatis" class="form-control">
          </div>
          <p class="text-muted small" style="margin-top:-4px;font-size:12px;">Kalau diisi manual: min. 8 karakter, memuat huruf besar, kecil, angka & simbol. Ditampilkan <b>sekali saja</b>.</p>

          <?php if ($error): ?><p class="alert alert-danger py-2 small"><?= e($error) ?></p><?php endif; ?>
          <?php if ($success): ?><p class="alert alert-success py-2 small"><?= e($success) ?></p><?php endif; ?>

          <button type="submit" name="tambah" value="1" class="btn btn-primary mt-2">Tambah Pembimbing</button>
        </form>
      <?php endif; ?>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-2">Daftar pembimbing (<?= $totalPembimbing ?>)</p>

      <?php if (daftarDivisi()): ?>
      <form method="GET" class="row g-2 align-items-end mb-3">
        <div class="col-8 col-md-5">
          <label class="form-label small">Filter divisi/bagian</label>
          <select name="divisi" class="form-select form-select-sm" onchange="this.form.submit()">
            <option value="">— Semua divisi —</option>
            <option value="none" <?= $filterDivisi === 'none' ? 'selected' : '' ?>>Belum diatur</option>
            <?php foreach (daftarDivisi() as $idDivisi => $namaDivisi): ?>
              <option value="<?= $idDivisi ?>" <?= $filterDivisi === $idDivisi ? 'selected' : '' ?>><?= e($namaDivisi) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-4 col-md-3">
          <noscript><button type="submit" class="btn btn-secondary btn-sm">Filter</button></noscript>
          <?php if ($filterDivisi !== ''): ?><a href="kelola_pembimbing.php" class="btn btn-outline-secondary btn-sm">Reset</a><?php endif; ?>
        </div>
      </form>
      <?php endif; ?>

      <div class="list-group list-group-flush daftar-gulir" style="max-height:520px;">
        <?php if (empty($daftar)): ?>
          <div class="text-muted small text-center py-3"><?= $filterDivisi !== '' ? 'Tidak ada pembimbing pada divisi yang dipilih.' : 'Belum ada akun pembimbing.' ?></div>
        <?php else: foreach ($daftar as $p): ?>
          <div class="list-group-item px-0">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <b><?= e($p['nama']) ?></b>
              <span class="badge text-bg-<?= $p['status']==='aktif' ? 'success' : 'danger' ?>"><?= $p['status']==='aktif' ? 'Aktif' : 'Nonaktif' ?></span>
            </div>
            <div class="small text-muted">Username: <?= e($p['identifier']) ?><?= $p['no_hp'] ? ' · HP: ' . e($p['no_hp']) : '' ?></div>
            <div class="small text-muted">Divisi: <b><?= $p['nama_divisi'] ? e($p['nama_divisi']) : '<span class="text-danger">Belum diatur</span>' ?></b></div>
            <div class="small text-muted">Cabang: <b><?= $p['nama_cabang'] ? e($p['nama_cabang']) : '<span class="text-danger">Belum diatur</span>' ?></b></div>
            <div class="small text-muted">
              Mahasiswa bimbingan: <b><?= (int) $p['jumlah_bimbingan'] ?></b> (<?= (int) $p['jumlah_bimbingan_aktif'] ?> aktif)
              <?php if ($p['jumlah_bimbingan'] > 0): ?>
                · <a href="mahasiswa.php?pembimbing=<?= $p['id'] ?>">lihat</a>
              <?php endif; ?>
              <?php if ($p['jumlah_bimbingan_aktif'] > 0): ?>
                <br><span class="text-muted">Belum bisa dihapus selama masih ada mahasiswa aktif yang memakainya.</span>
              <?php endif; ?>
            </div>

            <div class="d-flex flex-wrap gap-2 mt-2">
              <a href="kelola_pembimbing.php?edit=<?= $p['id'] ?>" class="btn btn-outline-primary btn-sm">✏️ Edit</a>
              <form method="POST" style="margin:0;" data-konfirmasi="Ubah status aktif/nonaktif pembimbing ini? Pembimbing nonaktif langsung keluar dari aplikasi dan tidak bisa login." data-konfirmasi-judul="Ubah status pembimbing" data-konfirmasi-ya="Ya, ubah">
                <?= csrfField() ?>
                <input type="hidden" name="toggle" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-secondary btn-sm"><?= $p['status']==='aktif' ? 'Nonaktifkan' : 'Aktifkan' ?></button>
              </form>
              <button type="button" class="btn btn-outline-secondary btn-sm btn-reset-pass" data-id="<?= $p['id'] ?>" data-nama="<?= e($p['nama']) ?>">Reset Password</button>
              <?php if ($p['jumlah_bimbingan_aktif'] > 0): ?>
                <button type="button" class="btn btn-outline-danger btn-sm" disabled
                        title="Masih dipakai <?= (int) $p['jumlah_bimbingan_aktif'] ?> mahasiswa aktif — alihkan dulu ke pembimbing lain">Hapus</button>
              <?php else: ?>
                <form method="POST" style="margin:0;" data-konfirmasi="Hapus akun pembimbing ini?<?= $p['jumlah_bimbingan'] > 0 ? ' ' . (int) $p['jumlah_bimbingan'] . ' mahasiswa nonaktif (magang selesai) yang pernah dibimbingnya akan menjadi TANPA pembimbing — data absensi &amp; laporan mereka tetap utuh.' : '' ?> Tindakan ini tidak bisa dibatalkan." data-konfirmasi-judul="Hapus akun pembimbing" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1">
                  <?= csrfField() ?>
                  <input type="hidden" name="hapus" value="<?= $p['id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <?php if ($pg['totalHalaman'] > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
          <?php if ($pg['halaman'] > 1): ?>
            <a href="<?= urlHalaman($pg['halaman'] - 1) ?>" class="btn btn-outline-secondary btn-sm">← Sebelumnya</a>
          <?php else: ?><span></span><?php endif; ?>
          <span class="text-muted small">Halaman <?= $pg['halaman'] ?> dari <?= $pg['totalHalaman'] ?></span>
          <?php if ($pg['halaman'] < $pg['totalHalaman']): ?>
            <a href="<?= urlHalaman($pg['halaman'] + 1) ?>" class="btn btn-outline-secondary btn-sm">Berikutnya →</a>
          <?php else: ?><span></span><?php endif; ?>
        </div>
      <?php endif; ?>
      </div>
    </div>

    <a href="pengaturan.php" class="btn btn-outline-secondary mb-3">← Kembali ke Pengaturan</a>
</div>

<!-- Form tersembunyi untuk kirim reset password beserta password baru yang diketik admin -->
<form id="formReset" method="POST" style="display:none;">
  <?= csrfField() ?>
  <input type="hidden" name="reset" value="1">
  <input type="hidden" name="reset_id" id="resetId" value="">
  <input type="hidden" name="password_baru" id="resetPasswordBaru" value="">
</form>

<?php include __DIR__ . '/../includes/foot.php'; ?>
<script>
document.querySelectorAll('.btn-reset-pass').forEach(function (btn) {
  btn.addEventListener('click', async function () {
    var id = btn.dataset.id;
    var nama = btn.dataset.nama;
    // Input & konfirmasi memakai popup tengah layar (lihat includes/dialog.php)
    var pass = await Dialog.prompt({
      judul: 'Reset password',
      pesan: 'Password baru untuk ' + nama + ':\n(Kosongkan lalu klik Lanjutkan untuk digenerate otomatis secara acak)',
      placeholder: 'Kosongkan = password acak otomatis'
    });
    if (pass === null || pass === false) return; // dibatalkan
    pass = pass.trim();
    if (pass) {
      var kurangSyarat = [];
      if (pass.length < 8) kurangSyarat.push('minimal 8 karakter');
      if (!/[A-Z]/.test(pass)) kurangSyarat.push('huruf besar');
      if (!/[a-z]/.test(pass)) kurangSyarat.push('huruf kecil');
      if (!/[0-9]/.test(pass)) kurangSyarat.push('angka');
      if (!/[^A-Za-z0-9]/.test(pass)) kurangSyarat.push('simbol');
      if (kurangSyarat.length) {
        await Dialog.error('Kata sandi kurang: ' + kurangSyarat.join(', ') + '. Kosongkan saja kalau mau digenerate otomatis.', 'Password terlalu lemah');
        return;
      }
    }
    var lanjutReset = await Dialog.konfirmasi({
      judul: 'Reset password',
      pesan: pass
        ? ('Reset password ' + nama + ' ke "' + pass + '"?')
        : ('Reset password ' + nama + ' ke password acak baru? Password barunya ditampilkan sekali setelah ini.'),
      labelYa: 'Ya, reset'
    });
    if (!lanjutReset) return;
    document.getElementById('resetId').value = id;
    document.getElementById('resetPasswordBaru').value = pass;
    document.getElementById('formReset').submit();
  });
});
</script>
</body>
</html>
