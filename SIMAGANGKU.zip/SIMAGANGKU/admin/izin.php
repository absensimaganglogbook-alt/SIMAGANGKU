<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin(['admin', 'pembimbing']);
$pdo = getDB();

// Admin melihat & memproses semua izin; pembimbing hanya izin mahasiswa bimbingannya.
[$sqlScope, $paramScope] = scopeMahasiswa('u');

// Khusus pembimbing: cabang tidak dipilih manual — sistem memakai cabang pada akunnya,
// dan datanya otomatis dibatasi ke mahasiswa bimbingan di cabang tersebut
// (sama seperti halaman Absen Manual).
$cabangPembimbing = cabangOtomatisPembimbing();
if (isPembimbing()) {
    if ($cabangPembimbing) {
        $sqlScope .= " AND u.cabang_id = ?";
        $paramScope[] = (int) $cabangPembimbing['id'];
    } else {
        // Cabang pembimbing belum diatur admin → belum ada pengajuan yang boleh diproses.
        $sqlScope .= " AND 1=0";
    }
}
$pemrosesId = (int) currentUser()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'], $_POST['id'])) {
    verifikasiCsrf();
    $id = (int)$_POST['id'];

    // Ambil izin HANYA kalau termasuk wewenang user ini. Pembimbing yang mengirim id
    // izin milik mahasiswa bimbingan orang lain (mis. lewat DevTools) tidak akan
    // menemukan datanya, jadi tidak ada yang diubah.
    $stmtCek = $pdo->prepare("SELECT i.id, i.status, i.tanggal_selesai, i.disetujui_otomatis FROM izin i JOIN users u ON u.id = i.user_id WHERE i.id = ?{$sqlScope}");
    $stmtCek->execute(array_merge([$id], $paramScope));
    $izinTarget = $stmtCek->fetch();

    // $hasilAksi dipakai untuk menampilkan popup hasil setelah redirect.
    $hasilAksi = 'gagal';
    if ($izinTarget) {
        $ubahStatus = $pdo->prepare("UPDATE izin SET status = ?, diproses_oleh_id = ? WHERE id = ?");
        if ($_POST['aksi'] === 'approve' && $izinTarget['status'] === 'pending') {
            $ubahStatus->execute(['approved', $pemrosesId, $id]);
            $hasilAksi = 'approve';
        } elseif ($_POST['aksi'] === 'reject' && ($izinTarget['status'] === 'pending'
                  || ($izinTarget['status'] === 'approved' && !empty($izinTarget['disetujui_otomatis'])))) {
            // Izin yang disetujui OTOMATIS oleh sistem tetap boleh ditolak pembimbing/admin
            // kapan pun (mis. ternyata alasannya tidak wajar). Penanda "otomatis" dilepas
            // supaya riwayatnya jelas: keputusan akhirnya dari pembimbing/admin.
            $pdo->prepare("UPDATE izin SET status = 'rejected', diproses_oleh_id = ?, disetujui_otomatis = 0 WHERE id = ?")
                ->execute([$pemrosesId, $id]);
            $hasilAksi = !empty($izinTarget['disetujui_otomatis']) ? 'tolak_otomatis' : 'reject';
        } elseif ($_POST['aksi'] === 'batalkan' && $izinTarget['status'] === 'approved'
                  && $izinTarget['tanggal_selesai'] >= date('Y-m-d')) {
            // kembalikan ke pending, hanya kalau tanggal selesai belum lewat
            $ubahStatus->execute(['pending', $pemrosesId, $id]);
            $hasilAksi = 'batalkan';
        }
    }
    $balikKe = panelBase() . '/izin.php?';
    if ($izinTarget && $hasilAksi !== 'gagal') {
        $stmtNamaIzin = $pdo->prepare("SELECT u.nama FROM izin i JOIN users u ON u.id = i.user_id WHERE i.id = ?");
        $stmtNamaIzin->execute([$id]);
        catatAktivitas('proses_izin', 'izin', $id, $stmtNamaIzin->fetchColumn() ?: null,
            ['approve' => 'Disetujui', 'reject' => 'Ditolak', 'tolak_otomatis' => 'Izin otomatis ditolak', 'batalkan' => 'Persetujuan dibatalkan'][$hasilAksi] ?? $hasilAksi);
    }

    $qs = ['hasil' => $hasilAksi];
    if (kategoriDariInput($_POST['kategori'] ?? '') !== '') {
        $qs['kategori'] = kategoriDariInput($_POST['kategori']);
    }
    if (!empty($_POST['cabang'])) {
        $qs['cabang'] = (int)$_POST['cabang'];
    }
    if (!empty($_POST['halaman'])) {
        $qs['halaman'] = (int)$_POST['halaman'];
    }
    redirect($balikKe . http_build_query($qs));
}

// ---- Pesan hasil aksi (tampil sebagai popup) ----
$success = '';
$error = '';
switch ($_GET['hasil'] ?? '') {
    case 'approve':  $success = 'Pengajuan izin/sakit berhasil disetujui.'; break;
    case 'reject':   $success = 'Pengajuan izin/sakit berhasil ditolak.'; break;
    case 'tolak_otomatis': $success = 'Izin/sakit yang tadinya disetujui otomatis berhasil ditolak. Hari itu kembali dihitung sesuai absensinya.'; break;
    case 'batalkan': $success = 'Persetujuan izin berhasil dibatalkan, statusnya kembali menunggu.'; break;
    case 'gagal':    $error = 'Pengajuan tidak bisa diproses. Mungkin statusnya sudah berubah atau bukan wewenangmu. Muat ulang halaman lalu coba lagi.'; break;
}

// ---- Filter kategori & cabang mahasiswa ----
$filterKategori = kategoriDariInput($_GET['kategori'] ?? ''); // '' = semua kategori
// Filter cabang hanya untuk admin; pembimbing memakai cabang akunnya (lihat di atas).
$filterCabang = (!isPembimbing() && isset($_GET['cabang']) && $_GET['cabang'] !== '') ? (int)$_GET['cabang'] : '';

$sqlIzin = "SELECT i.*, u.nama, u.kategori_id, c.nama_cabang, pb.nama AS nama_pembimbing, p.nama AS nama_pemroses, p.role AS role_pemroses FROM izin i JOIN users u ON u.id=i.user_id LEFT JOIN cabang c ON c.id = u.cabang_id LEFT JOIN users pb ON pb.id = u.pembimbing_id LEFT JOIN users p ON p.id = i.diproses_oleh_id";
$whereIzin = ['1=1' . $sqlScope];
$paramsIzin = $paramScope;
if ($filterKategori !== '') {
    $whereIzin[] = "u.kategori_id = ?";
    $paramsIzin[] = $filterKategori;
}
if ($filterCabang !== '') {
    $whereIzin[] = "u.cabang_id = ?";
    $paramsIzin[] = $filterCabang;
}
if ($whereIzin) {
    $sqlIzin .= " WHERE " . implode(' AND ', $whereIzin);
}
// Bawaannya bulan berjalan; pengajuan berstatus MENUNGGU selalu tampil apa pun bulannya.
$bulan = bulanDipilih();
[$awalBulan, $akhirBulan] = rentangBulan($bulan);
$sqlIzin .= " AND (i.status='pending' OR (i.tanggal_mulai <= ? AND i.tanggal_selesai >= ?))";
$paramsIzin[] = $akhirBulan;
$paramsIzin[] = $awalBulan;

$stmtAwalIzin = $pdo->prepare("SELECT DATE_FORMAT(MIN(i.tanggal_mulai), '%Y-%m') FROM izin i JOIN users u ON u.id=i.user_id WHERE 1=1{$sqlScope}");
$stmtAwalIzin->execute($paramScope);
$daftarTahun = daftarTahunPilihan(substr((string) $stmtAwalIzin->fetchColumn(), 0, 4), substr($bulan, 0, 4));

$sqlIzin .= " ORDER BY (i.status='pending') DESC, i.tanggal_mulai DESC";

// ---- Pagination: hitung total dulu (dengan filter yang sama), baru ambil 1 halaman ----
$sqlHitungIzin = str_replace('SELECT i.*, u.nama, u.kategori_id, c.nama_cabang, pb.nama AS nama_pembimbing, p.nama AS nama_pemroses, p.role AS role_pemroses', 'SELECT COUNT(*) c', $sqlIzin);
$stmtHitungIzin = $pdo->prepare($sqlHitungIzin);
$stmtHitungIzin->execute($paramsIzin);
$totalIzin = (int)$stmtHitungIzin->fetch()['c'];

$pg = paginasi($totalIzin, $_GET['halaman'] ?? 1, 15);
$sqlIzin .= " LIMIT {$pg['perHalaman']} OFFSET {$pg['offset']}";

$stmtIzin = $pdo->prepare($sqlIzin);
$stmtIzin->execute($paramsIzin);
$daftar = $stmtIzin->fetchAll();

$daftarCabangIzin = daftarCabang();

$statusLabel = ['pending' => 'Menunggu', 'approved' => 'Disetujui', 'rejected' => 'Ditolak'];
$statusClass = ['pending' => 'pending', 'approved' => 'ok', 'rejected' => 'bad'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Persetujuan Izin — Admin</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>

<div class="container pb-5">
  <h1 class="h4 fw-bold mb-3">Persetujuan Izin/Sakit</h1>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Semua pengajuan</p>
      <h2 class="h6 fw-bold mb-1">Izin / Sakit <?= e(namaBulanID($bulan)) ?> (<?= $totalIzin ?>)</h2>
      <p class="text-muted small mb-3">Pengajuan yang masih menunggu selalu ditampilkan, walau tanggalnya di bulan lain.</p>

      <?php if (isPembimbing()): ?>
        <p class="small mb-2">
          <span class="badge text-bg-info">🏢 Cabang: <?= e($cabangPembimbing['nama_cabang'] ?? 'Belum diatur') ?></span>
          <span class="text-muted">— diambil otomatis dari akunmu, jadi tidak perlu dipilih lagi.</span>
        </p>
        <?php if (!$cabangPembimbing): ?>
          <p class="text-muted small">⚠️ Cabang pada akunmu belum diatur admin, jadi belum ada pengajuan yang tampil di sini. Hubungi admin untuk mengaturnya.</p>
        <?php endif; ?>
      <?php endif; ?>
      <form method="GET" class="row g-2 align-items-end mb-3">
        <div class="col-12 col-md-4">
          <?= dropdownBulan($daftarTahun, $bulan) ?>
        </div>
        <div class="col-12 col-md-4">
          <label class="form-label small">Filter kategori mahasiswa</label>
          <select name="kategori" class="form-select">
            <option value="">— Semua kategori —</option>
            <?php foreach (daftarKategori() as $kode => $label): ?>
              <option value="<?= e($kode) ?>" <?= $filterKategori === $kode ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php if (!isPembimbing()): ?>
        <div class="col-12 col-md-4">
          <label class="form-label small">Filter cabang</label>
          <select name="cabang" class="form-select">
            <option value="">— Semua cabang —</option>
            <?php foreach ($daftarCabangIzin as $c): ?>
              <option value="<?= $c['id'] ?>" <?= $filterCabang == $c['id'] ? 'selected' : '' ?>><?= e($c['nama_cabang']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endif; ?>
        <div class="col-12 col-md-4 d-flex gap-2">
          <button type="submit" class="btn btn-secondary flex-fill">Terapkan</button>
          <?php if ($filterKategori !== '' || $filterCabang !== ''): ?>
            <a href="izin.php" class="btn btn-outline-secondary flex-fill">Reset</a>
          <?php endif; ?>
        </div>
      </form>

      <div class="list-group list-group-flush" style="max-height:560px;overflow-y:auto;">
        <?php if (empty($daftar)): ?>
          <div class="text-muted small text-center py-3">Tidak ada pengajuan izin/sakit di <?= e(namaBulanID($bulan)) ?><?= ($filterKategori !== '' || $filterCabang !== '') ? ' untuk filter yang dipilih' : '' ?>. Pilih bulan lain di atas untuk melihat data lainnya.</div>
        <?php else: foreach ($daftar as $i): ?>
          <div class="list-group-item px-0">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <b class="small"><?= e($i['nama']) ?> · <?= $i['jenis']==='sakit'?'Sakit':'Izin' ?></b>
              <?php if (!empty($i['disetujui_otomatis'])): ?><span class="badge text-bg-light text-dark">otomatis</span> <?php endif; ?>
              <span class="badge text-bg-<?= ['pending'=>'warning','approved'=>'success','rejected'=>'danger'][$i['status']] ?>"><?= $statusLabel[$i['status']] ?></span>
            </div>
            <div class="small text-muted">
              <?= e(labelKategori($i['kategori_id'])) ?><?= $i['nama_cabang'] ? ' · '.e($i['nama_cabang']) : '' ?>
              <?php if (!isPembimbing()): // pembimbing hanya melihat bimbingannya sendiri, jadi tidak perlu diulang ?>
                · Pembimbing: <b><?= e($i['nama_pembimbing'] ?: 'Belum ada') ?></b>
              <?php endif; ?>
            </div>
            <div class="small text-muted"><?= e(formatRentangTanggal($i['tanggal_mulai'], $i['tanggal_selesai'])) ?></div>
            <div class="small mt-1"><?= e($i['keterangan']) ?></div>
            <?php if (!empty($i['disetujui_otomatis'])): ?>
              <div class="small text-muted mt-1">Disetujui otomatis oleh sistem (izin/sakit 1 hari). Kamu tetap bisa menolaknya kalau dirasa tidak wajar.</div>
            <?php elseif ($i['status'] !== 'pending' && $i['nama_pemroses']): ?>
              <div class="small text-muted mt-1">Diproses oleh: <?= e($i['nama_pemroses']) ?> (<?= e(labelRole($i['role_pemroses'])) ?>)</div>
            <?php endif; ?>
            <?php if ($i['file_lampiran']): ?>
              <?= htmlLampiranIzin($i['file_lampiran']) ?>
            <?php endif; ?>

            <?php if ($i['status']==='pending'): ?>
              <div class="d-flex gap-2 mt-2">
                <form method="POST" class="m-0">
                  <?= csrfField() ?>
                  <input type="hidden" name="aksi" value="approve">
                  <input type="hidden" name="id" value="<?= $i['id'] ?>">
                  <input type="hidden" name="kategori" value="<?= e($filterKategori) ?>">
                  <input type="hidden" name="cabang" value="<?= e($filterCabang) ?>">
                  <input type="hidden" name="halaman" value="<?= $pg['halaman'] ?>">
                  <button type="submit" class="btn btn-primary btn-sm">Setujui</button>
                </form>
                <form method="POST" class="m-0" data-konfirmasi="Tolak pengajuan izin/sakit ini?" data-konfirmasi-judul="Tolak pengajuan" data-konfirmasi-ya="Ya, tolak" data-konfirmasi-bahaya="1">
                  <?= csrfField() ?>
                  <input type="hidden" name="aksi" value="reject">
                  <input type="hidden" name="id" value="<?= $i['id'] ?>">
                  <input type="hidden" name="kategori" value="<?= e($filterKategori) ?>">
                  <input type="hidden" name="cabang" value="<?= e($filterCabang) ?>">
                  <input type="hidden" name="halaman" value="<?= $pg['halaman'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Tolak</button>
                </form>
              </div>
            <?php elseif ($i['status']==='approved'): ?>
              <div class="d-flex flex-wrap gap-2 mt-2">
                <?php if (!empty($i['disetujui_otomatis'])): ?>
                  <form method="POST" class="m-0" data-konfirmasi="Tolak izin/sakit ini? Walau tadinya disetujui otomatis, hari itu akan dihitung sesuai absensinya (tidak hadir kalau mahasiswa tidak absen)." data-konfirmasi-judul="Tolak izin otomatis" data-konfirmasi-ya="Ya, tolak" data-konfirmasi-bahaya="1">
                    <?= csrfField() ?>
                    <input type="hidden" name="aksi" value="reject">
                    <input type="hidden" name="id" value="<?= $i['id'] ?>">
                    <input type="hidden" name="kategori" value="<?= e($filterKategori) ?>">
                    <input type="hidden" name="cabang" value="<?= e($filterCabang) ?>">
                    <input type="hidden" name="halaman" value="<?= $pg['halaman'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm">Tolak</button>
                  </form>
                <?php endif; ?>
                <?php if ($i['tanggal_selesai'] >= date('Y-m-d')): ?>
                  <form method="POST" class="m-0" data-konfirmasi="Batalkan persetujuan izin ini? Statusnya kembali jadi menunggu." data-konfirmasi-judul="Batalkan persetujuan" data-konfirmasi-ya="Ya, batalkan">
                    <?= csrfField() ?>
                    <input type="hidden" name="aksi" value="batalkan">
                    <input type="hidden" name="id" value="<?= $i['id'] ?>">
                    <input type="hidden" name="kategori" value="<?= e($filterKategori) ?>">
                    <input type="hidden" name="cabang" value="<?= e($filterCabang) ?>">
                    <input type="hidden" name="halaman" value="<?= $pg['halaman'] ?>">
                    <button type="submit" class="btn btn-<?= !empty($i['disetujui_otomatis']) ? 'outline-secondary' : 'danger' ?> btn-sm">↩️ Batalkan Persetujuan</button>
                  </form>
                <?php elseif (empty($i['disetujui_otomatis'])): ?>
                  <span class="text-muted small">Sudah lewat — tidak bisa dibatalkan</span>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <?php if ($pg['totalHalaman'] > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
          <?php if ($pg['halaman'] > 1): ?>
            <a href="<?= urlHalaman($pg['halaman'] - 1) ?>" class="btn btn-outline-secondary btn-sm">← Sebelumnya</a>
          <?php else: ?><span></span><?php endif; ?>
          <span class="text-muted small">Halaman <?= $pg['halaman'] ?> dari <?= $pg['totalHalaman'] ?></span>
          <?php if ($pg['halaman'] < $pg['totalHalaman']): ?>
            <a href="<?= urlHalaman($pg['halaman'] + 1) ?>" class="btn btn-outline-secondary btn-sm">Berikutnya →</a>
          <?php else: ?><span></span><?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
