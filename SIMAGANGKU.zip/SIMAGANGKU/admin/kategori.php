<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('admin');
$pdo = getDB();
$error = '';
$success = '';

/**
 * Kelola kategori magang (khusus admin): tambah, ubah, hapus.
 *
 * Tiap kategori WAJIB punya prefiks kode username (2–5 huruf A–Z). Prefiks ini
 * dipakai tombol "Generate Otomatis" di form mahasiswa untuk membuat username
 * berurutan, mis. prefiks PKL → PKL001, PKL002, dst.
 */

/**
 * Cek bentrok nama/prefiks dengan kategori lain. Mengembalikan pesan error atau null.
 * $kecualiId dipakai saat edit, supaya kategori tidak dianggap bentrok dengan dirinya sendiri.
 */
function cekDuplikatKategori($pdo, $nama, $prefiks, $kecualiId = 0) {
    $stmt = $pdo->prepare("SELECT nama, prefiks_kode FROM kategori WHERE (nama = ? OR prefiks_kode = ?) AND id <> ?");
    $stmt->execute([$nama, $prefiks, (int) $kecualiId]);
    foreach ($stmt->fetchAll() as $row) {
        // Perbandingan nama di SQL sudah tidak peka huruf besar/kecil (collation utf8mb4_unicode_ci),
        // jadi baris yang prefiksnya BERBEDA pasti ketemu karena namanya sama.
        if ($row['prefiks_kode'] === $prefiks) {
            return "Prefiks $prefiks sudah dipakai kategori \"{$row['nama']}\". Setiap kategori harus punya prefiks yang berbeda.";
        }
        return "Nama kategori \"{$row['nama']}\" sudah ada.";
    }
    return null;
}

/**
 * Ambil & rapikan input form kategori. Prefiks otomatis diubah jadi huruf besar.
 */
function inputKategori() {
    return [
        trim(preg_replace('/\s+/', ' ', $_POST['nama'] ?? '')),
        strtoupper(trim($_POST['prefiks_kode'] ?? '')),
    ];
}

function validasiInputKategori($nama, $prefiks) {
    if ($nama === '') return 'Nama kategori wajib diisi.';
    // Hitung per karakter (bukan per byte) tanpa butuh ekstensi mbstring.
    if (!preg_match('/^.{1,100}$/u', $nama)) return 'Nama kategori maksimal 100 karakter.';
    return validasiPrefiksKategori($prefiks);
}

// ---- Tambah ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    verifikasiCsrf();
    [$nama, $prefiks] = inputKategori();

    $error = validasiInputKategori($nama, $prefiks) ?? cekDuplikatKategori($pdo, $nama, $prefiks);
    if (!$error) {
        try {
            $pdo->prepare("INSERT INTO kategori (nama, prefiks_kode) VALUES (?, ?)")->execute([$nama, $prefiks]);
            catatAktivitas('tambah_data', 'kategori', $pdo->lastInsertId(), $nama, 'Prefiks: ' . $prefiks);
            redirect('/admin/kategori.php?ditambahkan=1');
        } catch (PDOException $e) {
            $error = 'Nama atau prefiks kategori sudah dipakai. Gunakan yang lain.';
        }
    }
}

// ---- Simpan hasil edit ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit'])) {
    verifikasiCsrf();
    $id = (int) ($_POST['id'] ?? 0);
    [$nama, $prefiks] = inputKategori();

    if (!ambilKategori($id)) {
        $error = 'Kategori tidak ditemukan.';
    } else {
        $error = validasiInputKategori($nama, $prefiks) ?? cekDuplikatKategori($pdo, $nama, $prefiks, $id);
    }
    if (!$error) {
        try {
            $pdo->prepare("UPDATE kategori SET nama = ?, prefiks_kode = ? WHERE id = ?")->execute([$nama, $prefiks, $id]);
            catatAktivitas('ubah_data', 'kategori', $id, $nama, 'Prefiks: ' . $prefiks);
            redirect('/admin/kategori.php?tersimpan=1');
        } catch (PDOException $e) {
            $error = 'Nama atau prefiks kategori sudah dipakai. Gunakan yang lain.';
        }
    }
}

// ---- Hapus ----
// Kategori yang masih dipakai mahasiswa (aktif maupun nonaktif) tidak boleh dihapus,
// supaya data & laporan lama tidak kehilangan kategorinya. Database juga menjaga ini
// lewat foreign key ON DELETE RESTRICT.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {
    verifikasiCsrf();
    $id = (int) $_POST['hapus'];
    $kategori = ambilKategori($id);
    $stmtPakai = $pdo->prepare("SELECT COUNT(*) FROM users WHERE kategori_id = ?");
    $stmtPakai->execute([$id]);
    $jumlahPakai = (int) $stmtPakai->fetchColumn();

    if (!$kategori) {
        $error = 'Kategori tidak ditemukan.';
    } elseif ($jumlahPakai > 0) {
        $error = "Kategori \"{$kategori['nama']}\" masih dipakai $jumlahPakai mahasiswa, jadi belum bisa dihapus. Pindahkan dulu mahasiswanya ke kategori lain lewat menu Mahasiswa → Edit.";
    } else {
        try {
            $pdo->prepare("DELETE FROM kategori WHERE id = ?")->execute([$id]);
            catatAktivitas('hapus_data', 'kategori', $id, $kategori['nama'], 'Prefiks: ' . $kategori['prefiks_kode']);
            redirect('/admin/kategori.php?terhapus=1');
        } catch (PDOException $e) {
            $error = 'Kategori tidak bisa dihapus karena masih dipakai data lain.';
        }
    }
}

if (isset($_GET['ditambahkan'])) $success = 'Kategori baru berhasil ditambahkan dan langsung bisa dipilih di form mahasiswa.';
if (isset($_GET['tersimpan'])) $success = 'Perubahan kategori berhasil disimpan.';
if (isset($_GET['terhapus'])) $success = 'Kategori berhasil dihapus.';

$editData = isset($_GET['edit']) ? ambilKategori((int) $_GET['edit']) : null;

// Nilai form: pakai input terakhir kalau submit gagal, supaya admin tidak mengetik ulang.
$gagalSubmit = $error !== '' && $_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['tambah']) || isset($_POST['edit']));
$nilaiNama = $gagalSubmit ? ($_POST['nama'] ?? '') : ($editData['nama'] ?? '');
$nilaiPrefiks = $gagalSubmit ? strtoupper($_POST['prefiks_kode'] ?? '') : ($editData['prefiks_kode'] ?? '');

$daftar = $pdo->query("
    SELECT k.*,
           COUNT(u.id) AS jumlah_mahasiswa,
           COALESCE(SUM(u.status = 'aktif'), 0) AS jumlah_aktif
    FROM kategori k
    LEFT JOIN users u ON u.kategori_id = k.id AND u.role = 'mahasiswa'
    GROUP BY k.id
    ORDER BY k.nama ASC
")->fetchAll();

$jumlahTanpaKategori = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'mahasiswa' AND kategori_id IS NULL")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Kategori Magang — Admin</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
  <h1 class="h4 fw-bold mb-3">Kategori Magang</h1>

  <?php if ($jumlahTanpaKategori > 0): ?>
    <div class="alert alert-warning small">
      ⚠️ Ada <b><?= $jumlahTanpaKategori ?></b> mahasiswa yang kategorinya <b>belum diatur</b>
      (mis. dulu berkategori Magang Kemnaker yang sudah dihapus).
      <a href="mahasiswa.php?kategori=none" class="alert-link">Lihat & atur kategorinya</a>.
    </div>
  <?php endif; ?>

  <?php if ($success): ?><div class="alert alert-success small"><?= e($success) ?></div><?php endif; ?>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1"><?= $editData ? 'Ubah kategori' : 'Tambah kategori' ?></p>
      <h2 class="h6 fw-bold mb-3"><?= $editData ? 'Edit: ' . e($editData['nama']) : 'Kategori Baru' ?></h2>

      <form method="POST">
        <?= csrfField() ?>
        <?php if ($editData): ?><input type="hidden" name="id" value="<?= $editData['id'] ?>"><?php endif; ?>

        <div class="mb-3">
          <label class="form-label">Nama kategori</label>
          <input type="text" name="nama" class="form-control" maxlength="100" required
                 value="<?= e($nilaiNama) ?>" placeholder="Contoh: Magang Mandiri">
        </div>

        <div class="mb-3">
          <label class="form-label">Prefiks kode username</label>
          <input type="text" name="prefiks_kode" id="inputPrefiks" class="form-control text-uppercase" style="max-width:180px;"
                 minlength="2" maxlength="5" pattern="[A-Za-z]{2,5}" required
                 value="<?= e($nilaiPrefiks) ?>" placeholder="Contoh: MDR">
          <p class="text-muted small mt-1 mb-0">Wajib 2–5 huruf A–Z dan unik. Dipakai tombol "Generate Otomatis".</p>
          <?php if ($editData): ?>
            <p class="text-warning-emphasis small mt-1 mb-0">
              Mengubah prefiks tidak mengganti username mahasiswa yang sudah ada — hanya berlaku
              untuk username yang di-generate setelah ini.
            </p>
          <?php endif; ?>
        </div>

        <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= e($error) ?></div><?php endif; ?>

        <div class="d-flex gap-2">
          <?php if ($editData): ?>
            <button type="submit" name="edit" value="1" class="btn btn-primary">Simpan Perubahan</button>
            <a href="kategori.php" class="btn btn-secondary">Batal</a>
          <?php else: ?>
            <button type="submit" name="tambah" value="1" class="btn btn-primary">Tambah Kategori</button>
          <?php endif; ?>
        </div>
      </form>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Daftar</p>
      <h2 class="h6 fw-bold mb-3">Semua Kategori (<?= count($daftar) ?>)</h2>

      <?php if (empty($daftar)): ?>
        <div class="text-muted small text-center py-3">Belum ada kategori. Tambahkan minimal 1 kategori sebelum membuat akun mahasiswa.</div>
      <?php else: ?>
        <div class="table-responsive tabel-gulir" style="max-height:420px;">
          <table class="table table-sm align-middle mb-0">
            <thead>
              <tr>
                <th>Nama kategori</th>
                <th>Prefiks</th>
                <th>Username berikutnya</th>
                <th class="text-center">Mahasiswa</th>
                <th class="text-end">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($daftar as $k): ?>
                <tr>
                  <td class="fw-semibold"><?= e($k['nama']) ?></td>
                  <td><span class="badge text-bg-secondary"><?= e($k['prefiks_kode']) ?></span></td>
                  <td><code><?= e(generateKodeUnik($k['id'])) ?></code></td>
                  <td class="text-center">
                    <?php if ($k['jumlah_mahasiswa'] > 0): ?>
                      <a href="mahasiswa.php?kategori=<?= $k['id'] ?>"><?= (int) $k['jumlah_mahasiswa'] ?></a>
                      <span class="text-muted small">(<?= (int) $k['jumlah_aktif'] ?> aktif)</span>
                    <?php else: ?>
                      <span class="text-muted">0</span>
                    <?php endif; ?>
                  </td>
                  <td class="text-end">
                    <div class="d-inline-flex gap-1">
                      <a href="kategori.php?edit=<?= $k['id'] ?>" class="btn btn-outline-primary btn-sm">✏️ Edit</a>
                      <?php if ($k['jumlah_mahasiswa'] > 0): ?>
                        <button type="button" class="btn btn-outline-danger btn-sm" disabled
                                title="Masih dipakai <?= (int) $k['jumlah_mahasiswa'] ?> mahasiswa">Hapus</button>
                      <?php else: ?>
                        <form method="POST" class="m-0" data-konfirmasi="Hapus kategori ini? Tindakan ini tidak bisa dibatalkan." data-konfirmasi-judul="Hapus kategori" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1">
                          <?= csrfField() ?>
                          <input type="hidden" name="hapus" value="<?= $k['id'] ?>">
                          <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <p class="text-muted small mt-2 mb-0">Kategori yang masih dipakai mahasiswa tidak bisa dihapus.</p>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/foot.php'; ?>
<script>
// Pratinjau contoh username saat admin mengetik prefiks (huruf otomatis kapital, non-huruf dibuang).
(function () {
  var input = document.getElementById('inputPrefiks');
  var contoh = document.getElementById('contohKode');
  if (!input || !contoh) return;
  input.addEventListener('input', function () {
    var bersih = input.value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 5);
    if (input.value !== bersih) input.value = bersih;
    contoh.textContent = (bersih || 'XXX') + '001';
  });
})();
</script>
</body>
</html>
