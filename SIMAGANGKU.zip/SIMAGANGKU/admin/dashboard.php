<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/laporan_data.php';
requireLogin(['admin', 'pembimbing']);
$pdo = getDB();
$today = date('Y-m-d');

// Admin melihat semua mahasiswa; pembimbing hanya mahasiswa bimbingannya.
[$sqlScope, $paramScope] = scopeMahasiswa('u');
$labelPanel = labelRole(roleSekarang());

// Mahasiswa yang sertifikatnya perlu segera disiapkan.
$pengingatSertifikat = daftarPengingatSertifikat();

// Tandai / batalkan tanda "sertifikat sudah dibuat" (dari kartu pengingat di bawah).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sertifikat_id'])) {
    verifikasiCsrf();
    $galatSertifikat = ubahStatusSertifikat($_POST['sertifikat_id'], ($_POST['sertifikat_aksi'] ?? '') === 'tandai');
    redirect(panelBase() . '/dashboard.php' . ($galatSertifikat ? '?sertifikat=gagal' : '?sertifikat=ok'));
}

// Pemberitahuan kalau tadi mencoba membuka halaman khusus super admin.
if (($_GET['sertifikat'] ?? '') === 'ok') $success = 'Status sertifikat berhasil diperbarui.';
if (($_GET['sertifikat'] ?? '') === 'gagal') $errorSertifikat = 'Status sertifikat gagal diperbarui.';

$error = isset($_GET['akses_ditolak'])
    ? 'Menu Kelola Admin khusus super admin. Hubungi super admin kalau kamu perlu menambah atau mengubah akun admin.'
    : '';

// Pemberitahuan setelah pengguna mengganti kata sandinya sendiri di halaman Profil.
$success = isset($_GET['sandi_diganti'])
    ? 'Kata sandi berhasil diganti. Gunakan kata sandi baru saat login berikutnya.'
    : '';

// Peringatan non-blocking kalau situs diakses lewat HTTP biasa di domain/IP publik
// (bukan localhost/127.0.0.1) — browser modern akan MENOLAK kamera & GPS di halaman
// non-HTTPS, jadi mahasiswa tidak akan bisa absen sama sekali kalau SSL belum dipasang.
// Tidak muncul saat development lokal (localhost/127.0.0.1) atau kalau sudah HTTPS.
$httpsAktif = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
    || (($_SERVER['SERVER_PORT'] ?? '') == 443);
$hostSekarang = $_SERVER['HTTP_HOST'] ?? '';
$isLocalhost = preg_match('/^(localhost|127\.0\.0\.1)(:\d+)?$/i', $hostSekarang);
// Cuma ditampilkan ke admin, karena pemasangan SSL memang urusan admin/pengelola server.
$perluPeringatanHttps = isAdmin() && !$httpsAktif && !$isLocalhost;

// ---- Widget "Tidak hadir kemarin" ----
// Dihitung pakai fungsi yang sama dengan halaman Laporan (ambilDataLaporan), supaya
// logikanya konsisten satu tempat: mahasiswa dianggap tidak hadir kalau tidak ada
// absen masuk DAN tidak sedang izin/sakit yang disetujui di hari itu. Kalau kemarin
// hari libur, hasilnya otomatis kosong (tidak ada yang perlu ditandai tidak hadir).
$kemarin = date('Y-m-d', strtotime('-1 day'));
$tidakHadirKemarin = array_values(array_filter(
    ambilDataLaporan($kemarin, $kemarin, null, null, null, idPembimbingScope()),
    fn($item) => $item['status'] === 'Tidak Hadir'
));

// ---- Ambil semua mahasiswa aktif + status absen hari ini ----
// (dipakai bareng untuk angka ringkasan di kartu atas DAN daftar nama per kategori di bawah)
// Catatan: JOIN absensi aman dari duplikat baris karena tabel absensi punya
// UNIQUE KEY (user_id, tanggal, jenis) — jadi maksimal 1 baris per jenis per hari.
$stmt = $pdo->prepare("
  SELECT
    u.id, u.nama, u.identifier, u.foto_profil, u.kategori_id, u.cabang_id,
    c.nama_cabang, c.jam_pulang AS jam_tutup_absen,
    am.waktu AS waktu_masuk, am.status AS status_masuk, am.terlambat AS terlambat_masuk, am.wfa AS wfa_masuk,
    am.diisi_admin AS admin_masuk, am.alasan_manual AS alasan_masuk, am.keterangan AS catatan_masuk,
    ap.waktu AS waktu_pulang, ap.status AS status_pulang,
    ap.diisi_admin AS admin_pulang, ap.alasan_manual AS alasan_pulang, ap.keterangan AS catatan_pulang
  FROM users u
  LEFT JOIN cabang c ON c.id = u.cabang_id
  LEFT JOIN absensi am ON am.user_id = u.id AND am.tanggal = ? AND am.jenis = 'masuk'
  LEFT JOIN absensi ap ON ap.user_id = u.id AND ap.tanggal = ? AND ap.jenis = 'pulang'
  WHERE u.role = 'mahasiswa' AND u.status = 'aktif'{$sqlScope}
  ORDER BY u.nama ASC
");
$stmt->execute(array_merge([$today, $today], $paramScope));
$semuaMhs = $stmt->fetchAll();

// Ambil pengajuan izin/sakit yang berlaku untuk hari ini (pending ATAU approved),
// diquery TERPISAH dari query mahasiswa di atas supaya kalau ada mahasiswa dengan
// lebih dari 1 pengajuan yang tumpang tindih, baris mahasiswa tidak ikut terduplikasi.
$stmtIzin = $pdo->prepare("
  SELECT i.user_id, i.jenis, i.status FROM izin i
  JOIN users u ON u.id = i.user_id
  WHERE i.status IN ('pending','approved') AND ? BETWEEN i.tanggal_mulai AND i.tanggal_selesai{$sqlScope}
  ORDER BY (i.status='approved') DESC, i.id DESC
");
$stmtIzin->execute(array_merge([$today], $paramScope));
$izinMap = [];
foreach ($stmtIzin->fetchAll() as $iz) {
    // Kalau lebih dari 1 baris untuk user yang sama, prioritaskan yang approved (urutan query di atas).
    if (!isset($izinMap[$iz['user_id']])) {
        $izinMap[$iz['user_id']] = $iz;
    }
}
foreach ($semuaMhs as &$m) {
    $m['izin_jenis'] = $izinMap[$m['id']]['jenis'] ?? null;
    $m['izin_status'] = $izinMap[$m['id']]['status'] ?? null;
}
unset($m);

// Golongkan tiap mahasiswa ke kelompok-kelompok yang dibutuhkan
$totalMhs = count($semuaMhs);
$sudahMasuk = $belumMasuk = $terlambat = $sudahPulang = $belumPulang = [];

foreach ($semuaMhs as $m) {
    $masukValid = $m['waktu_masuk'] !== null && $m['status_masuk'] === 'valid';
    $pulangValid = $m['waktu_pulang'] !== null && $m['status_pulang'] === 'valid';

    if ($masukValid) {
        $sudahMasuk[] = $m;
        if ($m['terlambat_masuk']) $terlambat[] = $m;
    } else {
        $belumMasuk[] = $m;
    }

    if ($pulangValid) {
        $sudahPulang[] = $m;
    } else {
        $belumPulang[] = $m;
    }
}

$stmtPending = $pdo->prepare("SELECT COUNT(*) c FROM izin i JOIN users u ON u.id = i.user_id WHERE i.status='pending'{$sqlScope}");
$stmtPending->execute($paramScope);
$izinPending = (int) $stmtPending->fetch()['c'];

$stmt2 = $pdo->prepare("
  SELECT a.*, u.nama FROM absensi a JOIN users u ON u.id=a.user_id
  WHERE a.tanggal=?{$sqlScope} ORDER BY a.waktu DESC LIMIT 15
");
$stmt2->execute(array_merge([$today], $paramScope));
$aktivitasHariIni = $stmt2->fetchAll();

// Data untuk kartu stat + daftar nama di bawahnya: key => [label, list mahasiswa]
$kelompok = [
    'aktif'        => [isPembimbing() ? 'Mahasiswa bimbingan aktif' : 'Mahasiswa aktif', $semuaMhs],
    'sudah-masuk'  => ['Sudah absen masuk', $sudahMasuk],
    'belum-masuk'  => ['Belum absen masuk', $belumMasuk],
    'terlambat'    => ['Terlambat hari ini', $terlambat],
    'sudah-pulang' => ['Sudah absen pulang', $sudahPulang],
    'belum-pulang' => ['Belum absen pulang', $belumPulang],
];

// Keterangan izin/sakit + info absen yang diisi manual admin, ditampilkan ringkas di daftar nama
function keteranganDashboard($m) {
    $alasanLabel = ['hadir' => 'Hadir', 'sakit' => 'Sakit', 'izin' => 'Izin', 'lainnya' => 'Lainnya'];
    $baris = [];

    if ($m['izin_jenis']) {
        $label = $m['izin_jenis'] === 'sakit' ? 'Sakit' : 'Izin';
        $baris[] = $m['izin_status'] === 'pending' ? "$label (menunggu persetujuan)" : "$label (disetujui)";
    }
    if ($m['admin_masuk']) {
        $baris[] = 'Absen masuk diisi admin: ' . ($alasanLabel[$m['alasan_masuk']] ?? '-') . ($m['catatan_masuk'] ? ' — ' . $m['catatan_masuk'] : '');
    }
    if ($m['admin_pulang']) {
        $baris[] = 'Absen pulang diisi admin: ' . ($alasanLabel[$m['alasan_pulang']] ?? '-') . ($m['catatan_pulang'] ? ' — ' . $m['catatan_pulang'] : '');
    }
    return $baris;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Dashboard <?= e($labelPanel) ?> — Absensi Magang</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>

<div class="container pb-5">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h1 class="h4 fw-bold mb-0">Dashboard <?= e($labelPanel) ?></h1>
      <span class="text-muted small"><?= e(currentUser()['nama']) ?></span>
    </div>
  </div>

  <?php if ($perluPeringatanHttps): ?>
    <div class="alert alert-danger d-flex align-items-start gap-2">
      <i class="bi bi-lock-fill fs-5"></i>
      <div>
        <b class="d-block">Situs ini belum diakses lewat HTTPS</b>
        <span class="small">Browser mahasiswa akan menolak izin kamera & lokasi GPS di halaman non-HTTPS, jadi absen tidak akan bisa dilakukan sama sekali. Pasang sertifikat SSL (mis. Let's Encrypt) di hosting sebelum dibagikan ke mahasiswa. Peringatan ini otomatis hilang begitu HTTPS aktif.</span>
      </div>
    </div>
  <?php endif; ?>

  <div class="row row-cols-2 row-cols-md-3 g-2 mb-3" id="statsGrid">
    <?php foreach ($kelompok as $key => [$label, $list]): ?>
      <div class="col">
        <div class="card h-100 stat-box clickable <?= $key === 'aktif' ? 'active border-primary' : '' ?>" data-filter="<?= $key ?>">
          <div class="card-body py-3">
            <div class="fs-3 fw-bold text-primary"><?= count($list) ?></div>
            <div class="small text-muted"><?= e($label) ?></div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <?php if ($izinPending > 0): ?>
    <div class="alert alert-warning d-flex align-items-start gap-2">
      <i class="bi bi-bell-fill fs-5"></i>
      <div><b class="d-block"><?= $izinPending ?> pengajuan izin/sakit menunggu</b><span class="small">Cek di menu Izin/Sakit untuk memproses.</span></div>
    </div>
  <?php endif; ?>

  <?php if (!empty($tidakHadirKemarin)): ?>
    <div class="alert alert-danger d-flex align-items-start gap-2">
      <i class="bi bi-exclamation-triangle-fill fs-5"></i>
      <div>
        <b class="d-block"><?= count($tidakHadirKemarin) ?> mahasiswa tidak hadir kemarin (<?= formatTanggalID($kemarin) ?>) tanpa keterangan</b>
        <span class="small">
          <?= e(implode(', ', array_slice(array_map(fn($i) => $i['nama'], $tidakHadirKemarin), 0, 5))) ?><?= count($tidakHadirKemarin) > 5 ? ', dan ' . (count($tidakHadirKemarin) - 5) . ' lainnya' : '' ?>
          — <a href="laporan.php?dari=<?= $kemarin ?>&sampai=<?= $kemarin ?>" class="alert-link">lihat detail di Laporan</a>
        </span>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($pengingatSertifikat): ?>
    <?php
      // Ringkasan singkat saja; pengelolaannya (tandai / batalkan) ada di menu Sertifikat.
      $sertifikatLewat = array_filter($pengingatSertifikat, fn($p) => (int) $p['sisa_hari'] < 0);
      $namaSertifikat = array_slice(array_map(fn($p) => $p['nama'], $pengingatSertifikat), 0, 4);
    ?>
    <div class="alert alert-warning d-flex align-items-start gap-2">
      <i class="bi bi-award-fill fs-5"></i>
      <div>
        <b class="d-block">
          <?= count($pengingatSertifikat) ?> sertifikat perlu disiapkan
          <?= $sertifikatLewat ? '(' . count($sertifikatLewat) . ' sudah lewat tanggal)' : '' ?>
        </b>
        <span class="small">
          <?= e(implode(', ', $namaSertifikat)) ?><?= count($pengingatSertifikat) > 4 ? ', dan ' . (count($pengingatSertifikat) - 4) . ' lainnya' : '' ?>
          — <a href="sertifikat.php" class="alert-link">kelola di menu Sertifikat</a>
        </span>
      </div>
    </div>
  <?php endif; ?>

  <a href="absen_manual.php" class="btn btn-outline-primary mb-3"><i class="bi bi-pencil-square me-1"></i>Isi Absen Manual (izin/sakit dadakan)</a>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Rincian per mahasiswa</p>
      <h2 class="h6 fw-bold mb-1" id="daftarJudul"><?= isPembimbing() ? 'Mahasiswa Bimbingan Aktif' : 'Mahasiswa aktif' ?> (<?= $totalMhs ?>)</h2>
      <p class="text-muted small">Klik salah satu kartu angka di atas untuk melihat siapa saja yang termasuk di dalamnya.</p>

      <div class="list-group list-group-flush" style="max-height:420px;overflow-y:auto;" id="daftarMhs">
        <?php foreach ($semuaMhs as $m):
          $masukValid = $m['waktu_masuk'] !== null && $m['status_masuk'] === 'valid';
          $pulangValid = $m['waktu_pulang'] !== null && $m['status_pulang'] === 'valid';
          $ketList = keteranganDashboard($m);
        ?>
          <div class="list-group-item px-0"
               data-aktif="1"
               data-sudah-masuk="<?= $masukValid ? 1 : 0 ?>"
               data-belum-masuk="<?= $masukValid ? 0 : 1 ?>"
               data-terlambat="<?= ($masukValid && $m['terlambat_masuk']) ? 1 : 0 ?>"
               data-sudah-pulang="<?= $pulangValid ? 1 : 0 ?>"
               data-belum-pulang="<?= $pulangValid ? 0 : 1 ?>">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <div class="d-flex align-items-center gap-2">
                <img src="<?= e(urlAvatar($m['foto_profil'], $m['nama'])) ?>" class="rounded-circle" style="width:28px;height:28px;object-fit:cover;">
                <b class="small"><?= e($m['nama']) ?></b>
              </div>
              <?php if (!$masukValid): ?>
                <span class="badge text-bg-danger">Belum masuk</span>
              <?php elseif ($pulangValid): ?>
                <span class="badge text-bg-success">Berhasil</span>
              <?php elseif ($m['admin_masuk']): ?>
                <span class="badge text-bg-warning">Diisi Admin</span>
              <?php elseif ($m['terlambat_masuk']): ?>
                <span class="badge text-bg-warning">Terlambat</span>
              <?php else: ?>
                <span class="badge text-bg-success">Tepat waktu</span>
              <?php endif; ?>
            </div>
            <div class="small text-muted">Username: <?= e($m['identifier']) ?><?= $m['kategori_id'] ? ' · '.e(labelKategori($m['kategori_id'])) : '' ?><?= $m['nama_cabang'] ? ' · '.e($m['nama_cabang']) : '' ?></div>
            <div class="small text-muted">
              Masuk: <?= $masukValid
                  ? substr($m['waktu_masuk'],0,5).($m['wfa_masuk'] ? ' (WFA)' : '')
                  : (absenMasukSudahDitutup(['jam_pulang' => $m['jam_tutup_absen']], $today)
                      ? '<span class="text-danger">Tidak hadir</span>'
                      : 'Belum absen') ?>
              &nbsp;·&nbsp;
              Pulang: <?= $pulangValid ? substr($m['waktu_pulang'],0,5).($m['admin_pulang'] ? ' (diisi admin)' : '') : 'Belum absen' ?>
            </div>
            <?php foreach ($ketList as $ket): ?>
              <div class="small text-muted">Keterangan: <b><?= e($ket) ?></b></div>
            <?php endforeach; ?>
            <div class="mt-2">
              <a href="absen_manual.php?user_id=<?= $m['id'] ?>&tanggal=<?= $today ?>&jenis=<?= $masukValid ? 'pulang' : 'masuk' ?>" class="btn btn-outline-primary btn-sm"><i class="bi bi-pencil-square me-1"></i>Isi Manual</a>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if (empty($semuaMhs)): ?>
          <div class="text-muted small text-center py-3"><?= isPembimbing() ? 'Belum ada mahasiswa aktif yang ditetapkan sebagai bimbinganmu. Hubungi admin untuk mengaturnya.' : 'Belum ada mahasiswa aktif.' ?></div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Aktivitas</p>
      <h2 class="h6 fw-bold mb-2">Absensi Hari Ini</h2>
      <div class="list-group list-group-flush" style="max-height:420px;overflow-y:auto;">
        <?php if (empty($aktivitasHariIni)): ?>
          <div class="text-muted small text-center py-3">Belum ada aktivitas absen hari ini.</div>
        <?php else: foreach ($aktivitasHariIni as $r): ?>
          <div class="list-group-item px-0 d-flex align-items-center gap-2">
            <img src="<?= e(urlAvatar($r['foto'], $r['nama'] ?? '')) ?>" class="rounded" style="width:38px;height:38px;object-fit:cover;">
            <div class="flex-grow-1">
              <p class="small fw-semibold mb-0"><?= e($r['nama']) ?> · <?= $r['jenis']==='masuk'?'Masuk':'Pulang' ?></p>
              <span class="text-muted" style="font-size:11.5px;">
                <?= substr($r['waktu'],0,5) ?>
                <?= $r['diisi_admin'] ? ' · Diisi admin ('.e(['hadir'=>'Hadir','sakit'=>'Sakit','izin'=>'Izin','lainnya'=>'Lainnya'][$r['alasan_manual']] ?? '-').')' : ' · '.$r['jarak_meter'].'m'.($r['wfa'] ? ' · WFA' : '') ?>
              </span>
            </div>
            <span class="badge text-bg-<?= $r['status']!=='valid' ? 'danger' : ($r['diisi_admin'] ? 'warning' : ($r['terlambat'] ? 'warning' : 'success')) ?>"><?= $r['status']!=='valid' ? 'Ditolak' : ($r['diisi_admin'] ? 'Manual' : ($r['terlambat'] ? 'Terlambat' : 'Berhasil')) ?></span>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/foot.php'; ?>
<script>
// Klik kartu angka di atas -> filter daftar nama mahasiswa di bawahnya sesuai kelompok itu.
(function () {
  var judulPerFilter = <?= jsonUntukScript(array_map(fn($k) => $k[0], $kelompok)) ?>;
  var statBoxes = document.querySelectorAll('#statsGrid .stat-box');
  var items = document.querySelectorAll('#daftarMhs .list-group-item');
  var judul = document.getElementById('daftarJudul');

  statBoxes.forEach(function (box) {
    box.addEventListener('click', function () {
      var filter = box.dataset.filter;
      statBoxes.forEach(function (b) { b.classList.remove('active'); });
      box.classList.add('active');

      var jumlahTampil = 0;
      items.forEach(function (item) {
        var cocok = item.dataset[toCamel(filter)] === '1';
        item.style.display = cocok ? '' : 'none';
        if (cocok) jumlahTampil++;
      });

      judul.textContent = (judulPerFilter[filter] || 'Mahasiswa') + ' (' + jumlahTampil + ')';
    });
  });

  function toCamel(str) {
    return str.replace(/-([a-z])/g, function (g) { return g[1].toUpperCase(); });
  }
})();
</script>
</body>
</html>
