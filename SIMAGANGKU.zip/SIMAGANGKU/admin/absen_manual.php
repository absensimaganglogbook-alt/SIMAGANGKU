<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin(['admin', 'pembimbing']);
$pdo = getDB();
$admin = currentUser(); // admin ATAU pembimbing yang sedang mengisi

// Admin bisa mengisi untuk semua mahasiswa; pembimbing hanya mahasiswa bimbingannya.
[$sqlScope, $paramScope] = scopeMahasiswa('u');

// Khusus pembimbing: cabang tidak perlu dipilih manual — sistem memakai cabang yang
// sudah ditetapkan admin pada akun pembimbing itu, dan daftar mahasiswanya otomatis
// dibatasi ke mahasiswa bimbingan yang berada di cabang tersebut.
$pembimbingSaya = isPembimbing() ? ambilPembimbing($admin['id']) : null;
$cabangPembimbing = $pembimbingSaya && $pembimbingSaya['cabang_id'] ? ambilCabang($pembimbingSaya['cabang_id']) : null;
if (isPembimbing()) {
    if ($cabangPembimbing) {
        $sqlScope .= " AND u.cabang_id = ?";
        $paramScope[] = (int) $cabangPembimbing['id'];
    } else {
        // Cabang pembimbing belum diatur admin → tidak ada mahasiswa yang boleh diisi
        // (daripada menampilkan semua bimbingan dari cabang mana pun).
        $sqlScope .= " AND 1=0";
    }
}

$alasanLabel = ['hadir' => 'Hadir', 'sakit' => 'Sakit', 'izin' => 'Izin', 'lainnya' => 'Lainnya'];

$error = '';
$success = isset($_GET['terhapus']) ? 'Data absen manual berhasil dihapus.' : '';

// Pesan setelah pengalihan (Post/Redirect/Get) — hanya tampil sekali, tidak muncul lagi saat refresh.
if ($pesanSekali = ambilPesanSekali()) {
    if (($pesanSekali['tipe'] ?? 'success') === 'success') { $success = $pesanSekali['pesan']; }
    else { $error = $pesanSekali['pesan']; }
}
$dataExisting = null; // dipakai kalau butuh konfirmasi timpa data

// Nilai form: dari POST kalau baru submit, dari GET kalau baru buka halaman (mis. dari shortcut Dashboard)
$fUserId = (int)($_POST['user_id'] ?? $_GET['user_id'] ?? 0);
$fTanggal = $_POST['tanggal'] ?? $_GET['tanggal'] ?? date('Y-m-d');
$fJenis = $_POST['jenis'] ?? $_GET['jenis'] ?? 'pulang';
$fJam = $_POST['jam'] ?? date('H:i');
$fAlasan = $_POST['alasan_manual'] ?? 'sakit';

// Mode kerja hari itu (WFO / WFA). Penting: absen pulang mahasiswa dikunci mengikuti
// mode absen MASUK-nya. Dulu absen manual selalu tersimpan sebagai WFO, sehingga
// mahasiswa yang hari itu WFA tidak bisa absen pulang dari luar kantor.
$fMode = ($_POST['mode_kerja'] ?? $_GET['mode_kerja'] ?? 'wfo') === 'wfa' ? 'wfa' : 'wfo';
$fCatatan = trim($_POST['catatan'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_absen'])) {
    verifikasiCsrf();
    $konfirmasiTimpa = isset($_POST['konfirmasi_timpa']);

    // ---- Validasi input ----
    $stmtMhs = $pdo->prepare("SELECT u.* FROM users u WHERE u.id=? AND u.role='mahasiswa'{$sqlScope}");
    $stmtMhs->execute(array_merge([$fUserId], $paramScope));
    $mhs = $stmtMhs->fetch();

    if (!$mhs) {
        $error = isPembimbing()
            ? 'Mahasiswa tidak ditemukan atau bukan mahasiswa bimbinganmu. Pilih lagi dari daftar.'
            : 'Mahasiswa tidak ditemukan. Pilih lagi dari daftar.';
    } elseif ($mhs['status'] !== 'aktif') {
        $error = 'Mahasiswa ini sudah tidak aktif, tidak bisa diisikan absen.';
    } elseif (!in_array($fJenis, ['masuk', 'pulang'], true)) {
        $error = 'Jenis absen tidak valid.';
    } elseif (!array_key_exists($fAlasan, $alasanLabel)) {
        $error = 'Alasan wajib dipilih.';
    } elseif ($fTanggal === '' || $fTanggal > date('Y-m-d')) {
        $error = 'Tanggal tidak boleh kosong atau di masa depan.';
    } elseif (!preg_match('/^\d{2}:\d{2}$/', $fJam)) {
        $error = 'Jam tidak valid.';
    } else {
        // ---- Cek apakah sudah ada data absen di tanggal+jenis yang sama ----
        $cek = $pdo->prepare("SELECT a.*, ad.nama AS nama_admin FROM absensi a
                               LEFT JOIN users ad ON ad.id = a.diisi_oleh_admin_id
                               WHERE a.user_id=? AND a.tanggal=? AND a.jenis=?");
        $cek->execute([$fUserId, $fTanggal, $fJenis]);
        $existing = $cek->fetch();

        if ($existing && !$konfirmasiTimpa) {
            // Jangan langsung ditimpa — tampilkan datanya dulu, minta admin konfirmasi.
            $dataExisting = $existing;
        } else {
            $waktuFull = $fJam . ':00';
            $stmtSave = $pdo->prepare("
                INSERT INTO absensi (user_id, tanggal, jenis, waktu, status, terlambat, wfa, diisi_admin, alasan_manual, diisi_oleh_admin_id, keterangan, foto, lat, lng, jarak_meter)
                VALUES (?, ?, ?, ?, 'valid', 0, ?, 1, ?, ?, ?, NULL, NULL, NULL, NULL)
                ON DUPLICATE KEY UPDATE
                    waktu = VALUES(waktu), status = 'valid', terlambat = 0, wfa = VALUES(wfa),
                    diisi_admin = 1, alasan_manual = VALUES(alasan_manual),
                    diisi_oleh_admin_id = VALUES(diisi_oleh_admin_id), keterangan = VALUES(keterangan),
                    foto = NULL, lat = NULL, lng = NULL, jarak_meter = NULL
            ");
            // Kalau menimpa absen asli mahasiswa, fotonya di-set NULL oleh query ini —
            // jadi file fisiknya dibuang dulu supaya tidak tertinggal percuma.
            $stmtFotoLama = $pdo->prepare("SELECT foto FROM absensi WHERE user_id=? AND tanggal=? AND jenis=?");
            $stmtFotoLama->execute([$fUserId, $fTanggal, $fJenis]);
            $fotoLamaManual = $stmtFotoLama->fetchColumn();

            $stmtSave->execute([$fUserId, $fTanggal, $fJenis, $waktuFull, ($fMode === 'wfa' ? 1 : 0),
                    $fAlasan, $admin['id'], $fCatatan ?: null]);
            if ($fotoLamaManual) hapusSatuBerkas($fotoLamaManual);
            catatAktivitas('absen_manual', 'mahasiswa', $fUserId, $mhs['nama'],
                ucfirst($fJenis) . ' ' . formatTanggalID($fTanggal) . ' jam ' . substr($waktuFull, 0, 5) . ' (' . $alasanLabel[$fAlasan] . ' · ' . strtoupper($fMode) . ')');

            simpanPesanSekali('Absen ' . ($fJenis === 'masuk' ? 'masuk' : 'pulang') . ' untuk ' . $mhs['nama'] . ' pada ' . formatTanggalID($fTanggal) . ' berhasil disimpan (' . $alasanLabel[$fAlasan] . ').');
            redirect(panelBase() . '/absen_manual.php');

            // Reset form ke kondisi netral setelah berhasil, biar tidak ketimpa lagi tanpa sengaja
            $fUserId = 0; $fTanggal = date('Y-m-d'); $fJenis = 'pulang'; $fJam = date('H:i'); $fAlasan = 'sakit'; $fCatatan = ''; $fMode = 'wfo';
        }
    }
}

// ---- Hapus entri manual (hanya yang memang diisi_admin=1, tidak boleh hapus absen asli mahasiswa) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {
    verifikasiCsrf();
    $idHapus = (int)$_POST['hapus'];
    // JOIN ke users supaya pembimbing hanya bisa menghapus entri milik mahasiswa bimbingannya.
    $stmtFotoHapus = $pdo->prepare("SELECT a.foto FROM absensi a JOIN users u ON u.id = a.user_id WHERE a.id=? AND a.diisi_admin=1{$sqlScope}");
    $stmtFotoHapus->execute(array_merge([$idHapus], $paramScope));
    $fotoEntriHapus = $stmtFotoHapus->fetchColumn();

    $pdo->prepare("DELETE a FROM absensi a JOIN users u ON u.id = a.user_id WHERE a.id=? AND a.diisi_admin=1{$sqlScope}")
        ->execute(array_merge([$idHapus], $paramScope));
    if ($fotoEntriHapus) hapusSatuBerkas($fotoEntriHapus);
    catatAktivitas('hapus_absen', 'absensi', $idHapus, null, 'Menghapus 1 entri absen manual');
    redirect(panelBase() . '/absen_manual.php?terhapus=1');
}

$stmtDaftarMhs = $pdo->prepare("
    SELECT u.id, u.nama, u.identifier, u.kategori_id, u.cabang_id, c.nama_cabang
    FROM users u LEFT JOIN cabang c ON c.id = u.cabang_id
    WHERE u.role='mahasiswa' AND u.status='aktif'{$sqlScope}
    ORDER BY u.nama ASC
");
$stmtDaftarMhs->execute($paramScope);
$daftarMahasiswa = $stmtDaftarMhs->fetchAll();
$daftarCabangUntukFilter = isPembimbing() ? [] : daftarCabang();

// Riwayat absen manual: bawaannya bulan berjalan saja.
$bulan = bulanDipilih();
[$awalBulan, $akhirBulan] = rentangBulan($bulan);
$paramManual = array_merge($paramScope, [$awalBulan, $akhirBulan]);

$stmtAwalManual = $pdo->prepare("SELECT DATE_FORMAT(MIN(a.tanggal), '%Y-%m') FROM absensi a JOIN users u ON u.id = a.user_id WHERE a.diisi_admin = 1{$sqlScope}");
$stmtAwalManual->execute($paramScope);
$daftarTahun = daftarTahunPilihan(substr((string) $stmtAwalManual->fetchColumn(), 0, 4), substr($bulan, 0, 4));

$stmtTotalManual = $pdo->prepare("SELECT COUNT(*) c FROM absensi a JOIN users u ON u.id = a.user_id WHERE a.diisi_admin = 1{$sqlScope} AND a.tanggal BETWEEN ? AND ?");
$stmtTotalManual->execute($paramManual);
$totalRiwayatManual = (int)$stmtTotalManual->fetch()['c'];
$pg = paginasi($totalRiwayatManual, $_GET['halaman'] ?? 1, 15);

$stmtRiwayatManual = $pdo->prepare("
    SELECT a.*, u.nama, u.identifier, ad.nama AS nama_admin, ad.role AS role_pengisi
    FROM absensi a
    JOIN users u ON u.id = a.user_id
    LEFT JOIN users ad ON ad.id = a.diisi_oleh_admin_id
    WHERE a.diisi_admin = 1{$sqlScope} AND a.tanggal BETWEEN ? AND ?
    ORDER BY a.tanggal DESC, a.created_at DESC
    LIMIT {$pg['perHalaman']} OFFSET {$pg['offset']}
");
$stmtRiwayatManual->execute($paramManual);
$riwayatManual = $stmtRiwayatManual->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Isi Absen Manual — Absensi Magang</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Untuk kasus mendadak</p>
      <h2 class="h6 fw-bold mb-2">Isi Absen Mahasiswa</h2>
      <p class="text-muted small" style="margin-top:6px;">Untuk mengisikan absen mahasiswa yang tidak sempat absen sendiri. Entri ini ditandai "Diisi Admin" di riwayat & laporan.</p>

      <?php if ($success): ?><p class="alert alert-success py-2 small" style="margin-top:12px;"><?= e($success) ?></p><?php endif; ?>
      <?php if ($error): ?><p class="alert alert-danger py-2 small" style="margin-top:12px;"><?= e($error) ?></p><?php endif; ?>

      <?php if ($dataExisting): ?>
        <div class="alert alert-warning d-flex align-items-start gap-2" style="margin-top:12px;">
          <span class="ico">⚠️</span>
          <div>
            <b>Sudah ada data absen <?= $fJenis === 'masuk' ? 'masuk' : 'pulang' ?> di tanggal ini</b>
            <span>
              Jam <?= substr($dataExisting['waktu'],0,5) ?> ·
              Status: <?= $dataExisting['status'] === 'valid' ? 'Valid' : 'Ditolak' ?> ·
              Sumber: <?= $dataExisting['diisi_admin'] ? 'Diisi manual (' . e($dataExisting['nama_admin'] ?? '-') . ')' : 'Absen mahasiswa sendiri (kamera+GPS)' ?>.
              Lanjutkan untuk menimpa data ini dengan data baru yang kamu isi?
            </span>
          </div>
        </div>
        <form method="POST" style="margin-top:10px;">
          <?= csrfField() ?>
          <input type="hidden" name="submit_absen" value="1" class="form-control">
          <input type="hidden" name="user_id" value="<?= $fUserId ?>" class="form-control">
          <input type="hidden" name="tanggal" value="<?= e($fTanggal) ?>" class="form-control">
          <input type="hidden" name="jenis" value="<?= e($fJenis) ?>" class="form-control">
          <input type="hidden" name="jam" value="<?= e($fJam) ?>" class="form-control">
          <input type="hidden" name="alasan_manual" value="<?= e($fAlasan) ?>" class="form-control">
          <input type="hidden" name="mode_kerja" value="<?= e($fMode) ?>" class="form-control">
          <input type="hidden" name="catatan" value="<?= e($fCatatan) ?>" class="form-control">
          <input type="hidden" name="konfirmasi_timpa" value="1" class="form-control">
          <button type="submit" class="btn btn-danger">Ya, timpa data yang sudah ada</button>
          <a href="absen_manual.php" class="btn btn-outline-secondary" style="margin-top:8px;">Batal</a>
        </form>
      <?php else: ?>
        <form method="POST" style="margin-top:14px;">
          <?= csrfField() ?>
          <input type="hidden" name="submit_absen" value="1" class="form-control">
          <div style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;">
            <?php if (!isPembimbing()): ?>
            <div class="mb-3" style="flex:1;min-width:160px;">
              <label class="form-label">Filter cabang</label>
              <select id="filterCabangMhs" class="form-select">
                <option value="">— Semua cabang —</option>
                <?php foreach ($daftarCabangUntukFilter as $c): ?>
                  <option value="<?= $c['id'] ?>"><?= e($c['nama_cabang']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <?php endif; ?>
            <div class="mb-3" style="flex:1;min-width:160px;">
              <label class="form-label">Filter kategori</label>
              <select id="filterKategoriMhs" class="form-select">
                <option value="">— Semua kategori —</option>
                <?php foreach (daftarKategori() as $kode => $label): ?>
                  <option value="<?= e($kode) ?>"><?= e($label) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <?php if (isPembimbing()): ?>
            <p class="small mb-3">
              <span class="badge text-bg-info">🏢 Cabang: <?= e($cabangPembimbing['nama_cabang'] ?? 'Belum diatur') ?></span>
              <span class="text-muted">— diambil otomatis dari akunmu, jadi tidak perlu dipilih lagi.</span>
            </p>
          <?php endif; ?>
          <div class="mb-3">
            <label class="form-label">Mahasiswa</label>
            <select name="user_id" id="pilihMahasiswaManual" required class="form-select">
              <option value="">— Pilih mahasiswa —</option>
              <?php foreach ($daftarMahasiswa as $m): ?>
                <option value="<?= $m['id'] ?>"
                        data-cabang="<?= (int)$m['cabang_id'] ?>"
                        data-kategori="<?= e($m['kategori_id'] ?? '') ?>"
                        <?= $fUserId == $m['id'] ? 'selected' : '' ?>>
                  <?= e($m['nama']) ?> (<?= e($m['identifier']) ?>)<?= $m['nama_cabang'] ? ' · '.e($m['nama_cabang']) : '' ?>
                </option>
              <?php endforeach; ?>
            </select>
            <p class="text-muted small" id="infoFilterMhs" style="margin-top:6px;font-size:12.5px;"></p>
            <?php if (isPembimbing()): ?>
              <p class="text-muted small" style="margin-top:-2px;font-size:12.5px;">
                <?php if (!$cabangPembimbing): ?>
                  ⚠️ Cabang pada akunmu belum diatur admin, jadi belum ada mahasiswa yang bisa diisi di sini. Hubungi admin untuk mengaturnya.
                <?php else: ?>
                  Hanya mahasiswa bimbinganmu di cabang <b><?= e($cabangPembimbing['nama_cabang']) ?></b> yang tampil di sini.
                <?php endif; ?>
              </p>
            <?php endif; ?>
          </div>
          <div class="mb-3"><label class="form-label">Tanggal</label><input type="date" name="tanggal" value="<?= e($fTanggal) ?>" max="<?= date('Y-m-d') ?>" required class="form-control"></div>
          <div class="mb-3">
            <label class="form-label">Jenis absen</label>
            <select name="jenis" required class="form-select">
              <option value="masuk" <?= $fJenis === 'masuk' ? 'selected' : '' ?>>Absen Masuk</option>
              <option value="pulang" <?= $fJenis === 'pulang' ? 'selected' : '' ?>>Absen Pulang</option>
            </select>
          </div>
          <div class="mb-3"><label class="form-label">Jam</label><input type="time" name="jam" value="<?= e($fJam) ?>" required class="form-control"></div>
          <div class="mb-3">
            <label class="form-label">Mode kerja hari itu</label>
            <select name="mode_kerja" required class="form-select">
              <option value="wfo" <?= $fMode === 'wfo' ? 'selected' : '' ?>>WFO — bekerja di kantor</option>
              <option value="wfa" <?= $fMode === 'wfa' ? 'selected' : '' ?>>WFA — bekerja dari mana saja</option>
            </select>
            <p class="text-muted small" style="margin-top:6px;margin-bottom:0;font-size:12px;">
              Menentukan absen pulang mahasiswa: kalau diisi <b>WFA</b>, mahasiswa bisa absen pulang
              dari luar kantor tanpa pemeriksaan jarak.
            </p>
          </div>

          <div class="mb-3">
            <label class="form-label">Alasan</label>
            <select name="alasan_manual" required class="form-select">
              <?php foreach ($alasanLabel as $kode => $label): ?>
                <option value="<?= e($kode) ?>" <?= $fAlasan === $kode ? 'selected' : '' ?>><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Catatan (opsional)</label>
            <textarea name="catatan" rows="3" placeholder="Contoh: Pulang jam 14:00 karena demam tinggi, sudah dikonfirmasi ke orang tua." class="form-control"><?= e($fCatatan) ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Simpan Absen Manual</button>
        </form>
      <?php endif; ?>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Riwayat</p>
      <h2 class="h6 fw-bold mb-2">Absen yang Diisi Manual — <?= e(namaBulanID($bulan)) ?> (<?= $totalRiwayatManual ?>)</h2>
      <form method="GET" class="mb-3" style="max-width:340px;">
        <?php foreach ($_GET as $kunci => $nilai): if (in_array($kunci, ['bulan', 'tahun', 'bln', 'halaman'], true) || is_array($nilai)) continue; ?>
          <input type="hidden" name="<?= e($kunci) ?>" value="<?= e($nilai) ?>">
        <?php endforeach; ?>
        <?= dropdownBulan($daftarTahun, $bulan) ?>
        <noscript><button class="btn btn-secondary btn-sm mt-1">Tampilkan</button></noscript>
      </form>

      <div class="daftar-gulir" style="margin-top:10px;max-height:520px;">
        <?php if (empty($riwayatManual)): ?>
          <div class="text-muted small text-center py-3">Tidak ada absen manual di <?= e(namaBulanID($bulan)) ?>. Pilih bulan lain di atas untuk melihat data lainnya.</div>
        <?php else: foreach ($riwayatManual as $r): ?>
          <div class="list-group-item px-0">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <b><?= e($r['nama']) ?> · <?= $r['jenis']==='masuk'?'Masuk':'Pulang' ?></b>
              <span class="badge text-bg-warning"><?= e($alasanLabel[$r['alasan_manual']] ?? '-') ?></span>
            </div>
            <div class="small text-muted">Username: <?= e($r['identifier']) ?> · <?= e(formatTanggalID($r['tanggal'])) ?> · <?= substr($r['waktu'],0,5) ?></div>
            <div class="small text-muted">Diisi oleh: <?= e($r['nama_admin'] ?? '-') ?><?= $r['nama_admin'] ? ' (' . e(labelRole($r['role_pengisi'])) . ')' : '' ?></div>
            <?php if ($r['keterangan']): ?>
              <div class="small text-muted">Catatan: <?= e($r['keterangan']) ?></div>
            <?php endif; ?>
            <div class="d-flex flex-wrap gap-2 mt-2">
              <form method="POST" style="margin:0;" data-konfirmasi="Hapus data absen manual ini? Data absensi mahasiswa untuk tanggal & jenis tersebut akan hilang." data-konfirmasi-judul="Hapus absen manual" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1">
                <?= csrfField() ?>
                <input type="hidden" name="hapus" value="<?= $r['id'] ?>" class="form-control">
                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
              </form>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <?php if ($pg['totalHalaman'] > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
          <?php if ($pg['halaman'] > 1): ?>
            <a href="<?= urlHalaman($pg['halaman'] - 1) ?>" class="btn btn-outline-secondary btn-sm">← Sebelumnya</a>
          <?php else: ?><span></span><?php endif; ?>
          <span class="text-muted small">Halaman <?= $pg['halaman'] ?> dari <?= $pg['totalHalaman'] ?></span>
          <?php if ($pg['halaman'] < $pg['totalHalaman']): ?>
            <a href="<?= urlHalaman($pg['halaman'] + 1) ?>" class="btn btn-outline-secondary btn-sm">Berikutnya →</a>
          <?php else: ?><span></span><?php endif; ?>
        </div>
      <?php endif; ?>
      </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
<script>
(function () {
  var filterCabang = document.getElementById('filterCabangMhs');
  var filterKategori = document.getElementById('filterKategoriMhs');
  var selectMhs = document.getElementById('pilihMahasiswaManual');
  var info = document.getElementById('infoFilterMhs');
  if (!selectMhs) return;

  // Simpan semua <option> asli (termasuk urutannya) supaya bisa dimunculkan lagi saat filter dikosongkan.
  var semuaOption = Array.prototype.slice.call(selectMhs.options);

  function terapkanFilter() {
    // Filter cabang tidak ada di panel pembimbing (cabangnya sudah otomatis dari akunnya).
    var cabang = filterCabang ? filterCabang.value : '';
    var kategori = filterKategori.value;
    var cocok = 0;

    semuaOption.forEach(function (opt) {
      if (!opt.value) { opt.hidden = false; return; } // opsi "— Pilih mahasiswa —" selalu tampil

      var cocokCabang = !cabang || opt.getAttribute('data-cabang') === cabang;
      var cocokKategori = !kategori || opt.getAttribute('data-kategori') === kategori;
      var tampil = cocokCabang && cocokKategori;
      opt.hidden = !tampil;
      if (tampil) cocok++;
    });

    // Kalau mahasiswa yang lagi dipilih jadi tidak cocok filter, kembalikan ke "— Pilih mahasiswa —"
    var opsiTerpilih = selectMhs.options[selectMhs.selectedIndex];
    if (opsiTerpilih && opsiTerpilih.hidden) {
      selectMhs.value = '';
    }

    info.textContent = (cabang || kategori)
      ? cocok + ' mahasiswa cocok dengan filter ini.'
      : '';
  }

  if (filterCabang) filterCabang.addEventListener('change', terapkanFilter);
  filterKategori.addEventListener('change', terapkanFilter);
})();
</script>
</body>
</html>
