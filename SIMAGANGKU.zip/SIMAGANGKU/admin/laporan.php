<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/laporan_data.php';
requireLogin(['admin', 'pembimbing']);

$dariTanggal = $_GET['dari'] ?? date('Y-m-01');
$sampaiTanggal = $_GET['sampai'] ?? date('Y-m-d');
$mahasiswaId = isset($_GET['mahasiswa']) && $_GET['mahasiswa'] !== '' ? (int)$_GET['mahasiswa'] : null;
// Pembimbing hanya boleh melihat mahasiswa bimbingannya. Kalau id mahasiswa di URL
// bukan wewenangnya, abaikan filter itu (data tetap dibatasi ke bimbingannya sendiri).
if ($mahasiswaId && !bolehAksesMahasiswa($mahasiswaId)) {
    $mahasiswaId = null;
}

// '' = semua kategori
$kategoriPilihan = kategoriDariInput($_GET['kategori'] ?? '');

// '' = semua cabang
$cabangPilihan = isset($_GET['cabang']) && $_GET['cabang'] !== '' ? (int)$_GET['cabang'] : '';
if ($cabangPilihan && !ambilCabang($cabangPilihan)) {
    $cabangPilihan = '';
}

// Khusus pembimbing: cabang tidak dipilih manual — otomatis memakai cabang pada akunnya
// (sama seperti halaman Absen Manual). -1 dipakai kalau cabang akunnya belum diatur admin,
// supaya tidak ada data yang cocok sampai admin mengaturnya.
$cabangPembimbing = cabangOtomatisPembimbing();
if (isPembimbing()) {
    $cabangPilihan = $cabangPembimbing ? (int) $cabangPembimbing['id'] : -1;
}

$items = ambilDataLaporan($dariTanggal, $sampaiTanggal, $mahasiswaId, $kategoriPilihan ?: null, $cabangPilihan ?: null, idPembimbingScope());
[$sqlScope, $paramScope] = scopeMahasiswa('u');
// Daftar mahasiswa di dropdown ikut dibatasi cabang pembimbing.
if (isPembimbing()) {
    if ($cabangPembimbing) {
        $sqlScope .= " AND u.cabang_id = ?";
        $paramScope[] = (int) $cabangPembimbing['id'];
    } else {
        $sqlScope .= " AND 1=0";
    }
}
$stmtDaftarMhs = getDB()->prepare("SELECT u.id, u.nama, u.identifier, u.kategori_id, u.cabang_id FROM users u WHERE u.role='mahasiswa'{$sqlScope} ORDER BY u.nama ASC");
$stmtDaftarMhs->execute($paramScope);
$daftarMahasiswa = $stmtDaftarMhs->fetchAll();
$daftarCabangLaporan = daftarCabang();

// ---- Pagination pratinjau (hanya untuk tampilan di browser, TIDAK memotong data export Excel/PDF) ----
$totalItems = count($items);
$pg = paginasi($totalItems, $_GET['halaman'] ?? 1, 15);
$itemsHalaman = array_slice($items, $pg['offset'], $pg['perHalaman']);

$namaMahasiswaTerpilih = null;
if ($mahasiswaId) {
    foreach ($daftarMahasiswa as $m) {
        if ($m['id'] == $mahasiswaId) { $namaMahasiswaTerpilih = $m['nama']; break; }
    }
}
$namaKategoriTerpilih = $kategoriPilihan ? labelKategori($kategoriPilihan) : null;
$namaCabangTerpilih = null;
if ($cabangPilihan) {
    $cabangObj = ambilCabang($cabangPilihan);
    $namaCabangTerpilih = $cabangObj ? $cabangObj['nama_cabang'] : null;
}

// dipakai untuk sambungkan filter kategori, cabang & mahasiswa ke link export
$qsExtra = ($mahasiswaId ? '&mahasiswa='.$mahasiswaId : '') . ($kategoriPilihan ? '&kategori='.e($kategoriPilihan) : '') . ($cabangPilihan ? '&cabang='.$cabangPilihan : '');
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Laporan — Admin</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>

<div class="container pb-5">
  <h1 class="h4 fw-bold mb-3">Laporan</h1>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-2">Filter</p>
      <?php if (isPembimbing()): ?>
        <p class="small mb-2">
          <span class="badge text-bg-info">🏢 Cabang: <?= e($cabangPembimbing['nama_cabang'] ?? 'Belum diatur') ?></span>
          <span class="text-muted">— diambil otomatis dari akunmu, jadi tidak perlu dipilih lagi.</span>
        </p>
        <?php if (!$cabangPembimbing): ?>
          <p class="text-muted small">⚠️ Cabang pada akunmu belum diatur admin, jadi laporan masih kosong. Hubungi admin untuk mengaturnya.</p>
        <?php endif; ?>
      <?php endif; ?>
      <form method="GET" class="row g-2 align-items-end">
        <div class="col-6 col-md-2"><label class="form-label small">Dari tanggal</label><input type="date" name="dari" class="form-control" value="<?= e($dariTanggal) ?>"></div>
        <div class="col-6 col-md-2"><label class="form-label small">Sampai tanggal</label><input type="date" name="sampai" class="form-control" value="<?= e($sampaiTanggal) ?>"></div>
        <div class="col-6 col-md-3">
          <label class="form-label small">Kategori</label>
          <select name="kategori" id="filterKategori" class="form-select">
            <option value="">— Semua kategori —</option>
            <?php foreach (daftarKategori() as $kode => $label): ?>
              <option value="<?= e($kode) ?>" <?= $kategoriPilihan === $kode ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php if (!isPembimbing()): ?>
        <div class="col-6 col-md-3">
          <label class="form-label small">Cabang</label>
          <select name="cabang" id="filterCabang" class="form-select">
            <option value="">— Semua cabang —</option>
            <?php foreach ($daftarCabangLaporan as $c): ?>
              <option value="<?= $c['id'] ?>" <?= $cabangPilihan == $c['id'] ? 'selected' : '' ?>><?= e($c['nama_cabang']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endif; ?>
        <div class="col-12 col-md-8">
          <label class="form-label small">Mahasiswa</label>
          <select name="mahasiswa" id="filterMahasiswa" class="form-select">
            <option value=""><?= isPembimbing() ? '— Semua mahasiswa bimbingan (sesuai kategori di atas) —' : '— Semua mahasiswa (sesuai kategori/cabang di atas) —' ?></option>
            <?php foreach ($daftarMahasiswa as $m): ?>
              <option value="<?= $m['id'] ?>" data-kategori="<?= e($m['kategori_id']) ?>" data-cabang="<?= e($m['cabang_id']) ?>" <?= $mahasiswaId == $m['id'] ? 'selected' : '' ?>><?= e($m['nama']) ?> (<?= e($m['identifier']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 col-md-4 d-flex gap-2">
          <button type="submit" class="btn btn-secondary flex-fill">Terapkan</button>
          <?php if ($mahasiswaId || $kategoriPilihan || $cabangPilihan): ?>
            <a href="laporan.php?dari=<?= e($dariTanggal) ?>&sampai=<?= e($sampaiTanggal) ?>" class="btn btn-outline-secondary flex-fill">Reset</a>
          <?php endif; ?>
        </div>
      </form>
      <p class="text-muted small mt-2 mb-0">Kosongkan pilihan mahasiswa untuk laporan gabungan.</p>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Ekspor data</p>
      <h2 class="h6 fw-bold mb-1">
        Laporan <?= $namaMahasiswaTerpilih ? e($namaMahasiswaTerpilih) : (($namaKategoriTerpilih || $namaCabangTerpilih) ? trim(e($namaKategoriTerpilih).' '.($namaKategoriTerpilih && $namaCabangTerpilih ? '· ' : '').e($namaCabangTerpilih)) : (isPembimbing() ? 'Semua Mahasiswa Bimbingan' : 'Semua Mahasiswa')) ?>
      </h2>
      <p class="text-muted small">Periode: <?= e(formatTanggalID($dariTanggal)) ?> – <?= e(formatTanggalID($sampaiTanggal)) ?> · <?= $totalItems ?> baris data.</p>
      <div class="d-flex flex-column flex-sm-row gap-2">
        <a href="export_excel.php?dari=<?= e($dariTanggal) ?>&sampai=<?= e($sampaiTanggal) ?><?= $qsExtra ?>" class="btn btn-primary">⬇️ Export ke Excel (.xls)</a>
        <a href="export_pdf.php?dari=<?= e($dariTanggal) ?>&sampai=<?= e($sampaiTanggal) ?><?= $qsExtra ?>" target="_blank" class="btn btn-outline-secondary">🖨️ Buka Laporan PDF (Print)</a>
      </div>
    </div>
  </div>

  <?php $ringkas = ringkasanLaporan($items); ?>
  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Ringkasan</p>
      <h2 class="h6 fw-bold mb-3">
        Rekap periode <?= e(formatRentangTanggal($dariTanggal, $sampaiTanggal)) ?>
        <?= $namaMahasiswaTerpilih ? '— ' . e($namaMahasiswaTerpilih) : '' ?>
      </h2>
      <div class="row g-2">
        <?php foreach (daftarRingkasanLaporan($ringkas) as [$labelRingkas, $nilai, $warna]): ?>
          <div class="col-6 col-md-3 col-lg-2">
            <div class="border rounded p-2 h-100">
              <div class="h5 fw-bold mb-0 text-<?= $warna === 'secondary' || $warna === 'dark' ? 'body' : $warna ?>"><?= (int) $nilai ?></div>
              <div class="small text-muted"><?= e($labelRingkas) ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <p class="text-muted small mt-2 mb-0">
        Angka ini dihitung dari seluruh data pada periode & filter di atas (bukan hanya halaman pratinjau),
        dan ikut tercetak di file Excel maupun PDF.
      </p>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Pratinjau</p>
      <h2 class="h6 fw-bold mb-2">Data yang akan diekspor</h2>
      <div class="list-group list-group-flush" style="max-height:480px;overflow-y:auto;">
        <?php if (empty($itemsHalaman)): ?>
          <div class="text-muted small text-center py-3">Tidak ada data pada periode ini.</div>
        <?php else: foreach ($itemsHalaman as $it): ?>
          <div class="list-group-item px-0 d-flex align-items-center gap-2">
            <img src="<?= e(urlAvatar($it['foto'], $it['nama'] ?? '')) ?>" class="rounded" style="width:38px;height:38px;object-fit:cover;">
            <div class="flex-grow-1">
              <p class="small fw-semibold mb-0"><?= e($it['nama']) ?><?= $it['jenis'] !== '-' ? ' · '.e($it['jenis']) : '' ?></p>
              <span class="text-muted" style="font-size:11.5px;"><?= e($it['tanggal_tampil']) ?><?= $it['jam']!=='-' ? ' · '.e($it['jam']) : '' ?></span>
            </div>
            <?php $warnaBs = ['izin' => 'primary', 'sakit' => 'warning', 'late' => 'warning', 'bad' => 'danger', 'ok' => 'success', 'wait' => 'secondary'][warnaLaporan($it)]; ?>
            <span class="badge text-bg-<?= $warnaBs ?>"><?= e($it['status']) ?></span>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <?php if ($pg['totalHalaman'] > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
          <?php if ($pg['halaman'] > 1): ?>
            <a href="<?= urlHalaman($pg['halaman'] - 1) ?>" class="btn btn-outline-secondary btn-sm">← Sebelumnya</a>
          <?php else: ?><span></span><?php endif; ?>
          <span class="text-muted small">Halaman <?= $pg['halaman'] ?> dari <?= $pg['totalHalaman'] ?></span>
          <?php if ($pg['halaman'] < $pg['totalHalaman']): ?>
            <a href="<?= urlHalaman($pg['halaman'] + 1) ?>" class="btn btn-outline-secondary btn-sm">Berikutnya →</a>
          <?php else: ?><span></span><?php endif; ?>
        </div>
      <?php endif; ?>
      <p class="text-muted small mt-2 mb-0">Pratinjau dibatasi per halaman; file Excel/PDF yang diunduh selalu berisi seluruh data.</p>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/foot.php'; ?>
<script>
// Saring pilihan mahasiswa supaya cuma menampilkan mahasiswa dari kategori
// DAN cabang yang dipilih (kombinasi keduanya). Kalau kategori/cabang diganti
// dan mahasiswa yang sedang terpilih tidak lagi cocok, otomatis kembali ke
// "Semua mahasiswa".
(function () {
  var selKategori = document.getElementById('filterKategori');
  // Di panel pembimbing tidak ada pilihan cabang (otomatis dari akunnya), jadi boleh kosong.
  var selCabang = document.getElementById('filterCabang');
  var selMahasiswa = document.getElementById('filterMahasiswa');
  if (!selKategori || !selMahasiswa) return;

  function terapkanFilter() {
    var kategori = selKategori.value;
    var cabang = selCabang ? selCabang.value : '';
    var mahasiswaTerpilihMasihCocok = false;
    Array.prototype.forEach.call(selMahasiswa.options, function (opt) {
      if (!opt.value) { opt.hidden = false; return; } // opsi "semua mahasiswa"
      var cocokKategori = !kategori || opt.dataset.kategori === kategori;
      var cocokCabang = !cabang || opt.dataset.cabang === cabang;
      var cocok = cocokKategori && cocokCabang;
      opt.hidden = !cocok;
      if (cocok && opt.selected) mahasiswaTerpilihMasihCocok = true;
    });
    if (!mahasiswaTerpilihMasihCocok) {
      selMahasiswa.value = '';
    }
  }

  selKategori.addEventListener('change', terapkanFilter);
  if (selCabang) selCabang.addEventListener('change', terapkanFilter);
  terapkanFilter();
})();
</script>
</body>
</html>
