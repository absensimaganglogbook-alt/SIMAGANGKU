<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('admin');
$pdo = getDB();
$error = '';
$success = '';

/**
 * Kelola divisi/bagian instansi (khusus admin): tambah, ubah, hapus.
 *
 * Divisi dipakai saat membuat/mengedit akun pembimbing (menu Kelola Pembimbing),
 * supaya jelas tiap pembimbing bertugas di bagian mana. Divisi yang masih dipakai
 * pembimbing tidak bisa dihapus.
 */

/** Ambil & rapikan input form divisi (spasi ganda dirapikan jadi satu). */
function inputDivisi() {
    return [
        trim(preg_replace('/\s+/', ' ', $_POST['nama'] ?? '')),
        trim(preg_replace('/\s+/', ' ', $_POST['keterangan'] ?? '')),
    ];
}

function validasiInputDivisi($nama, $keterangan) {
    if ($nama === '') return 'Nama divisi/bagian wajib diisi.';
    // Hitung per karakter (bukan per byte), tanpa butuh ekstensi mbstring.
    if (!preg_match('/^.{1,100}$/u', $nama)) return 'Nama divisi/bagian maksimal 100 karakter.';
    if ($keterangan !== '' && !preg_match('/^.{1,255}$/u', $keterangan)) return 'Keterangan maksimal 255 karakter.';
    return null;
}

/** Cek nama divisi kembar. $kecualiId dipakai saat edit supaya tidak bentrok dengan dirinya sendiri. */
function cekDuplikatDivisi($pdo, $nama, $kecualiId = 0) {
    // Perbandingan di SQL sudah tidak peka huruf besar/kecil (collation utf8mb4_unicode_ci).
    $stmt = $pdo->prepare("SELECT nama FROM divisi WHERE nama = ? AND id <> ?");
    $stmt->execute([$nama, (int) $kecualiId]);
    $bentrok = $stmt->fetch();
    return $bentrok ? "Divisi \"{$bentrok['nama']}\" sudah ada." : null;
}

// ---- Tambah ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    verifikasiCsrf();
    [$nama, $keterangan] = inputDivisi();
    $error = validasiInputDivisi($nama, $keterangan) ?? cekDuplikatDivisi($pdo, $nama);
    if (!$error) {
        try {
            $pdo->prepare("INSERT INTO divisi (nama, keterangan) VALUES (?, ?)")->execute([$nama, $keterangan ?: null]);
            catatAktivitas('tambah_data', 'divisi', $pdo->lastInsertId(), $nama);
            redirect('/admin/divisi.php?ditambahkan=1');
        } catch (PDOException $e) {
            $error = 'Nama divisi sudah dipakai. Gunakan nama lain.';
        }
    }
}

// ---- Simpan hasil edit ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit'])) {
    verifikasiCsrf();
    $id = (int) ($_POST['id'] ?? 0);
    [$nama, $keterangan] = inputDivisi();
    if (!ambilDivisi($id)) {
        $error = 'Divisi tidak ditemukan.';
    } else {
        $error = validasiInputDivisi($nama, $keterangan) ?? cekDuplikatDivisi($pdo, $nama, $id);
    }
    if (!$error) {
        try {
            $pdo->prepare("UPDATE divisi SET nama = ?, keterangan = ? WHERE id = ?")->execute([$nama, $keterangan ?: null, $id]);
            catatAktivitas('ubah_data', 'divisi', $id, $nama);
            redirect('/admin/divisi.php?tersimpan=1');
        } catch (PDOException $e) {
            $error = 'Nama divisi sudah dipakai. Gunakan nama lain.';
        }
    }
}

// ---- Hapus ----
// Divisi yang masih dipakai pembimbing (aktif maupun nonaktif) tidak boleh dihapus,
// supaya data akun pembimbing tidak kehilangan divisinya. Database juga menjaga ini
// lewat foreign key ON DELETE RESTRICT.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {
    verifikasiCsrf();
    $id = (int) $_POST['hapus'];
    $divisi = ambilDivisi($id);
    $stmtPakai = $pdo->prepare("SELECT COUNT(*) FROM users WHERE divisi_id = ?");
    $stmtPakai->execute([$id]);
    $jumlahPakai = (int) $stmtPakai->fetchColumn();

    if (!$divisi) {
        $error = 'Divisi tidak ditemukan.';
    } elseif ($jumlahPakai > 0) {
        $error = "Divisi \"{$divisi['nama']}\" masih dipakai $jumlahPakai pembimbing, jadi belum bisa dihapus. Pindahkan dulu pembimbingnya ke divisi lain lewat menu Kelola Pembimbing → Edit.";
    } else {
        try {
            $pdo->prepare("DELETE FROM divisi WHERE id = ?")->execute([$id]);
            catatAktivitas('hapus_data', 'divisi', $id, $divisi['nama']);
            redirect('/admin/divisi.php?terhapus=1');
        } catch (PDOException $e) {
            $error = 'Divisi tidak bisa dihapus karena masih dipakai data lain.';
        }
    }
}

if (isset($_GET['ditambahkan'])) $success = 'Divisi baru berhasil ditambahkan dan langsung bisa dipilih saat membuat akun pembimbing.';
if (isset($_GET['tersimpan'])) $success = 'Perubahan divisi berhasil disimpan.';
if (isset($_GET['terhapus'])) $success = 'Divisi berhasil dihapus.';

$editData = isset($_GET['edit']) ? ambilDivisi((int) $_GET['edit']) : null;

// Nilai form: pakai input terakhir kalau submit gagal, supaya admin tidak mengetik ulang.
$gagalSubmit = $error !== '' && $_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['tambah']) || isset($_POST['edit']));
$nilaiNama = $gagalSubmit ? ($_POST['nama'] ?? '') : ($editData['nama'] ?? '');
$nilaiKeterangan = $gagalSubmit ? ($_POST['keterangan'] ?? '') : ($editData['keterangan'] ?? '');

$daftar = $pdo->query("
    SELECT d.*,
           COUNT(u.id) AS jumlah_pembimbing,
           COALESCE(SUM(u.status = 'aktif'), 0) AS jumlah_aktif
    FROM divisi d
    LEFT JOIN users u ON u.divisi_id = d.id AND u.role = 'pembimbing'
    GROUP BY d.id
    ORDER BY d.nama ASC
")->fetchAll();

$jumlahTanpaDivisi = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'pembimbing' AND divisi_id IS NULL")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Kelola Divisi — Admin</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
  <h1 class="h4 fw-bold mb-3">Divisi / Bagian</h1>

  <div class="alert alert-info small">
    🏢 Divisi/bagian instansi, dipilih saat membuat <a href="kelola_pembimbing.php" class="alert-link">akun pembimbing</a>.
  </div>

  <?php if ($jumlahTanpaDivisi > 0): ?>
    <div class="alert alert-warning small">
      ⚠️ Ada <b><?= $jumlahTanpaDivisi ?></b> akun pembimbing yang divisinya <b>belum diatur</b>
      (akun yang dibuat sebelum fitur ini ada).
      <a href="kelola_pembimbing.php?divisi=none" class="alert-link">Lihat & lengkapi divisinya</a>.
    </div>
  <?php endif; ?>

  <?php if ($success): ?><div class="alert alert-success small"><?= e($success) ?></div><?php endif; ?>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1"><?= $editData ? 'Ubah divisi' : 'Tambah divisi' ?></p>
      <h2 class="h6 fw-bold mb-3"><?= $editData ? 'Edit: ' . e($editData['nama']) : 'Divisi Baru' ?></h2>

      <form method="POST">
        <?= csrfField() ?>
        <?php if ($editData): ?><input type="hidden" name="id" value="<?= $editData['id'] ?>"><?php endif; ?>

        <div class="mb-3">
          <label class="form-label">Nama divisi/bagian</label>
          <input type="text" name="nama" class="form-control" maxlength="100" required
                 value="<?= e($nilaiNama) ?>" placeholder="Contoh: Bagian SDM & Umum">
        </div>

        <div class="mb-3">
          <label class="form-label">Keterangan <span class="text-muted fw-normal">(opsional)</span></label>
          <input type="text" name="keterangan" class="form-control" maxlength="255"
                 value="<?= e($nilaiKeterangan) ?>" placeholder="Contoh: Menangani kepegawaian dan administrasi umum">
          <p class="text-muted small mt-1 mb-0">Catatan singkat untuk admin, tidak ditampilkan ke mahasiswa.</p>
        </div>

        <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= e($error) ?></div><?php endif; ?>

        <div class="d-flex gap-2">
          <?php if ($editData): ?>
            <button type="submit" name="edit" value="1" class="btn btn-primary">Simpan Perubahan</button>
            <a href="divisi.php" class="btn btn-secondary">Batal</a>
          <?php else: ?>
            <button type="submit" name="tambah" value="1" class="btn btn-primary">Tambah Divisi</button>
          <?php endif; ?>
        </div>
      </form>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Daftar</p>
      <h2 class="h6 fw-bold mb-3">Semua Divisi (<?= count($daftar) ?>)</h2>

      <?php if (empty($daftar)): ?>
        <div class="text-muted small text-center py-3">Belum ada divisi. Tambahkan minimal 1 divisi sebelum membuat akun pembimbing.</div>
      <?php else: ?>
        <div class="table-responsive tabel-gulir" style="max-height:420px;">
          <table class="table table-sm align-middle mb-0">
            <thead>
              <tr>
                <th>Nama divisi/bagian</th>
                <th>Keterangan</th>
                <th class="text-center">Pembimbing</th>
                <th class="text-end">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($daftar as $d): ?>
                <tr>
                  <td class="fw-semibold"><?= e($d['nama']) ?></td>
                  <td class="small text-muted"><?= $d['keterangan'] ? e($d['keterangan']) : '-' ?></td>
                  <td class="text-center">
                    <?php if ($d['jumlah_pembimbing'] > 0): ?>
                      <a href="kelola_pembimbing.php?divisi=<?= $d['id'] ?>"><?= (int) $d['jumlah_pembimbing'] ?></a>
                      <span class="text-muted small">(<?= (int) $d['jumlah_aktif'] ?> aktif)</span>
                    <?php else: ?>
                      <span class="text-muted">0</span>
                    <?php endif; ?>
                  </td>
                  <td class="text-end">
                    <div class="d-inline-flex gap-1">
                      <a href="divisi.php?edit=<?= $d['id'] ?>" class="btn btn-outline-primary btn-sm">✏️ Edit</a>
                      <?php if ($d['jumlah_pembimbing'] > 0): ?>
                        <button type="button" class="btn btn-outline-danger btn-sm" disabled
                                title="Masih dipakai <?= (int) $d['jumlah_pembimbing'] ?> pembimbing">Hapus</button>
                      <?php else: ?>
                        <form method="POST" class="m-0" data-konfirmasi="Hapus divisi ini? Tindakan ini tidak bisa dibatalkan." data-konfirmasi-judul="Hapus divisi" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1">
                          <?= csrfField() ?>
                          <input type="hidden" name="hapus" value="<?= $d['id'] ?>">
                          <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <p class="text-muted small mt-2 mb-0">Divisi yang masih dipakai pembimbing tidak bisa dihapus.</p>
      <?php endif; ?>
    </div>
  </div>

  <a href="kelola_pembimbing.php" class="btn btn-outline-secondary">👥 Buka Kelola Pembimbing</a>
</div>

<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
