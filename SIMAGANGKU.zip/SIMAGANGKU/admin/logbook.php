<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin(['admin', 'pembimbing']);
$pdo = getDB();

/**
 * Pantau Log Book mahasiswa (admin & pembimbing) — hanya melihat, tidak mengubah.
 * Pembatasannya sama dengan halaman lain:
 * - admin      : semua mahasiswa,
 * - pembimbing : hanya mahasiswa bimbingannya, dan hanya yang satu cabang dengan akunnya
 *                (cabang diambil otomatis dari akun, tidak dipilih manual).
 */

[$sqlScope, $paramScope] = scopeMahasiswa('u');
$cabangPembimbing = cabangOtomatisPembimbing();
if (isPembimbing()) {
    if ($cabangPembimbing) {
        $sqlScope .= " AND u.cabang_id = ?";
        $paramScope[] = (int) $cabangPembimbing['id'];
    } else {
        $sqlScope .= " AND 1=0";
    }
}

// ---- Daftar mahasiswa yang boleh dilihat ----
$stmtMhs = $pdo->prepare("SELECT u.id, u.nama, u.identifier FROM users u
                          WHERE u.role='mahasiswa'{$sqlScope} ORDER BY u.nama ASC");
$stmtMhs->execute($paramScope);
$daftarMahasiswa = $stmtMhs->fetchAll();

// ---- Filter ----
$tanggalValid = fn($t) => is_string($t) && ($d = DateTime::createFromFormat('Y-m-d', $t)) && $d->format('Y-m-d') === $t;
$dari = $tanggalValid($_GET['dari'] ?? '') ? $_GET['dari'] : date('Y-m-01');
$sampai = $tanggalValid($_GET['sampai'] ?? '') ? $_GET['sampai'] : date('Y-m-d');
if ($sampai < $dari) [$dari, $sampai] = [$sampai, $dari];

$mahasiswaId = isset($_GET['mahasiswa']) && $_GET['mahasiswa'] !== '' ? (int) $_GET['mahasiswa'] : null;
// Id mahasiswa dari URL yang bukan wewenangnya diabaikan (data tetap terbatas lewat scope).
if ($mahasiswaId && !in_array($mahasiswaId, array_column($daftarMahasiswa, 'id'))) {
    $mahasiswaId = null;
}

// ---- Rekap per mahasiswa ----
$paramRekap = array_merge([$dari, $sampai], $paramScope);

// Kalau satu mahasiswa dipilih di filter, rekap ikut dibatasi ke mahasiswa itu saja.
// Sebelumnya rekap selalu menampilkan SEMUA mahasiswa walau filternya sudah dipakai,
// sehingga tidak cocok dengan daftar rincian di bawahnya.
$filterRekap = '';
if ($mahasiswaId) {
    $filterRekap = " AND u.id = ?";
    $paramRekap[] = $mahasiswaId;
}

$sqlRekap = "SELECT u.id, u.nama, u.identifier, u.tanggal_mulai, u.tanggal_selesai,
                    COUNT(l.id) AS jumlah_catatan,
                    COUNT(DISTINCT l.tanggal) AS jumlah_hari,
                    MAX(l.tanggal) AS terakhir_isi
             FROM users u
             LEFT JOIN logbook l ON l.user_id = u.id AND l.tanggal BETWEEN ? AND ?
             WHERE u.role='mahasiswa'{$sqlScope}{$filterRekap}
             GROUP BY u.id ORDER BY u.nama ASC";
$stmtRekap = $pdo->prepare($sqlRekap);
$stmtRekap->execute($paramRekap);
$rekap = $stmtRekap->fetchAll();

// Status kepatuhan tiap mahasiswa (diisi / tidak diisi / izin / sakit / tidak hadir),
// dihitung dari absensi + izin + hari libur + isi log book.
foreach ($rekap as $i => $r) {
    $statusMhs = statusLogbookRentang($r['id'], $dari, $sampai, $r);
    $rekap[$i]['status_harian'] = $statusMhs;
    $rekap[$i]['rekap_status'] = rekapStatusLogbook($statusMhs);
}

// Detail status harian untuk 1 mahasiswa (kalau difilter), termasuk hari yang kosong.
$statusHarianTerpilih = [];
if ($mahasiswaId) {
    foreach ($rekap as $r) {
        if ((int) $r['id'] === $mahasiswaId) { $statusHarianTerpilih = $r['status_harian']; break; }
    }
    krsort($statusHarianTerpilih);
}

// ---- Detail catatan ----
$sqlDetail = "SELECT l.*, u.nama, u.identifier FROM logbook l
              JOIN users u ON u.id = l.user_id
              WHERE l.tanggal BETWEEN ? AND ?{$sqlScope}";
$paramDetail = array_merge([$dari, $sampai], $paramScope);
if ($mahasiswaId) {
    $sqlDetail .= " AND l.user_id = ?";
    $paramDetail[] = $mahasiswaId;
}
$sqlDetail .= " ORDER BY l.tanggal DESC, u.nama ASC, l.id ASC";
$stmtDetail = $pdo->prepare($sqlDetail);
$stmtDetail->execute($paramDetail);
$detail = $stmtDetail->fetchAll();

$jam5 = fn($j) => $j ? substr($j, 0, 5) : '';
$qsExport = fn($id) => 'dari=' . urlencode($dari) . '&sampai=' . urlencode($sampai) . '&mahasiswa=' . (int) $id;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Log Book Mahasiswa — <?= e(labelRole(roleSekarang())) ?></title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
  <h1 class="h4 fw-bold mb-3">Log Book Mahasiswa</h1>

  <div class="alert alert-info small">
    📓 Catatan kegiatan harian mahasiswa (hanya bisa dipantau, tidak bisa diubah dari sini).
    Mahasiswa mengisinya di hari yang sama setelah absen masuk.
  </div>

  <?php if (isPembimbing()): ?>
    <p class="small mb-2">
      <span class="badge text-bg-info">🏢 Cabang: <?= e($cabangPembimbing['nama_cabang'] ?? 'Belum diatur') ?></span>
      <span class="text-muted">— diambil otomatis dari akunmu.</span>
    </p>
    <?php if (!$cabangPembimbing): ?>
      <p class="text-muted small">⚠️ Cabang pada akunmu belum diatur admin, jadi belum ada data yang tampil. Hubungi admin.</p>
    <?php endif; ?>
  <?php endif; ?>

  <div class="card mb-3">
    <div class="card-body">
      <form method="GET" class="row g-2 align-items-end">
        <div class="col-6 col-md-3">
          <label class="form-label small">Dari tanggal</label>
          <input type="date" name="dari" value="<?= e($dari) ?>" class="form-control">
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small">Sampai tanggal</label>
          <input type="date" name="sampai" value="<?= e($sampai) ?>" class="form-control">
        </div>
        <div class="col-12 col-md-4">
          <label class="form-label small">Mahasiswa</label>
          <select name="mahasiswa" class="form-select">
            <option value="">— Semua mahasiswa —</option>
            <?php foreach ($daftarMahasiswa as $m): ?>
              <option value="<?= $m['id'] ?>" <?= $mahasiswaId === (int) $m['id'] ? 'selected' : '' ?>><?= e($m['nama']) ?> (<?= e($m['identifier']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 col-md-2 d-flex gap-2">
          <button type="submit" class="btn btn-secondary flex-fill">Terapkan</button>
        </div>
      </form>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Rekap</p>
      <h2 class="h6 fw-bold mb-3">
        Ringkasan per Mahasiswa
        <?php if ($mahasiswaId): ?>
          <span class="text-muted fw-normal">— hanya mahasiswa yang dipilih</span>
        <?php endif; ?>
      </h2>
      <?php if (!$rekap): ?>
        <div class="text-muted small text-center py-3">Belum ada mahasiswa yang bisa ditampilkan.</div>
      <?php else: ?>
        <div class="table-responsive tabel-gulir" style="max-height:420px;">
          <table class="table table-sm align-middle mb-0">
            <thead>
              <tr>
                <th>Mahasiswa</th>
                <th class="text-center">Diisi</th>
                <th class="text-center">Tidak diisi</th>
                <th class="text-center">Izin/Sakit</th>
                <th class="text-center">Tidak hadir</th>
                <th>Terakhir mengisi</th>
                <th class="text-end">Unduh</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rekap as $r): ?>
                <tr>
                  <td class="fw-semibold"><?= e($r['nama']) ?><br><span class="text-muted small"><?= e($r['identifier']) ?></span></td>
                  <td class="text-center"><span class="badge text-bg-success"><?= (int) $r['rekap_status']['diisi'] ?></span>
                    <div class="text-muted small"><?= (int) $r['jumlah_catatan'] ?> catatan</div></td>
                  <td class="text-center"><?= $r['rekap_status']['tidak_diisi'] > 0
                        ? '<span class="badge text-bg-danger">' . (int) $r['rekap_status']['tidak_diisi'] . '</span>'
                        : '<span class="text-muted">0</span>' ?></td>
                  <td class="text-center"><?= (int) ($r['rekap_status']['izin'] + $r['rekap_status']['sakit']) ?></td>
                  <td class="text-center"><?= (int) $r['rekap_status']['tidak_hadir'] ?></td>
                  <td class="small">
                    <?= $r['terakhir_isi'] ? e(formatTanggalID($r['terakhir_isi'])) : '<span class="text-danger">belum pernah mengisi</span>' ?>
                  </td>
                  <td class="text-end">
                    <div class="d-inline-flex gap-1">
                      <a href="<?= BASE_URL ?>/mahasiswa/export_logbook.php?<?= $qsExport($r['id']) ?>" target="_blank" rel="noopener" class="btn btn-outline-secondary btn-sm">🖨️ PDF</a>
                      <a href="<?= BASE_URL ?>/mahasiswa/export_logbook_excel.php?<?= $qsExport($r['id']) ?>" class="btn btn-outline-success btn-sm">📊 Excel</a>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($statusHarianTerpilih): ?>
  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Status harian</p>
      <h2 class="h6 fw-bold mb-3">Hari per Hari</h2>
      <div class="table-responsive tabel-gulir" style="max-height:340px;">
        <table class="table table-sm align-middle mb-0">
          <thead><tr><th>Tanggal</th><th>Status</th><th class="text-center">Catatan</th></tr></thead>
          <tbody>
            <?php foreach ($statusHarianTerpilih as $tgl => $d): [$labelSt, $warnaSt] = labelStatusLogbook($d['status']); ?>
              <tr>
                <td class="text-nowrap small"><?= e(namaHariID(date('N', strtotime($tgl)))) ?>, <?= e(formatTanggalID($tgl)) ?></td>
                <td><span class="badge text-bg-<?= $warnaSt ?>"><?= e($labelSt) ?></span>
                  <?= $d['keterangan'] ? '<span class="text-muted small"> · ' . e($d['keterangan']) . '</span>' : '' ?></td>
                <td class="text-center"><?= $d['jumlah'] ?: '-' ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Detail</p>
      <h2 class="h6 fw-bold mb-3">Catatan Kegiatan (<?= count($detail) ?>)</h2>
      <?php if (!$detail): ?>
        <div class="text-muted small text-center py-3">Tidak ada catatan kegiatan pada rentang tanggal ini.</div>
      <?php else: ?>
        <div class="list-group list-group-flush" style="max-height:620px;overflow-y:auto;">
          <?php $tanggalTerakhir = null; foreach ($detail as $d): ?>
            <?php if ($d['tanggal'] !== $tanggalTerakhir): $tanggalTerakhir = $d['tanggal']; ?>
              <div class="list-group-item px-0 pb-1 pt-3 border-0"><b class="small"><?= e(formatTanggalID($d['tanggal'])) ?></b></div>
            <?php endif; ?>
            <div class="list-group-item px-0">
              <div class="small fw-semibold"><?= e($d['nama']) ?> </div>
              <div class="small" style="white-space:pre-line;overflow-wrap:anywhere;"><?= e($d['kegiatan']) ?></div>
              <?php if ($d['hasil']): ?><div class="small text-muted" style="overflow-wrap:anywhere;">Hasil: <?= e($d['hasil']) ?></div><?php endif; ?>
              <?php if ($d['kendala']): ?><div class="small text-muted" style="overflow-wrap:anywhere;">Kendala: <?= e($d['kendala']) ?></div><?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
