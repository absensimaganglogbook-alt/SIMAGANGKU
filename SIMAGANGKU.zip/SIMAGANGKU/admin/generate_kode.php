<?php
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');

if (!isLoggedIn() || $_SESSION['user_role'] !== 'admin') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Sesi habis, silakan login ulang.']);
    exit;
}

$kode = generateKodeUnik(kategoriDariInput($_GET['kategori'] ?? ''));
if ($kode === null) {
    echo json_encode(['ok' => false, 'message' => 'Pilih kategori magang dulu sebelum generate kode.']);
    exit;
}

echo json_encode(['ok' => true, 'kode' => $kode]);
