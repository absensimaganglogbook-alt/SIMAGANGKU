<?php
require_once __DIR__ . '/../includes/auth.php';
requireSuperAdmin();   // khusus super admin
$pdo = getDB();
$error = '';
$success = '';

// Pesan setelah pengalihan (Post/Redirect/Get) — hanya tampil sekali, tidak muncul lagi saat refresh.
if ($pesanSekali = ambilPesanSekali()) {
    if (($pesanSekali['tipe'] ?? 'success') === 'success') { $success = $pesanSekali['pesan']; }
    else { $error = $pesanSekali['pesan']; }
}

$adminSekarangId = (int) currentUser()['id'];

/**
 * Hitung berapa admin yang statusnya 'aktif' saat ini. Dipakai berkali-kali
 * di bawah untuk memastikan tidak ada aksi yang bikin institusi kehabisan
 * admin aktif sama sekali (semua orang ke-lock out, tidak ada yang bisa login).
 */
function jumlahAdminAktif($pdo) {
    return (int) $pdo->query("SELECT COUNT(*) c FROM users WHERE role='admin' AND status='aktif'")->fetch()['c'];
}

// ---- Tambah admin ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    verifikasiCsrf();
    $nama = trim($_POST['nama'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $passwordAwal = trim($_POST['password_awal'] ?? '');
    $passwordDigenerate = false;
    if ($passwordAwal === '') {
        $passwordAwal = bikinPasswordAcak();
        $passwordDigenerate = true;
    }

    if (!$nama || !$username) {
        $error = 'Nama dan username wajib diisi.';
    } elseif (!$passwordDigenerate && ($pesanKekuatan = validasiKekuatanPassword($passwordAwal)) !== null) {
        $error = $pesanKekuatan;
    } else {
        $cek = $pdo->prepare("SELECT id FROM users WHERE identifier=?");
        $cek->execute([$username]);
        if ($cek->fetch()) {
            $error = 'Username sudah dipakai (oleh admin atau mahasiswa lain). Pilih username lain.';
        } else {
            $hash = password_hash($passwordAwal, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (role, nama, identifier, password, status, harus_ganti_password)
                                    VALUES ('admin', ?, ?, ?, 'aktif', 1)");
            $stmt->execute([$nama, $username, $hash]);
            catatAktivitas('tambah_akun', 'admin', $pdo->lastInsertId(), $nama, 'Username: ' . $username);
            simpanPesanSekali("Admin berhasil ditambahkan. Password awal: $passwordAwal — catat/salin sekarang, tidak ditampilkan lagi setelah ini.");
            redirect('/admin/kelola_admin.php');
        }
    }
}

// ---- Reset password admin ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset'])) {
    verifikasiCsrf();
    $idReset = (int) ($_POST['reset_id'] ?? 0);
    $passwordBaru = trim($_POST['password_baru'] ?? '');
    $passwordDigenerate = false;
    if ($passwordBaru === '') {
        $passwordBaru = bikinPasswordAcak();
        $passwordDigenerate = true;
    }

    if (!$idReset) {
        $error = 'Admin tidak ditemukan.';
    } elseif (!$passwordDigenerate && ($pesanKekuatan = validasiKekuatanPassword($passwordBaru)) !== null) {
        $error = $pesanKekuatan;
    } else {
        $hash = password_hash($passwordBaru, PASSWORD_DEFAULT);
        $stmtNamaReset = $pdo->prepare("SELECT nama FROM users WHERE id=? AND role='admin'");
        $stmtNamaReset->execute([$idReset]);
        $namaAdminReset = $stmtNamaReset->fetchColumn();
        $stmt = $pdo->prepare("UPDATE users SET password=?, harus_ganti_password=1 WHERE id=? AND role='admin'");
        $stmt->execute([$hash, $idReset]);
        catatAktivitas('reset_password', 'admin', $idReset, $namaAdminReset ?: null);
        simpanPesanSekali("Password berhasil direset ke: $passwordBaru — catat/salin sekarang, tidak ditampilkan lagi setelah ini.");
        redirect('/admin/kelola_admin.php');
    }
}

// ---- Ubah status aktif/nonaktif ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle'])) {
    verifikasiCsrf();
    $idToggle = (int) $_POST['toggle'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id=? AND role='admin'");
    $stmt->execute([$idToggle]);
    $target = $stmt->fetch();

    if (!$target) {
        $error = 'Admin tidak ditemukan.';
    } elseif ($idToggle === $adminSekarangId) {
        $error = 'Kamu tidak bisa menonaktifkan akunmu sendiri. Minta admin lain untuk melakukannya kalau memang perlu.';
    } elseif ($target['status'] === 'aktif' && (int) $target['super_admin'] === 1 && jumlahSuperAdminAktif() <= 1) {
        $error = 'Tidak bisa menonaktifkan akun ini karena dia satu-satunya SUPER ADMIN yang masih aktif. Tambahkan super admin lain lewat database dulu.';
    } elseif ($target['status'] === 'aktif' && jumlahAdminAktif($pdo) <= 1) {
        $error = 'Tidak bisa menonaktifkan admin ini karena dia satu-satunya admin yang masih aktif. Aktifkan/tambahkan admin lain dulu sebelum menonaktifkan ini.';
    } else {
        $pdo->prepare("UPDATE users SET status = IF(status='aktif','nonaktif','aktif') WHERE id=? AND role='admin'")->execute([$idToggle]);
        catatAktivitas('ubah_status', 'admin', $idToggle, $target['nama'],
            'Status ' . $target['status'] . ' → ' . ($target['status'] === 'aktif' ? 'nonaktif' : 'aktif'));
        redirect('/admin/kelola_admin.php?status_diubah=1');
    }
}

// ---- Angkat / turunkan super admin ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ubah_level'])) {
    verifikasiCsrf();
    $idLevel = (int) $_POST['ubah_level'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id=? AND role='admin'");
    $stmt->execute([$idLevel]);
    $target = $stmt->fetch();

    if (!$target) {
        $error = 'Admin tidak ditemukan.';
    } elseif ((int) $target['super_admin'] === 0) {
        // Super admin tidak bisa diangkat lewat aplikasi — supaya jumlahnya tetap
        // terkendali dan tidak bertambah tanpa sepengetahuan pemilik sistem.
        $error = 'Admin biasa tidak bisa diangkat menjadi super admin dari aplikasi. '
               . 'Penambahan super admin hanya bisa dilakukan langsung di database oleh pengelola sistem.';
    } elseif ((int) $target['super_admin'] === 1 && jumlahSuperAdminAktif() <= 1) {
        // Tanpa penjaga ini, aplikasi bisa terkunci tanpa satu pun super admin.
        $error = 'Tidak bisa menurunkan akun ini karena dia satu-satunya super admin yang aktif. Tambahkan super admin lain lewat database dulu.';
    } else {
        // Hanya penurunan yang tersedia (pengangkatan ditolak di atas).
        $pdo->prepare("UPDATE users SET super_admin=0 WHERE id=? AND role='admin'")->execute([$idLevel]);
        catatAktivitas('ubah_level', 'admin', $idLevel, $target['nama'], 'Diturunkan menjadi admin biasa');
        redirect('/admin/kelola_admin.php?level_diubah=turun');
    }
}

// ---- Hapus admin ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {
    verifikasiCsrf();
    $idHapus = (int) $_POST['hapus'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id=? AND role='admin'");
    $stmt->execute([$idHapus]);
    $target = $stmt->fetch();
    $totalAdminSemua = (int) $pdo->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch()['c'];

    if (!$target) {
        $error = 'Admin tidak ditemukan.';
    } elseif ($idHapus === $adminSekarangId) {
        $error = 'Kamu tidak bisa menghapus akunmu sendiri. Minta admin lain untuk melakukannya kalau memang perlu.';
    } elseif ($totalAdminSemua <= 1) {
        $error = 'Tidak bisa menghapus admin ini karena dia satu-satunya akun admin yang tersisa di sistem.';
    } elseif ((int) $target['super_admin'] === 1 && jumlahSuperAdminAktif() <= 1) {
        $error = 'Tidak bisa menghapus akun ini karena dia satu-satunya SUPER ADMIN yang masih aktif. Tambahkan super admin lain lewat database dulu.';
    } elseif ($target['status'] === 'aktif' && jumlahAdminAktif($pdo) <= 1) {
        $error = 'Tidak bisa menghapus admin ini karena dia satu-satunya admin yang masih aktif. Aktifkan/tambahkan admin lain dulu sebelum menghapus ini.';
    } else {
        hapusBerkasMilikUser($idHapus);
        $pdo->prepare("DELETE FROM users WHERE id=? AND role='admin'")->execute([$idHapus]);
        catatAktivitas('hapus_akun', 'admin', $idHapus, $target['nama'], 'Username: ' . $target['identifier']);
        redirect('/admin/kelola_admin.php?dihapus=1');
    }
}

// ---- Pesan hasil aksi (tampil sebagai popup) ----
if (isset($_GET['status_diubah'])) $success = 'Status aktif/nonaktif admin berhasil diubah.';
if (($_GET['level_diubah'] ?? '') === 'turun') $success = 'Akun tersebut sekarang menjadi admin biasa.';
if (isset($_GET['dihapus'])) $success = 'Akun admin berhasil dihapus.';

// ---- Daftar admin (dengan pagination, walau biasanya jumlahnya sedikit) ----
$totalAdmin = (int) $pdo->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch()['c'];
$pg = paginasi($totalAdmin, $_GET['halaman'] ?? 1, 20);
$stmtDaftar = $pdo->prepare("SELECT * FROM users WHERE role='admin' ORDER BY nama ASC LIMIT {$pg['perHalaman']} OFFSET {$pg['offset']}");
$stmtDaftar->execute();
$daftarAdmin = $stmtDaftar->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Kelola Admin — Admin</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
    <div class="alert alert-warning small mb-3">
      🔒 Halaman ini <b>khusus super admin</b>. Admin biasa tetap bisa mengelola mahasiswa,
      pembimbing, pengaturan, dan Riwayat Aktivitas — hanya pengelolaan akun admin yang dibatasi.
      <br>Akun super admin <b>tidak bisa ditambah dari aplikasi</b>; penambahannya dilakukan langsung
      di database oleh pengelola sistem. Super admin yang ada bisa diturunkan menjadi admin biasa,
      selama masih tersisa minimal satu super admin yang aktif. Untuk pembimbing magang, pakai
      <a href="kelola_pembimbing.php" class="alert-link">akun Pembimbing</a>. Password awal/reset otomatis digenerate acak
      kalau dikosongkan, dan cuma ditampilkan <b>sekali</b> setelah dibuat.
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Tambah akun</p>
      <h2 class="h6 fw-bold mb-2">Admin Baru</h2>
      <form method="POST" style="margin-top:12px;">
        <?= csrfField() ?>
        <div class="mb-3"><label class="form-label">Nama lengkap</label><input type="text" name="nama" required class="form-control"></div>
        <div class="mb-3"><label class="form-label">Username (dipakai untuk login)</label><input type="text" name="username" required class="form-control"></div>
        <div class="mb-3">
          <label class="form-label">Password awal (kosongkan = digenerate otomatis secara acak)</label>
          <input type="text" name="password_awal" placeholder="Kosongkan untuk password acak otomatis" class="form-control">
        </div>
        <p class="text-muted small" style="margin-top:-4px;font-size:12px;">Kalau diisi manual: min. 8 karakter, memuat huruf besar, kecil, angka & simbol. Ditampilkan <b>sekali saja</b>.</p>

        <?php if ($error): ?><p class="alert alert-danger py-2 small"><?= e($error) ?></p><?php endif; ?>
        <?php if ($success): ?><p class="alert alert-success py-2 small"><?= e($success) ?></p><?php endif; ?>

        <button type="submit" name="tambah" value="1" class="btn btn-primary mt-2">Tambah Admin</button>
      </form>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-2">Daftar admin (<?= $totalAdmin ?>)</p>

      <div class="list-group list-group-flush daftar-gulir" style="max-height:420px;">
        <?php if (empty($daftarAdmin)): ?>
          <div class="text-muted small text-center py-3">Belum ada data admin.</div>
        <?php else: foreach ($daftarAdmin as $a): $iniAkunSendiri = ((int)$a['id'] === $adminSekarangId); ?>
          <div class="list-group-item px-0">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <div class="d-flex align-items-center gap-2">
                <b><?= e($a['nama']) ?></b>
                <?php if ($iniAkunSendiri): ?><span class="badge text-bg-warning">Kamu</span><?php endif; ?>
                <span class="badge text-bg-<?= (int)$a['super_admin'] === 1 ? 'danger' : 'secondary' ?>">
                  <?= (int)$a['super_admin'] === 1 ? 'Super Admin' : 'Admin biasa' ?>
                </span>
              </div>
              <span class="badge text-bg-<?= $a['status']==='aktif' ? 'success' : 'danger' ?>"><?= $a['status']==='aktif' ? 'Aktif' : 'Nonaktif' ?></span>
            </div>
            <div class="small text-muted">Username: <?= e($a['identifier']) ?></div>
            <div class="small text-muted">Dibuat: <?= e(formatTanggalID(substr($a['created_at'], 0, 10))) ?></div>

            <div class="d-flex flex-wrap gap-2 mt-2">
              <?php if (!$iniAkunSendiri): ?>
                <form method="POST" style="margin:0;" data-konfirmasi="Ubah status aktif/nonaktif admin ini?" data-konfirmasi-judul="Ubah status admin" data-konfirmasi-ya="Ya, ubah">
                  <?= csrfField() ?>
                  <input type="hidden" name="toggle" value="<?= $a['id'] ?>" class="form-control">
                  <button type="submit" class="btn btn-secondary btn-sm"><?= $a['status']==='aktif' ? 'Nonaktifkan' : 'Aktifkan' ?></button>
                </form>
              <?php endif; ?>
              <button type="button" class="btn btn-outline-secondary btn-sm btn-reset-pass" data-id="<?= $a['id'] ?>" data-nama="<?= $iniAkunSendiri ? 'akun kamu sendiri' : e($a['nama']) ?>">Reset Password<?= $iniAkunSendiri ? ' Sendiri' : '' ?></button>
              <?php if ((int) $a['super_admin'] === 1): // hanya penurunan; pengangkatan tidak tersedia di aplikasi ?>
                <form method="POST" style="margin:0;"
                      data-konfirmasi="Turunkan <?= e($a['nama']) ?> menjadi admin biasa? Dia tidak lagi bisa membuka menu Kelola Admin, dan statusnya tidak bisa dikembalikan lewat aplikasi."
                      data-konfirmasi-judul="Turunkan super admin"
                      data-konfirmasi-ya="Ya, turunkan" data-konfirmasi-bahaya="1">
                  <?= csrfField() ?>
                  <input type="hidden" name="ubah_level" value="<?= $a['id'] ?>">
                  <button type="submit" class="btn btn-outline-danger btn-sm">⬇️ Turunkan</button>
                </form>
              <?php endif; ?>
              <?php if (!$iniAkunSendiri): ?>
                <form method="POST" style="margin:0;" data-konfirmasi="Hapus akun admin ini? Jejak siapa yang mengisi absen manual/memproses izin sebelumnya (kalau ada) akan jadi kosong. Kalau cuma mau menonaktifkan sementara, pakai tombol Nonaktifkan saja. Tindakan hapus tidak bisa dibatalkan." data-konfirmasi-judul="Hapus akun admin" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1">
                  <?= csrfField() ?>
                  <input type="hidden" name="hapus" value="<?= $a['id'] ?>" class="form-control">
                  <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
              <?php else: ?>
                <span class="text-muted small" style="font-size:12px;">Nonaktifkan/hapus akun sendiri tidak bisa lewat sini.</span>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <?php if ($pg['totalHalaman'] > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
          <?php if ($pg['halaman'] > 1): ?>
            <a href="<?= urlHalaman($pg['halaman'] - 1) ?>" class="btn btn-outline-secondary btn-sm">← Sebelumnya</a>
          <?php else: ?><span></span><?php endif; ?>
          <span class="text-muted small">Halaman <?= $pg['halaman'] ?> dari <?= $pg['totalHalaman'] ?></span>
          <?php if ($pg['halaman'] < $pg['totalHalaman']): ?>
            <a href="<?= urlHalaman($pg['halaman'] + 1) ?>" class="btn btn-outline-secondary btn-sm">Berikutnya →</a>
          <?php else: ?><span></span><?php endif; ?>
        </div>
      <?php endif; ?>
      </div>
    </div>

    <a href="pengaturan.php" class="btn btn-outline-secondary mb-3">← Kembali ke Pengaturan</a>
</div>

<!-- Form tersembunyi untuk kirim reset password beserta password baru yang diketik admin -->
<form id="formReset" method="POST" style="display:none;">
  <?= csrfField() ?>
  <input type="hidden" name="reset" value="1">
  <input type="hidden" name="reset_id" id="resetId" value="">
  <input type="hidden" name="password_baru" id="resetPasswordBaru" value="">
</form>

<?php include __DIR__ . '/../includes/foot.php'; ?>
<script>
document.querySelectorAll('.btn-reset-pass').forEach(function (btn) {
  btn.addEventListener('click', async function () {
    var id = btn.dataset.id;
    var nama = btn.dataset.nama;
    // Input & konfirmasi memakai popup tengah layar (lihat includes/dialog.php)
    var pass = await Dialog.prompt({
      judul: 'Reset password',
      pesan: 'Password baru untuk ' + nama + ':\n(Kosongkan lalu klik Lanjutkan untuk digenerate otomatis secara acak)',
      placeholder: 'Kosongkan = password acak otomatis'
    });
    if (pass === null || pass === false) return; // dibatalkan
    pass = pass.trim();
    if (pass) {
      var kurangSyarat = [];
      if (pass.length < 8) kurangSyarat.push('minimal 8 karakter');
      if (!/[A-Z]/.test(pass)) kurangSyarat.push('huruf besar');
      if (!/[a-z]/.test(pass)) kurangSyarat.push('huruf kecil');
      if (!/[0-9]/.test(pass)) kurangSyarat.push('angka');
      if (!/[^A-Za-z0-9]/.test(pass)) kurangSyarat.push('simbol');
      if (kurangSyarat.length) {
        await Dialog.error('Kata sandi kurang: ' + kurangSyarat.join(', ') + '. Kosongkan saja kalau mau digenerate otomatis.', 'Password terlalu lemah');
        return;
      }
    }
    var lanjutReset = await Dialog.konfirmasi({
      judul: 'Reset password',
      pesan: pass
        ? ('Reset password ' + nama + ' ke "' + pass + '"?')
        : ('Reset password ' + nama + ' ke password acak baru? Password barunya ditampilkan sekali setelah ini.'),
      labelYa: 'Ya, reset'
    });
    if (!lanjutReset) return;
    document.getElementById('resetId').value = id;
    document.getElementById('resetPasswordBaru').value = pass;
    document.getElementById('formReset').submit();
  });
});
</script>
</body>
</html>
