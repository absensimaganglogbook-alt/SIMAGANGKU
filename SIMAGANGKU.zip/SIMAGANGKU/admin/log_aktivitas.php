<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('admin');
$pdo = getDB();

/**
 * Riwayat Aktivitas (audit log) — khusus admin.
 *
 * Halaman ini HANYA menampilkan. Tidak ada tombol ubah/hapus, bahkan untuk admin,
 * supaya catatannya tetap bernilai sebagai bukti. Satu-satunya penghapusan adalah
 * pembersihan otomatis sesuai masa simpan (Atur → Privasi & Storage).
 */

// ---- Filter ----
$tanggalValid = fn($t) => is_string($t) && ($d = DateTime::createFromFormat('Y-m-d', $t)) && $d->format('Y-m-d') === $t;
$dari = $tanggalValid($_GET['dari'] ?? '') ? $_GET['dari'] : date('Y-m-d', strtotime('-30 day'));
$sampai = $tanggalValid($_GET['sampai'] ?? '') ? $_GET['sampai'] : date('Y-m-d');
if ($sampai < $dari) [$dari, $sampai] = [$sampai, $dari];

$aksiPilihan = $_GET['aksi'] ?? '';
if (!array_key_exists($aksiPilihan, daftarAksiLog())) $aksiPilihan = '';

$pelakuPilihan = isset($_GET['pelaku']) && $_GET['pelaku'] !== '' ? (int) $_GET['pelaku'] : '';
$cari = trim($_GET['cari'] ?? '');

$where = ["DATE(l.created_at) BETWEEN ? AND ?"];
$params = [$dari, $sampai];
if ($aksiPilihan !== '') { $where[] = "l.aksi = ?"; $params[] = $aksiPilihan; }
if ($pelakuPilihan !== '') { $where[] = "l.user_id = ?"; $params[] = $pelakuPilihan; }
if ($cari !== '') {
    $where[] = "(l.objek_nama LIKE ? OR l.keterangan LIKE ? OR l.nama_pelaku LIKE ?)";
    $params[] = "%$cari%"; $params[] = "%$cari%"; $params[] = "%$cari%";
}
$sqlWhere = " WHERE " . implode(' AND ', $where);

$stmtTotal = $pdo->prepare("SELECT COUNT(*) c FROM log_aktivitas l" . $sqlWhere);
$stmtTotal->execute($params);
$total = (int) $stmtTotal->fetch()['c'];

$pg = paginasi($total, $_GET['halaman'] ?? 1, 30);
$stmt = $pdo->prepare("SELECT l.* FROM log_aktivitas l" . $sqlWhere . "
                       ORDER BY l.created_at DESC, l.id DESC
                       LIMIT {$pg['perHalaman']} OFFSET {$pg['offset']}");
$stmt->execute($params);
$daftar = $stmt->fetchAll();

// Daftar pelaku untuk dropdown (diambil dari isi log, termasuk akun yang sudah dihapus).
$daftarPelaku = $pdo->query("SELECT user_id, MAX(nama_pelaku) AS nama, MAX(role_pelaku) AS role
                             FROM log_aktivitas WHERE user_id IS NOT NULL
                             GROUP BY user_id ORDER BY nama ASC")->fetchAll();

$pengaturan = ambilPengaturan();
$retensiLog = (int) ($pengaturan['retensi_log_bulan'] ?? 0);

$warnaAksi = [
    'hapus_akun' => 'danger', 'hapus_data' => 'danger', 'hapus_absen' => 'danger',
    'tambah_akun' => 'success', 'tambah_data' => 'success',
    'ubah_akun' => 'primary', 'ubah_data' => 'primary', 'ubah_pengaturan' => 'primary',
    'ubah_status' => 'warning', 'reset_password' => 'warning', 'ubah_level' => 'dark', 'sertifikat' => 'success',
    'absen_manual' => 'secondary', 'proses_izin' => 'info', 'login_diblokir' => 'dark',
];
$labelObjek = [
    'mahasiswa' => 'Mahasiswa', 'pembimbing' => 'Pembimbing', 'admin' => 'Admin',
    'kategori' => 'Kategori', 'divisi' => 'Divisi', 'cabang' => 'Cabang',
    'hari_libur' => 'Hari libur', 'absensi' => 'Absensi', 'izin' => 'Izin/Sakit',
    'pengaturan' => 'Pengaturan', 'login' => 'Login',
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Riwayat Aktivitas — Admin</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
  <h1 class="h4 fw-bold mb-3">Riwayat Aktivitas</h1>

  <div class="alert alert-info small">
    🧾 Catatan siapa melakukan apa. <b>Tidak bisa diubah atau dihapus</b>, termasuk oleh admin.
    Masa simpan: <?= $retensiLog > 0 ? $retensiLog . ' bulan' : 'selamanya' ?>
    (<a href="pengaturan.php#retensi-foto" class="alert-link">ubah</a>).
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <form method="GET" class="row g-2 align-items-end">
        <div class="col-6 col-md-2">
          <label class="form-label small">Dari</label>
          <input type="date" name="dari" value="<?= e($dari) ?>" class="form-control">
        </div>
        <div class="col-6 col-md-2">
          <label class="form-label small">Sampai</label>
          <input type="date" name="sampai" value="<?= e($sampai) ?>" class="form-control">
        </div>
        <div class="col-12 col-md-3">
          <label class="form-label small">Jenis aksi</label>
          <select name="aksi" class="form-select">
            <option value="">— Semua aksi —</option>
            <?php foreach (daftarAksiLog() as $kode => $label): ?>
              <option value="<?= e($kode) ?>" <?= $aksiPilihan === $kode ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 col-md-3">
          <label class="form-label small">Pelaku</label>
          <select name="pelaku" class="form-select">
            <option value="">— Semua pelaku —</option>
            <?php foreach ($daftarPelaku as $p): ?>
              <option value="<?= (int) $p['user_id'] ?>" <?= $pelakuPilihan === (int) $p['user_id'] ? 'selected' : '' ?>>
                <?= e($p['nama']) ?> (<?= e(labelRole($p['role'])) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 col-md-2">
          <label class="form-label small">Cari</label>
          <input type="text" name="cari" value="<?= e($cari) ?>" class="form-control" placeholder="nama/keterangan">
        </div>
        <div class="col-12 d-flex gap-2">
          <button type="submit" class="btn btn-secondary btn-sm">Terapkan filter</button>
          <a href="log_aktivitas.php" class="btn btn-outline-secondary btn-sm">Reset</a>
        </div>
      </form>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Catatan</p>
      <h2 class="h6 fw-bold mb-3"><?= $total ?> aktivitas tercatat</h2>

      <?php if (!$daftar): ?>
        <div class="text-muted small text-center py-3">Tidak ada aktivitas pada filter ini.</div>
      <?php else: ?>
        <div class="table-responsive tabel-gulir" style="max-height:560px;">
          <table class="table table-sm align-middle mb-0">
            <thead>
              <tr>
                <th style="white-space:nowrap;">Waktu</th>
                <th>Pelaku</th>
                <th>Aksi</th>
                <th>Objek</th>
                <th>Keterangan</th>
                <th>IP</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($daftar as $l): ?>
                <tr>
                  <td class="small text-nowrap">
                    <?= e(formatTanggalID(substr($l['created_at'], 0, 10))) ?><br>
                    <span class="text-muted"><?= e(substr($l['created_at'], 11, 5)) ?></span>
                  </td>
                  <td class="small">
                    <b><?= e($l['nama_pelaku']) ?></b><br>
                    <span class="text-muted"><?= e(labelRole($l['role_pelaku'])) ?><?= $l['user_id'] ? '' : ' · akun dihapus' ?></span>
                  </td>
                  <td><span class="badge text-bg-<?= $warnaAksi[$l['aksi']] ?? 'secondary' ?>"><?= e(labelAksiLog($l['aksi'])) ?></span></td>
                  <td class="small">
                    <?= $l['objek_nama'] ? '<b>' . e($l['objek_nama']) . '</b><br>' : '' ?>
                    <span class="text-muted"><?= e($labelObjek[$l['objek_tipe']] ?? ($l['objek_tipe'] ?: '-')) ?></span>
                  </td>
                  <td class="small"><?= $l['keterangan'] ? e($l['keterangan']) : '-' ?></td>
                  <td class="small text-muted"><?= e($l['ip_address'] ?: '-') ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <?php if ($pg['totalHalaman'] > 1): ?>
          <div class="d-flex justify-content-between align-items-center mt-3">
            <?php if ($pg['halaman'] > 1): ?>
              <a href="<?= urlHalaman($pg['halaman'] - 1) ?>" class="btn btn-outline-secondary btn-sm">← Sebelumnya</a>
            <?php else: ?><span></span><?php endif; ?>
            <span class="text-muted small">Halaman <?= $pg['halaman'] ?> dari <?= $pg['totalHalaman'] ?></span>
            <?php if ($pg['halaman'] < $pg['totalHalaman']): ?>
              <a href="<?= urlHalaman($pg['halaman'] + 1) ?>" class="btn btn-outline-secondary btn-sm">Berikutnya →</a>
            <?php else: ?><span></span><?php endif; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
