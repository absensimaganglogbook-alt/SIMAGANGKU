<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/laporan_data.php';
requireLogin(['admin', 'pembimbing']);

$dariTanggal = $_GET['dari'] ?? date('Y-m-01');
$sampaiTanggal = $_GET['sampai'] ?? date('Y-m-d');
$mahasiswaId = isset($_GET['mahasiswa']) && $_GET['mahasiswa'] !== '' ? (int)$_GET['mahasiswa'] : null;
// Pembimbing hanya boleh melihat mahasiswa bimbingannya. Kalau id mahasiswa di URL
// bukan wewenangnya, abaikan filter itu (data tetap dibatasi ke bimbingannya sendiri).
if ($mahasiswaId && !bolehAksesMahasiswa($mahasiswaId)) {
    $mahasiswaId = null;
}
$kategoriPilihan = kategoriDariInput($_GET['kategori'] ?? '');
$cabangPilihan = isset($_GET['cabang']) && $_GET['cabang'] !== '' ? (int)$_GET['cabang'] : '';
if ($cabangPilihan && !ambilCabang($cabangPilihan)) {
    $cabangPilihan = '';
}
// Khusus pembimbing: cabang tidak dipilih manual — otomatis memakai cabang pada akunnya
// (sama seperti halaman Absen Manual). -1 dipakai kalau cabang akunnya belum diatur admin,
// supaya tidak ada data yang cocok sampai admin mengaturnya.
$cabangPembimbing = cabangOtomatisPembimbing();
if (isPembimbing()) {
    $cabangPilihan = $cabangPembimbing ? (int) $cabangPembimbing['id'] : -1;
}

$items = ambilDataLaporan($dariTanggal, $sampaiTanggal, $mahasiswaId, $kategoriPilihan ?: null, $cabangPilihan ?: null, idPembimbingScope());

$namaFile = 'laporan-absensi';
if ($mahasiswaId) {
    $stmt = getDB()->prepare("SELECT nama FROM users WHERE id=?");
    $stmt->execute([$mahasiswaId]);
    $nama = $stmt->fetch()['nama'] ?? 'mahasiswa';
    $namaFile .= '_' . preg_replace('/[^a-zA-Z0-9]+/', '-', $nama);
} else {
    if ($kategoriPilihan) {
        $namaFile .= '_' . preg_replace('/[^a-zA-Z0-9]+/', '-', labelKategori($kategoriPilihan));
    }
    if ($cabangPilihan) {
        $cabangObj = ambilCabang($cabangPilihan);
        $namaFile .= '_' . preg_replace('/[^a-zA-Z0-9]+/', '-', $cabangObj['nama_cabang']);
    }
}
if (isPembimbing() && !$mahasiswaId) {
    $namaFile .= '_bimbingan-' . preg_replace('/[^a-zA-Z0-9]+/', '-', currentUser()['nama']);
}
// Tanggal ikut disaring karakternya supaya nilai aneh dari URL tidak merusak header nama file.
$namaFile .= '_' . preg_replace('/[^0-9-]/', '', $dariTanggal) . '_sd_' . preg_replace('/[^0-9-]/', '', $sampaiTanggal) . '.xls';

// Teknik native tanpa library: kirim HTML table dengan header file .xls.
// Microsoft Excel & LibreOffice Calc otomatis membukanya sebagai spreadsheet.
header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $namaFile . '"');
echo "\xEF\xBB\xBF"; // BOM supaya karakter UTF-8 tampil benar di Excel
?>
<?php $ringkas = ringkasanLaporan($items); ?>
<table border="1">
  <tr><td colspan="7" style="font-size:14px;font-weight:bold;">RINGKASAN PERIODE <?= e(formatRentangTanggal($dariTanggal, $sampaiTanggal)) ?></td></tr>
  <?php foreach (daftarRingkasanLaporan($ringkas) as [$labelRingkas, $nilai, $warna]): ?>
    <tr><td colspan="3"><?= e($labelRingkas) ?></td><td colspan="4"><?= (int) $nilai ?></td></tr>
  <?php endforeach; ?>
  <tr><td colspan="7"></td></tr>

  <tr>
    <th>Tanggal</th><th>Nama</th><th>Jenis</th><th>Jam</th><th>Jarak</th><th>Status</th><th>Keterangan</th>
  </tr>
  <?php foreach ($items as $it): $warna = warnaLaporanCetak($it); ?>
  <tr<?= $warna ? ' style="background-color:'.$warna['bg'].';color:'.$warna['teks'].';"' : '' ?>>
    <td><?= e($it['tanggal_tampil']) ?></td>
    <td><?= e($it['nama']) ?></td>
    <td><?= e($it['jenis']) ?></td>
    <td><?= e($it['jam']) ?></td>
    <td><?= e($it['jarak']) ?></td>
    <td><b><?= e($it['status']) ?></b></td>
    <td><?= e($it['keterangan']) ?></td>
  </tr>
  <?php endforeach; ?>
</table>
