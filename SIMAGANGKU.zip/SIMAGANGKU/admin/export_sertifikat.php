<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin(['admin', 'pembimbing']);

/**
 * Rekap status sertifikat magang dalam bentuk Excel (.xls).
 * Memakai pola yang sama dengan export laporan absensi: tabel HTML yang dikirim
 * dengan header Excel, jadi tidak butuh library tambahan.
 *
 * Pembimbing otomatis hanya mendapat mahasiswa bimbingannya (scopeMahasiswa).
 */

$pdo = getDB();
$hariPengingat = hariPengingatSertifikat();
[$sqlScope, $paramScope] = scopeMahasiswa('u');

$statusFilter = in_array($_GET['status'] ?? '', ['perlu', 'sudah', 'semua'], true) ? $_GET['status'] : 'semua';
$cari = trim($_GET['cari'] ?? '');

// Filter rentang tanggal selesai magang (sama seperti di halaman Sertifikat).
$tanggalValid = fn($t) => is_string($t) && ($d = DateTime::createFromFormat('Y-m-d', $t)) && $d->format('Y-m-d') === $t;
$dari = $tanggalValid($_GET['dari'] ?? '') ? $_GET['dari'] : '';
$sampai = $tanggalValid($_GET['sampai'] ?? '') ? $_GET['sampai'] : '';
if ($dari && $sampai && $sampai < $dari) [$dari, $sampai] = [$sampai, $dari];

$where = ["u.role = 'mahasiswa'"];
$params = [];
if ($statusFilter === 'perlu') {
    $where[] = "u.sertifikat_selesai_tgl IS NULL AND u.tanggal_selesai IS NOT NULL
                AND DATEDIFF(u.tanggal_selesai, CURDATE()) <= ?";
    $params[] = $hariPengingat > 0 ? $hariPengingat : 0;
} elseif ($statusFilter === 'sudah') {
    $where[] = "u.sertifikat_selesai_tgl IS NOT NULL";
}
if ($cari !== '') {
    $where[] = "(u.nama LIKE ? OR u.identifier LIKE ?)";
    $params[] = "%$cari%";
    $params[] = "%$cari%";
}
if ($dari !== '') { $where[] = "u.tanggal_selesai >= ?"; $params[] = $dari; }
if ($sampai !== '') { $where[] = "u.tanggal_selesai <= ?"; $params[] = $sampai; }

$stmt = $pdo->prepare("SELECT u.nama, u.identifier, u.kampus, u.status,
                              u.tanggal_mulai, u.tanggal_selesai, u.sertifikat_selesai_tgl,
                              k.nama AS nama_kategori, c.nama_cabang,
                              p.nama AS nama_pembimbing, s.nama AS nama_penanda
                       FROM users u
                       LEFT JOIN kategori k ON k.id = u.kategori_id
                       LEFT JOIN cabang c ON c.id = u.cabang_id
                       LEFT JOIN users p ON p.id = u.pembimbing_id
                       LEFT JOIN users s ON s.id = u.sertifikat_oleh_id
                       WHERE " . implode(' AND ', $where) . $sqlScope . "
                       ORDER BY (u.sertifikat_selesai_tgl IS NOT NULL) ASC,
                                u.tanggal_selesai IS NULL, u.tanggal_selesai ASC, u.nama ASC");
$stmt->execute(array_merge($params, $paramScope));
$baris = $stmt->fetchAll();

// Riwayat sertifikat milik akun mahasiswa yang SUDAH DIHAPUS (dari tabel arsip),
// supaya rekapnya tidak kehilangan data lama.
$arsip = [];
if ($statusFilter !== 'perlu') {
    $whereArsip = ['a.user_id IS NULL'];
    $paramArsip = [];
    if ($cari !== '') { $whereArsip[] = "(a.nama LIKE ? OR a.identifier LIKE ?)"; $paramArsip[] = "%$cari%"; $paramArsip[] = "%$cari%"; }
    if ($dari !== '') { $whereArsip[] = "a.tanggal_selesai >= ?"; $paramArsip[] = $dari; }
    if ($sampai !== '') { $whereArsip[] = "a.tanggal_selesai <= ?"; $paramArsip[] = $sampai; }
    if (isPembimbing()) { $whereArsip[] = "a.pembimbing_id = ?"; $paramArsip[] = (int) ($_SESSION['user_id'] ?? 0); }

    $stmtArsip = $pdo->prepare("SELECT * FROM arsip_sertifikat a WHERE " . implode(' AND ', $whereArsip)
                             . " ORDER BY a.sertifikat_tgl DESC, a.nama ASC");
    $stmtArsip->execute($paramArsip);
    $arsip = $stmtArsip->fetchAll();
}

$pengaturan = ambilPengaturan();
$labelStatus = ['perlu' => 'perlu-disiapkan', 'sudah' => 'sudah-dibuat', 'semua' => 'semua'];
$namaFile = 'rekap-sertifikat_' . $labelStatus[$statusFilter] . '_' . date('Ymd') . '.xls';

header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $namaFile . '"');
header('Pragma: no-cache');
header('Expires: 0');

echo "\xEF\xBB\xBF"; // BOM supaya huruf beraksen tampil benar di Excel
?>
<table border="1">
  <tr><td colspan="9" style="font-size:16px;font-weight:bold;">REKAP SERTIFIKAT MAGANG</td></tr>
  <tr><td colspan="9"><?= e($pengaturan['nama_instansi']) ?></td></tr>
  <tr><td colspan="9">Dicetak: <?= e(formatTanggalID(date('Y-m-d'))) ?> · Filter: <?= e($labelStatus[$statusFilter]) ?><?= $cari !== '' ? ' · Pencarian: ' . e($cari) : '' ?></td></tr>
  <tr><td colspan="9">Rentang tanggal selesai magang: <?= ($dari === '' && $sampai === '') ? 'semua tanggal'
      : e(formatRentangTanggal($dari ?: '1970-01-01', $sampai ?: date('Y-m-d'))) ?></td></tr>
  <tr><td colspan="9"></td></tr>

  <tr style="background:#eeeeee;font-weight:bold;">
    <td>No</td>
    <td>Nama</td>
    <td>NIM/Username</td>
    <td>Asal kampus/sekolah</td>
    <td>Kategori</td>
    <td>Periode magang</td>
    <td>Pembimbing</td>
    <td>Status sertifikat</td>
    <td>Ditandai oleh &amp; tanggal</td>
  </tr>
  <?php if (!$baris): ?>
    <tr><td colspan="9">Tidak ada data untuk filter ini.</td></tr>
  <?php else: foreach ($baris as $i => $b): ?>
    <tr>
      <td><?= $i + 1 ?></td>
      <td><?= e($b['nama']) ?></td>
      <td><?= e($b['identifier']) ?></td>
      <td><?= e($b['kampus'] ?: '-') ?></td>
      <td><?= e($b['nama_kategori'] ?: '-') ?></td>
      <td><?= e(formatRentangTanggal($b['tanggal_mulai'] ?: '-', $b['tanggal_selesai'] ?: '-')) ?></td>
      <td><?= e($b['nama_pembimbing'] ?: '-') ?></td>
      <td><?= $b['sertifikat_selesai_tgl'] ? 'Sudah dibuat' : 'Belum dibuat' ?></td>
      <td>
        <?= $b['sertifikat_selesai_tgl']
            ? e(($b['nama_penanda'] ?: 'tidak diketahui') . ' · ' . formatTanggalID($b['sertifikat_selesai_tgl']))
            : '-' ?>
      </td>
    </tr>
  <?php endforeach; endif; ?>

  <?php foreach ($arsip as $i => $a): ?>
    <tr>
      <td><?= count($baris) + $i + 1 ?></td>
      <td><?= e($a['nama']) ?></td>
      <td><?= e($a['identifier']) ?></td>
      <td><?= e($a['kampus'] ?: '-') ?></td>
      <td><?= e($a['nama_kategori'] ?: '-') ?></td>
      <td><?= e(formatRentangTanggal($a['tanggal_mulai'] ?: '-', $a['tanggal_selesai'] ?: '-')) ?></td>
      <td><?= e($a['nama_pembimbing'] ?: '-') ?></td>
      <td>Sudah dibuat (akun mahasiswa sudah dihapus)</td>
      <td><?= e(($a['ditandai_oleh'] ?: 'tidak diketahui') . ' · ' . formatTanggalID($a['sertifikat_tgl'])) ?></td>
    </tr>
  <?php endforeach; ?>

  <tr><td colspan="9"></td></tr>
  <tr><td colspan="2">Jumlah baris</td><td colspan="7"><?= count($baris) + count($arsip) ?><?= $arsip ? ' (termasuk ' . count($arsip) . ' dari akun yang sudah dihapus)' : '' ?></td></tr>
</table>
