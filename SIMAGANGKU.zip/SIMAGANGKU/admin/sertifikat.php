<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin(['admin', 'pembimbing']);
$pdo = getDB();

/**
 * Menu Sertifikat — tempat terpusat untuk menandai sertifikat magang sudah dibuat,
 * sekaligus MEMBATALKAN tanda itu kalau salah tekan.
 *
 * Sebelumnya tombol pembatalan hanya ada di halaman Mahasiswa (khusus admin),
 * sehingga pembimbing tidak punya jalan untuk memperbaiki kesalahannya sendiri.
 *
 * Pembimbing otomatis hanya melihat mahasiswa bimbingannya (scopeMahasiswa),
 * sama seperti halaman lain di panel ini.
 */

// ---- Tandai / batalkan ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sertifikat_id'])) {
    verifikasiCsrf();
    $galat = ubahStatusSertifikat($_POST['sertifikat_id'], ($_POST['sertifikat_aksi'] ?? '') === 'tandai');

    // Filter yang sedang dipakai ikut dibawa balik supaya tampilan tidak "lompat".
    $kembali = array_filter([
        'status' => $_GET['status'] ?? null,
        'cari' => $_GET['cari'] ?? null,
        'halaman' => $_GET['halaman'] ?? null,
        'hasil' => $galat ? 'gagal' : (($_POST['sertifikat_aksi'] ?? '') === 'tandai' ? 'ditandai' : 'dibatalkan'),
    ], fn($v) => $v !== null && $v !== '');
    redirect(panelBase() . '/sertifikat.php?' . http_build_query($kembali));
}

switch ($_GET['hasil'] ?? '') {
    case 'ditandai':   $success = 'Sertifikat ditandai sudah dibuat. Mahasiswa itu tidak muncul lagi di daftar "perlu disiapkan".'; break;
    case 'dibatalkan': $success = 'Tanda sertifikat dibatalkan. Mahasiswa itu kembali masuk daftar "perlu disiapkan".'; break;
    case 'gagal':      $error = 'Status sertifikat gagal diubah. Mungkin mahasiswa itu bukan wewenangmu.'; break;
}

// ---- Filter ----
$statusFilter = in_array($_GET['status'] ?? '', ['perlu', 'sudah', 'semua'], true) ? $_GET['status'] : 'perlu';
$cari = trim($_GET['cari'] ?? '');

// Filter tanggal: memakai TANGGAL SELESAI MAGANG, supaya berlaku untuk yang sudah
// maupun belum dibuat sertifikatnya (mis. untuk merekap satu angkatan).
$tanggalValid = fn($t) => is_string($t) && ($d = DateTime::createFromFormat('Y-m-d', $t)) && $d->format('Y-m-d') === $t;
$dari = $tanggalValid($_GET['dari'] ?? '') ? $_GET['dari'] : '';
$sampai = $tanggalValid($_GET['sampai'] ?? '') ? $_GET['sampai'] : '';
if ($dari && $sampai && $sampai < $dari) [$dari, $sampai] = [$sampai, $dari];
$hariPengingat = hariPengingatSertifikat();

[$sqlScope, $paramScope] = scopeMahasiswa('u');

$where = ["u.role = 'mahasiswa'"];
$params = [];
if ($statusFilter === 'perlu') {
    // Belum ditandai DAN masa magangnya sudah dekat/berakhir.
    $where[] = "u.sertifikat_selesai_tgl IS NULL AND u.tanggal_selesai IS NOT NULL
                AND DATEDIFF(u.tanggal_selesai, CURDATE()) <= ?";
    $params[] = $hariPengingat > 0 ? $hariPengingat : 0;
} elseif ($statusFilter === 'sudah') {
    $where[] = "u.sertifikat_selesai_tgl IS NOT NULL";
}
if ($cari !== '') {
    $where[] = "(u.nama LIKE ? OR u.identifier LIKE ?)";
    $params[] = "%$cari%";
    $params[] = "%$cari%";
}
if ($dari !== '') { $where[] = "u.tanggal_selesai >= ?"; $params[] = $dari; }
if ($sampai !== '') { $where[] = "u.tanggal_selesai <= ?"; $params[] = $sampai; }
$sqlWhere = " WHERE " . implode(' AND ', $where) . $sqlScope;
$paramSemua = array_merge($params, $paramScope);

// ---- Ringkasan angka (selalu memakai scope yang sama) ----
$stmtRingkas = $pdo->prepare("SELECT
        SUM(CASE WHEN u.sertifikat_selesai_tgl IS NULL AND u.tanggal_selesai IS NOT NULL
                  AND DATEDIFF(u.tanggal_selesai, CURDATE()) <= ? THEN 1 ELSE 0 END) AS perlu,
        SUM(CASE WHEN u.sertifikat_selesai_tgl IS NULL AND u.tanggal_selesai IS NOT NULL
                  AND u.tanggal_selesai < CURDATE() THEN 1 ELSE 0 END) AS lewat,
        SUM(CASE WHEN u.sertifikat_selesai_tgl IS NOT NULL THEN 1 ELSE 0 END) AS sudah,
        COUNT(*) AS total
    FROM users u WHERE u.role='mahasiswa'{$sqlScope}");
$stmtRingkas->execute(array_merge([$hariPengingat > 0 ? $hariPengingat : 0], $paramScope));
$ringkas = $stmtRingkas->fetch();

// ---- Daftar ----
$stmtHitung = $pdo->prepare("SELECT COUNT(*) c FROM users u{$sqlWhere}");
$stmtHitung->execute($paramSemua);
$total = (int) $stmtHitung->fetch()['c'];

$pg = paginasi($total, $_GET['halaman'] ?? 1, 20);
$stmt = $pdo->prepare("SELECT u.id, u.nama, u.identifier, u.kampus, u.status,
                              u.tanggal_mulai, u.tanggal_selesai, u.sertifikat_selesai_tgl,
                              DATEDIFF(u.tanggal_selesai, CURDATE()) AS sisa_hari,
                              k.nama AS nama_kategori, c.nama_cabang,
                              p.nama AS nama_pembimbing, s.nama AS nama_penanda
                       FROM users u
                       LEFT JOIN kategori k ON k.id = u.kategori_id
                       LEFT JOIN cabang c ON c.id = u.cabang_id
                       LEFT JOIN users p ON p.id = u.pembimbing_id
                       LEFT JOIN users s ON s.id = u.sertifikat_oleh_id
                       {$sqlWhere}
                       ORDER BY (u.sertifikat_selesai_tgl IS NOT NULL) ASC,
                                u.tanggal_selesai IS NULL, u.tanggal_selesai ASC, u.nama ASC
                       LIMIT {$pg['perHalaman']} OFFSET {$pg['offset']}");
$stmt->execute($paramSemua);
$daftar = $stmt->fetchAll();

$qsExport = http_build_query(array_filter([
    'status' => $statusFilter, 'cari' => $cari, 'dari' => $dari, 'sampai' => $sampai,
], fn($v) => $v !== ''));

// Arsip sertifikat milik mahasiswa yang AKUNNYA SUDAH DIHAPUS — ikut ditampilkan
// (tanpa tombol aksi) supaya riwayatnya tidak hilang dari pandangan.
$arsipTerhapus = [];
if ($statusFilter !== 'perlu') {
    $whereArsip = ['a.user_id IS NULL'];
    $paramArsip = [];
    if ($cari !== '') { $whereArsip[] = "(a.nama LIKE ? OR a.identifier LIKE ?)"; $paramArsip[] = "%$cari%"; $paramArsip[] = "%$cari%"; }
    if ($dari !== '') { $whereArsip[] = "a.tanggal_selesai >= ?"; $paramArsip[] = $dari; }
    if ($sampai !== '') { $whereArsip[] = "a.tanggal_selesai <= ?"; $paramArsip[] = $sampai; }
    if (isPembimbing()) { $whereArsip[] = "a.pembimbing_id = ?"; $paramArsip[] = (int) ($_SESSION['user_id'] ?? 0); }

    $stmtArsip = $pdo->prepare("SELECT * FROM arsip_sertifikat a WHERE " . implode(' AND ', $whereArsip)
                             . " ORDER BY a.sertifikat_tgl DESC, a.nama ASC");
    $stmtArsip->execute($paramArsip);
    $arsipTerhapus = $stmtArsip->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Sertifikat — <?= e(labelRole(roleSekarang())) ?></title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
  <h1 class="h4 fw-bold mb-3">Sertifikat Magang</h1>

  <div class="alert alert-info small">
    🎓 Tandai di sini kalau sertifikat seorang mahasiswa sudah dibuat, supaya tidak muncul lagi
    sebagai pengingat. Salah tekan? Tekan <b>Batalkan</b> pada daftar "sudah dibuat".
    Setiap perubahan tercatat lengkap dengan nama pelakunya.
  </div>

  <div class="row g-2 mb-3">
    <?php foreach ([
      ['Perlu disiapkan', (int) $ringkas['perlu'], 'warning', 'perlu'],
      ['Sudah lewat tanggal', (int) $ringkas['lewat'], 'danger', 'perlu'],
      ['Sudah dibuat', (int) $ringkas['sudah'], 'success', 'sudah'],
      ['Total mahasiswa', (int) $ringkas['total'], 'secondary', 'semua'],
    ] as [$labelAngka, $nilai, $warna, $tujuan]): ?>
      <div class="col-6 col-md-3">
        <a href="?status=<?= e($tujuan) ?>" class="text-decoration-none">
          <div class="card h-100 border-<?= $warna ?>">
            <div class="card-body py-3">
              <div class="h4 fw-bold mb-0 text-<?= $warna === 'secondary' ? 'body' : $warna ?>"><?= $nilai ?></div>
              <div class="small text-muted"><?= e($labelAngka) ?></div>
            </div>
          </div>
        </a>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <form method="GET" class="row g-2 align-items-end">
        <div class="col-12 col-md-4">
          <label class="form-label small">Status</label>
          <select name="status" class="form-select" onchange="this.form.submit()">
            <option value="perlu" <?= $statusFilter === 'perlu' ? 'selected' : '' ?>>Perlu disiapkan</option>
            <option value="sudah" <?= $statusFilter === 'sudah' ? 'selected' : '' ?>>Sudah dibuat</option>
            <option value="semua" <?= $statusFilter === 'semua' ? 'selected' : '' ?>>Semua mahasiswa</option>
          </select>
        </div>
        <div class="col-12 col-md-5">
          <label class="form-label small">Cari nama / username</label>
          <input type="text" name="cari" value="<?= e($cari) ?>" class="form-control" placeholder="mis. Nur Aisyah atau PKL001">
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small">Magang selesai dari</label>
          <input type="date" name="dari" value="<?= e($dari) ?>" class="form-control">
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small">sampai</label>
          <input type="date" name="sampai" value="<?= e($sampai) ?>" class="form-control">
        </div>
        <div class="col-12 col-md-3 d-flex gap-2">
          <button type="submit" class="btn btn-secondary flex-fill">Terapkan</button>
          <a href="sertifikat.php" class="btn btn-outline-secondary">Reset</a>
        </div>
      </form>
      <p class="text-muted small mt-2 mb-0">
        "Perlu disiapkan" = masa magang berakhir dalam <?= (int) $hariPengingat ?> hari ke depan atau sudah lewat,
        dan sertifikatnya belum ditandai. Pilih <b>Semua mahasiswa</b> kalau ingin menandai lebih awal.
        Isian tanggal menyaring berdasarkan <b>tanggal selesai magang</b> — berguna untuk merekap satu angkatan,
        dan ikut terbawa saat mengunduh Excel.
      </p>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <div>
          <p class="text-primary fw-semibold small mb-1">Daftar</p>
          <h2 class="h6 fw-bold mb-0"><?= $total ?> mahasiswa</h2>
        </div>
        <a href="<?= BASE_URL . panelBase() ?>/export_sertifikat.php<?= $qsExport ? '?' . e($qsExport) : '' ?>" class="btn btn-outline-success btn-sm">
          📊 Unduh rekap Excel
        </a>
      </div>

      <?php if (!$daftar): ?>
        <div class="text-muted small text-center py-3">
          <?= $statusFilter === 'perlu'
              ? 'Tidak ada sertifikat yang perlu disiapkan saat ini. 🎉'
              : 'Tidak ada data yang cocok dengan filter ini.' ?>
        </div>
      <?php else: ?>
        <div class="list-group list-group-flush daftar-gulir" style="max-height:560px;">
          <?php foreach ($daftar as $m):
            $sudah = (bool) $m['sertifikat_selesai_tgl'];
            $sisa = $m['tanggal_selesai'] !== null ? (int) $m['sisa_hari'] : null;
          ?>
            <div class="list-group-item px-0">
              <div class="d-flex justify-content-between align-items-start gap-2 flex-wrap">
                <div>
                  <b><?= e($m['nama']) ?></b>
                  <span class="text-muted small">· <?= e($m['identifier']) ?><?= $m['kampus'] ? ' · ' . e($m['kampus']) : '' ?></span>
                  <div class="small text-muted">
                    <?= $m['tanggal_selesai']
                        ? 'Masa magang berakhir ' . e(formatTanggalID($m['tanggal_selesai']))
                        : 'Tanggal selesai magang belum diatur' ?>
                    <?= $m['nama_pembimbing'] ? ' · Pembimbing: ' . e($m['nama_pembimbing']) : '' ?>
                  </div>
                  <?php if ($sudah): ?>
                    <div class="small text-success">
                      ✓ Ditandai <?= e(formatTanggalID($m['sertifikat_selesai_tgl'])) ?>
                      <?= $m['nama_penanda'] ? ' oleh ' . e($m['nama_penanda']) : '' ?>
                    </div>
                  <?php endif; ?>
                </div>
                <?php if ($sudah): ?>
                  <span class="badge text-bg-success">Sudah dibuat</span>
                <?php elseif ($sisa === null): ?>
                  <span class="badge text-bg-secondary">Belum ada tanggal selesai</span>
                <?php else: ?>
                  <span class="badge text-bg-<?= $sisa < 0 ? 'danger' : ($sisa <= 3 ? 'warning' : 'secondary') ?>">
                    <?= $sisa < 0 ? 'Sudah berakhir ' . abs($sisa) . ' hari lalu'
                         : ($sisa === 0 ? 'Berakhir hari ini' : 'Berakhir ' . $sisa . ' hari lagi') ?>
                  </span>
                <?php endif; ?>
              </div>

              <form method="POST" class="mt-2 m-0"
                    data-konfirmasi="<?= $sudah
                        ? 'Batalkan tanda sertifikat ' . e($m['nama']) . '? Dia akan kembali muncul sebagai sertifikat yang perlu disiapkan.'
                        : 'Tandai sertifikat ' . e($m['nama']) . ' sudah dibuat?' ?>"
                    data-konfirmasi-judul="<?= $sudah ? 'Batalkan tanda sertifikat' : 'Sertifikat sudah dibuat' ?>"
                    data-konfirmasi-ya="<?= $sudah ? 'Ya, batalkan' : 'Ya, sudah dibuat' ?>"
                    <?= $sudah ? 'data-konfirmasi-bahaya="1"' : '' ?>>
                <?= csrfField() ?>
                <input type="hidden" name="sertifikat_id" value="<?= (int) $m['id'] ?>">
                <input type="hidden" name="sertifikat_aksi" value="<?= $sudah ? 'batal' : 'tandai' ?>">
                <button type="submit" class="btn btn-<?= $sudah ? 'outline-danger' : 'success' ?> btn-sm">
                  <?= $sudah ? '↩️ Batalkan' : '✅ Tandai sudah dibuat' ?>
                </button>
              </form>
            </div>
          <?php endforeach; ?>
        </div>

        <?php if ($arsipTerhapus): ?>
          <p class="text-muted small mt-3 mb-1">
            🗄️ Riwayat sertifikat dari akun mahasiswa yang <b>sudah dihapus</b> (<?= count($arsipTerhapus) ?>) —
            hanya catatan, tidak bisa diubah, dan tetap ikut terunduh ke Excel.
          </p>
          <div class="list-group list-group-flush daftar-gulir" style="max-height:220px;">
            <?php foreach ($arsipTerhapus as $a): ?>
              <div class="list-group-item px-0">
                <div class="d-flex justify-content-between align-items-start gap-2 flex-wrap">
                  <div>
                    <b><?= e($a['nama']) ?></b>
                    <span class="text-muted small">· <?= e($a['identifier']) ?><?= $a['kampus'] ? ' · ' . e($a['kampus']) : '' ?></span>
                    <div class="small text-muted">
                      <?= $a['tanggal_selesai'] ? 'Masa magang berakhir ' . e(formatTanggalID($a['tanggal_selesai'])) : 'Tanggal selesai tidak tercatat' ?>
                      <?= $a['nama_pembimbing'] ? ' · Pembimbing: ' . e($a['nama_pembimbing']) : '' ?>
                    </div>
                    <div class="small text-success">
                      ✓ Ditandai <?= e(formatTanggalID($a['sertifikat_tgl'])) ?><?= $a['ditandai_oleh'] ? ' oleh ' . e($a['ditandai_oleh']) : '' ?>
                    </div>
                  </div>
                  <span class="badge text-bg-secondary">Akun sudah dihapus</span>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <?php if ($pg['totalHalaman'] > 1): ?>
          <div class="d-flex justify-content-between align-items-center mt-3">
            <?php if ($pg['halaman'] > 1): ?>
              <a href="<?= urlHalaman($pg['halaman'] - 1) ?>" class="btn btn-outline-secondary btn-sm">← Sebelumnya</a>
            <?php else: ?><span></span><?php endif; ?>
            <span class="text-muted small">Halaman <?= $pg['halaman'] ?> dari <?= $pg['totalHalaman'] ?></span>
            <?php if ($pg['halaman'] < $pg['totalHalaman']): ?>
              <a href="<?= urlHalaman($pg['halaman'] + 1) ?>" class="btn btn-outline-secondary btn-sm">Berikutnya →</a>
            <?php else: ?><span></span><?php endif; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
