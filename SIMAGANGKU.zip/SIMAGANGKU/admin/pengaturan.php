<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('admin');
$pdo = getDB();
$success = '';

// Pesan setelah pengalihan (Post/Redirect/Get) — hanya tampil sekali, tidak muncul lagi saat refresh.
if ($pesanSekali = ambilPesanSekali()) {
    if (($pesanSekali['tipe'] ?? 'success') === 'success') { $success = $pesanSekali['pesan']; }
    else { $error = $pesanSekali['pesan']; }
}

$error = '';
$successLibur = '';
$errorLibur = '';
$successCabang = '';
$errorCabang = '';

$pengaturan = ambilPengaturan();

// ---- Form "Nama Instansi" (tetap global, berlaku untuk semua cabang) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'umum') {
    verifikasiCsrf();
    $nama = trim($_POST['nama_instansi'] ?? '');

    if (!$nama) {
        $error = 'Nama instansi wajib diisi.';
    } else {
        $stmt = $pdo->prepare("UPDATE pengaturan SET nama_instansi=? WHERE id=?");
        $stmt->execute([$nama, $pengaturan['id']]);
        catatAktivitas('ubah_pengaturan', 'pengaturan', null, 'Nama instansi', 'Menjadi: ' . $nama);
        simpanPesanSekali('Nama instansi berhasil disimpan.');
        redirect('/admin/pengaturan.php');
        $pengaturan = ambilPengaturan();
    }
}

// ---- Form "Retensi Foto Absen" ----
$successRetensi = '';
$errorRetensi = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'retensi_foto') {
    verifikasiCsrf();
    $retensiInput = $_POST['retensi_foto_bulan'] ?? '';

    $retensiLogInput = $_POST['retensi_log_bulan'] ?? '';
    $pengingatInput = $_POST['pengingat_sertifikat_hari'] ?? '';

    if ($retensiInput === '' || !ctype_digit((string)$retensiInput) || (int)$retensiInput < 0 || (int)$retensiInput > 60) {
        $errorRetensi = 'Isi lama simpan foto dengan angka bulan yang valid (0–60). 0 berarti foto tidak pernah dihapus otomatis.';
    } elseif ($retensiLogInput === '' || !ctype_digit((string)$retensiLogInput) || (int)$retensiLogInput < 0 || (int)$retensiLogInput > 120) {
        $errorRetensi = 'Isi lama simpan riwayat aktivitas dengan angka bulan yang valid (0–120). 0 berarti disimpan selamanya.';
    } elseif ($pengingatInput === '' || !ctype_digit((string)$pengingatInput) || (int)$pengingatInput < 0 || (int)$pengingatInput > 180) {
        $errorRetensi = 'Isi pengingat sertifikat dengan angka hari yang valid (0–180). 0 berarti pengingat dimatikan.';
    } else {
        $stmt = $pdo->prepare("UPDATE pengaturan SET retensi_foto_bulan=?, retensi_log_bulan=?, pengingat_sertifikat_hari=? WHERE id=?");
        $stmt->execute([(int)$retensiInput, (int)$retensiLogInput, (int)$pengingatInput, $pengaturan['id']]);
        catatAktivitas('ubah_pengaturan', 'pengaturan', null, 'Retensi data & pengingat',
            'Foto absen: ' . (int)$retensiInput . ' bulan · Riwayat aktivitas: ' . (int)$retensiLogInput . ' bulan'
            . ' · Pengingat sertifikat: ' . (int)$pengingatInput . ' hari');
        unset($_SESSION['_terakhir_bersihkan_log']);
        // Terapkan default baru di pembersihan foto berikutnya, lalu redirect supaya
        // form menampilkan nilai terbaru (ambilPengaturan() di-cache per request).
        unset($_SESSION['_terakhir_bersihkan_foto']);
        redirect('/admin/pengaturan.php?retensi_tersimpan=1#retensi-foto');
    }
}

if (isset($_GET['retensi_tersimpan'])) {
    $successRetensi = 'Default retensi foto berhasil disimpan. Berlaku untuk semua mahasiswa yang retensinya diatur "ikuti default".';
}

// --- Kelola cabang (lokasi absen + jam kerja dalam 1 form) ---
/**
 * Ambil & validasi input form cabang (dipakai form Tambah maupun Edit).
 * Mengembalikan [data, pesanError]. Jam kerja ikut divalidasi di sini, jadi cabang
 * tidak pernah tersimpan dalam kondisi "jam kerja belum diatur".
 */
function inputCabangDariForm() {
    $data = [
        'nama_cabang' => trim($_POST['nama_cabang'] ?? ''),
        'alamat' => trim($_POST['alamat_cabang'] ?? ''),
        'lat' => trim($_POST['lat_cabang'] ?? ''),
        'lng' => trim($_POST['lng_cabang'] ?? ''),
        'radius_meter' => trim($_POST['radius_cabang'] ?? ''),
        'jam_masuk' => normalisasiJam($_POST['jam_masuk'] ?? ''),
        'batas_terlambat' => normalisasiJam($_POST['batas_terlambat'] ?? ''),
        'jam_pulang' => normalisasiJam($_POST['jam_pulang'] ?? ''),
    ];

    if ($data['nama_cabang'] === '' || $data['alamat'] === '') {
        return [$data, 'Nama cabang dan alamat wajib diisi.'];
    }
    if (!is_numeric($data['lat']) || (float) $data['lat'] < -90 || (float) $data['lat'] > 90) {
        return [$data, 'Latitude tidak valid (harus angka antara -90 sampai 90, mis. -5.1484089).'];
    }
    if (!is_numeric($data['lng']) || (float) $data['lng'] < -180 || (float) $data['lng'] > 180) {
        return [$data, 'Longitude tidak valid (harus angka antara -180 sampai 180, mis. 119.4374119).'];
    }
    if (!ctype_digit($data['radius_meter']) || (int) $data['radius_meter'] <= 0) {
        return [$data, 'Radius toleransi harus berupa angka meter lebih dari 0.'];
    }
    if ($pesan = validasiUrutanJamKerja($data['jam_masuk'], $data['batas_terlambat'], $data['jam_pulang'])) {
        return [$data, $pesan];
    }
    return [$data, null];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['form'] ?? '', ['tambah_cabang', 'edit_cabang'], true)) {
    verifikasiCsrf();
    $modeEdit = $_POST['form'] === 'edit_cabang';
    $idCabang = (int) ($_POST['id_cabang'] ?? 0);
    [$dataCabang, $errorCabang] = inputCabangDariForm();

    if (!$errorCabang && $modeEdit && !ambilCabang($idCabang)) {
        $errorCabang = 'Cabang tidak ditemukan.';
    }
    if (!$errorCabang) {
        $nilai = [$dataCabang['nama_cabang'], $dataCabang['alamat'], $dataCabang['lat'], $dataCabang['lng'],
                  (int) $dataCabang['radius_meter'], $dataCabang['jam_masuk'], $dataCabang['batas_terlambat'], $dataCabang['jam_pulang']];
        if ($modeEdit) {
            $nilai[] = $idCabang;
            $pdo->prepare("UPDATE cabang SET nama_cabang=?, alamat=?, lat=?, lng=?, radius_meter=?, jam_masuk=?, batas_terlambat=?, jam_pulang=? WHERE id=?")
                ->execute($nilai);
            catatAktivitas('ubah_data', 'cabang', $idCabang, $dataCabang['nama_cabang'],
                'Jam kerja ' . substr($dataCabang['jam_masuk'], 0, 5) . '–' . substr($dataCabang['jam_pulang'], 0, 5)
                . ', radius ' . (int) $dataCabang['radius_meter'] . ' m');
            redirect('/admin/pengaturan.php?cabang_tersimpan=1#cabang');
        }
        $pdo->prepare("INSERT INTO cabang (nama_cabang, alamat, lat, lng, radius_meter, jam_masuk, batas_terlambat, jam_pulang) VALUES (?,?,?,?,?,?,?,?)")
            ->execute($nilai);
        catatAktivitas('tambah_data', 'cabang', $pdo->lastInsertId(), $dataCabang['nama_cabang']);
        redirect('/admin/pengaturan.php?cabang_ditambahkan=1#cabang');
    }
}

if (isset($_GET['cabang_tersimpan'])) {
    $successCabang = 'Perubahan data cabang (lokasi & jam kerja) berhasil disimpan dan langsung berlaku untuk absen mahasiswa cabang ini.';
}
if (isset($_GET['cabang_ditambahkan'])) {
    $successCabang = 'Cabang baru berhasil ditambahkan dan sudah bisa dipilih saat mendaftarkan mahasiswa.';
}

// ---- Data cabang yang sedang diedit (kalau ada) ----
$editCabang = null;
if (isset($_GET['edit_cabang'])) {
    $editCabang = ambilCabang((int)$_GET['edit_cabang']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'hapus_cabang') {
    verifikasiCsrf();
    $idCabang = (int)($_POST['id_cabang'] ?? 0);
    $jumlahMhs = jumlahMahasiswaDiCabang($idCabang);
    $jumlahPembimbingCabang = jumlahPembimbingDiCabang($idCabang);
    if ($jumlahMhs > 0) {
        $errorCabang = "Cabang ini masih dipakai oleh $jumlahMhs mahasiswa. Pindahkan dulu mahasiswanya ke cabang lain lewat menu Mahasiswa sebelum menghapus cabang ini.";
    } elseif ($jumlahPembimbingCabang > 0) {
        $errorCabang = "Cabang ini masih dipakai oleh $jumlahPembimbingCabang akun pembimbing. Pindahkan dulu pembimbingnya ke cabang lain lewat menu Pembimbing → Edit sebelum menghapus cabang ini.";
    } else {
        $stmtNamaCabang = $pdo->prepare("SELECT nama_cabang FROM cabang WHERE id = ?");
        $stmtNamaCabang->execute([$idCabang]);
        $namaCabangHapus = $stmtNamaCabang->fetchColumn();
        $pdo->prepare("DELETE FROM cabang WHERE id = ?")->execute([$idCabang]);
        catatAktivitas('hapus_data', 'cabang', $idCabang, $namaCabangHapus ?: null);
        simpanPesanSekali('Cabang berhasil dihapus.');
        redirect('/admin/pengaturan.php');
    }
}

$daftarCabangSemua = daftarCabang();

// Nilai yang ditampilkan di form cabang: input terakhir kalau simpan gagal (supaya admin
// tidak mengetik ulang), data cabang kalau sedang edit, atau nilai awal untuk cabang baru.
$gagalSimpanCabang = $errorCabang && in_array($_POST['form'] ?? '', ['tambah_cabang', 'edit_cabang'], true);
if ($gagalSimpanCabang) {
    $formCabang = $dataCabang;
    foreach (['jam_masuk', 'batas_terlambat', 'jam_pulang'] as $k) {
        $formCabang[$k] = $_POST[$k] ?? '';
    }
} elseif ($editCabang) {
    $formCabang = $editCabang;
} else {
    $formCabang = ['nama_cabang' => '', 'alamat' => '', 'lat' => '', 'lng' => '', 'radius_meter' => '200',
                   'jam_masuk' => '06:00', 'batas_terlambat' => '08:00', 'jam_pulang' => '17:00'];
}

// --- Kelola hari libur nasional/khusus ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'tambah_libur') {
    verifikasiCsrf();
    $tglLibur = $_POST['tanggal_libur'] ?? '';
    $ketLibur = trim($_POST['keterangan_libur'] ?? '');

    if (!$tglLibur || !DateTime::createFromFormat('Y-m-d', $tglLibur) || !$ketLibur) {
        $errorLibur = 'Mohon isi tanggal dan keterangan hari libur dengan benar.';
    } else {
        $hariKeCek = (int) date('N', strtotime($tglLibur));
        if ($hariKeCek === 6 || $hariKeCek === 7) {
            $errorLibur = 'Tanggal itu sudah otomatis libur (Sabtu/Minggu), tidak perlu ditambahkan lagi.';
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO hari_libur (tanggal, keterangan) VALUES (?, ?)");
                $stmt->execute([$tglLibur, $ketLibur]);
                catatAktivitas('tambah_data', 'hari_libur', $pdo->lastInsertId(), $ketLibur, 'Tanggal: ' . $tglLibur);
                simpanPesanSekali('Hari libur berhasil ditambahkan.');
                redirect('/admin/pengaturan.php');
            } catch (PDOException $e) {
                $errorLibur = 'Tanggal itu sudah terdaftar sebagai hari libur.';
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'hapus_libur') {
    verifikasiCsrf();
    $idLibur = (int)($_POST['id_libur'] ?? 0);
    if ($idLibur) {
        $stmtLibur = $pdo->prepare("SELECT tanggal, keterangan FROM hari_libur WHERE id = ?");
        $stmtLibur->execute([$idLibur]);
        $liburHapus = $stmtLibur->fetch();
        $stmt = $pdo->prepare("DELETE FROM hari_libur WHERE id = ?");
        $stmt->execute([$idLibur]);
        if ($liburHapus) {
            catatAktivitas('hapus_data', 'hari_libur', $idLibur, $liburHapus['keterangan'], 'Tanggal: ' . $liburHapus['tanggal']);
        }
        simpanPesanSekali('Hari libur berhasil dihapus.');
        redirect('/admin/pengaturan.php');
    }
}

$daftarLibur = $pdo->query("SELECT * FROM hari_libur WHERE tanggal >= CURDATE() - INTERVAL 30 DAY ORDER BY tanggal ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Pengaturan — Admin</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_admin.php'; ?>
<div class="container pb-5">
    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Umum</p>
      <h2 class="h6 fw-bold mb-2">Nama Instansi</h2>
      <p class="text-muted small" style="margin-top:6px;">Nama ini berlaku global, ditampilkan ke semua mahasiswa di semua cabang.</p>

      <form method="POST" style="margin-top:14px;">
        <?= csrfField() ?>
        <input type="hidden" name="form" value="umum" class="form-control">
        <div class="mb-3"><label class="form-label">Nama instansi</label><input type="text" name="nama_instansi" value="<?= e($pengaturan['nama_instansi']) ?>" required class="form-control"></div>

        <?php if ($error): ?><p class="alert alert-danger py-2 small"><?= e($error) ?></p><?php endif; ?>
        <?php if ($success): ?><p class="alert alert-success py-2 small"><?= e($success) ?></p><?php endif; ?>

        <button type="submit" class="btn btn-primary" style="margin-top:6px;">Simpan</button>
      </form>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Keamanan</p>
      <h2 class="h6 fw-bold mb-2">Kelola Akun Admin & Pembimbing</h2>
      <p class="text-muted small" style="margin-top:6px;"><b>Admin</b>: akses penuh. <b>Pembimbing</b>: hanya mahasiswa bimbingannya, tanpa akses pengaturan.</p>
      <div style="display:flex;gap:10px;margin-top:10px;flex-wrap:wrap;">
        <a href="kelola_pembimbing.php" class="btn btn-outline-primary">👥 Kelola Pembimbing</a>
        <a href="divisi.php" class="btn btn-outline-secondary">🏢 Kelola Divisi</a>
        <a href="log_aktivitas.php" class="btn btn-outline-secondary">🧾 Riwayat Aktivitas</a>
        <?php if (isSuperAdmin()): // halaman Kelola Admin khusus super admin ?>
          <a href="kelola_admin.php" class="btn btn-outline-secondary">👤 Kelola Admin</a>
        <?php endif; ?>
        <a href="profil.php" class="btn btn-secondary">🔑 Ganti Password Saya</a>
      </div>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1" id="retensi-foto">Privasi & Storage</p>
      <h2 class="h6 fw-bold mb-2">Default Retensi Foto Absen</h2>
      <p class="text-muted small" style="margin-top:6px;">Foto absen dihapus otomatis sekian bulan setelah magang selesai. Data absensinya tetap tersimpan.</p>
      <p class="text-muted small">Nilai ini dipakai untuk mahasiswa yang diatur "ikuti default" (bisa diubah per mahasiswa di menu <a href="mahasiswa.php">Mahasiswa</a>).</p>
      <?php
        $stmtRingkasRetensi = $pdo->query("SELECT SUM(retensi_foto_bulan IS NULL) ikut_default, SUM(retensi_foto_bulan IS NOT NULL) khusus FROM users WHERE role='mahasiswa'");
        $ringkasRetensi = $stmtRingkasRetensi->fetch();
      ?>
      <p class="small mb-0"><span class="badge text-bg-secondary"><?= (int) $ringkasRetensi['ikut_default'] ?> mahasiswa ikut default</span> <span class="badge text-bg-info"><?= (int) $ringkasRetensi['khusus'] ?> mahasiswa diatur khusus</span></p>

      <form method="POST" style="margin-top:14px;">
        <?= csrfField() ?>
        <input type="hidden" name="form" value="retensi_foto" class="form-control">
        <div class="mb-3">
          <label class="form-label">Default: simpan foto selama (bulan) setelah magang selesai</label>
          <input type="number" name="retensi_foto_bulan" min="0" max="60" value="<?= e($pengaturan['retensi_foto_bulan']) ?>" required class="form-control">
        </div>
        <p class="text-muted small" style="margin-top:-4px;font-size:12px;">Isi <b>0</b> agar foto tidak pernah dihapus otomatis.</p>

        <div class="mb-3">
          <label class="form-label">Pengingat sertifikat (hari sebelum magang berakhir)</label>
          <input type="number" name="pengingat_sertifikat_hari" min="0" max="180" value="<?= e($pengaturan['pengingat_sertifikat_hari']) ?>" required class="form-control">
        </div>
        <p class="text-muted small" style="margin-top:-4px;font-size:12px;">
          Dashboard admin &amp; pembimbing menampilkan daftar mahasiswa yang masa magangnya berakhir
          dalam sekian hari ke depan, supaya sertifikatnya disiapkan sebelum mereka selesai.
          Isi <b>0</b> untuk mematikan pengingat ini.
        </p>

        <div class="mb-3">
          <label class="form-label">Simpan riwayat aktivitas selama (bulan)</label>
          <input type="number" name="retensi_log_bulan" min="0" max="120" value="<?= e($pengaturan['retensi_log_bulan']) ?>" required class="form-control">
        </div>
        <p class="text-muted small" style="margin-top:-4px;font-size:12px;">Lama simpan <a href="log_aktivitas.php">Riwayat Aktivitas</a>. Isi <b>0</b> untuk menyimpan selamanya.</p>

        <?php if ($errorRetensi): ?><p class="alert alert-danger py-2 small"><?= e($errorRetensi) ?></p><?php endif; ?>
        <?php if ($successRetensi): ?><p class="alert alert-success py-2 small"><?= e($successRetensi) ?></p><?php endif; ?>

        <button type="submit" class="btn btn-primary" style="margin-top:6px;">Simpan Default Retensi</button>
      </form>
      </div>
    </div>

    <div class="card mb-3" id="cabang">
      <div class="card-body">
      <?php $jam5 = fn($j) => $j ? substr($j, 0, 5) : ''; ?>
      <p class="text-primary fw-semibold small mb-1">Cabang, Lokasi & Jam Kerja</p>
      <h2 class="h6 fw-bold mb-2"><?= $editCabang ? 'Edit Cabang: ' . e($editCabang['nama_cabang']) : 'Tambah Cabang Baru' ?></h2>
      <p class="text-muted small" style="margin-top:6px;">Setiap cabang punya koordinat, radius, dan jam kerja sendiri, dipakai untuk validasi absen mahasiswanya.</p>

      <?php if ($editCabang && !cabangSudahDiatur($editCabang) && !$gagalSimpanCabang): ?>
        <div class="alert alert-warning small">⚠️ Jam kerja cabang ini <b>belum diatur</b>. Lengkapi jam kerja di bawah lalu simpan supaya mahasiswa bisa didaftarkan dan absen di cabang ini.</div>
      <?php endif; ?>

      <form method="POST" action="pengaturan.php<?= $editCabang ? '?edit_cabang=' . (int) $editCabang['id'] : '' ?>#cabang" style="margin-top:14px;">
        <?= csrfField() ?>
        <input type="hidden" name="form" value="<?= $editCabang ? 'edit_cabang' : 'tambah_cabang' ?>">
        <?php if ($editCabang): ?><input type="hidden" name="id_cabang" value="<?= (int) $editCabang['id'] ?>"><?php endif; ?>

        <p class="fw-semibold small text-uppercase text-muted mb-2">1. Identitas cabang</p>
        <div class="mb-3"><label class="form-label">Nama cabang</label><input type="text" name="nama_cabang" value="<?= e($formCabang['nama_cabang']) ?>" placeholder="mis. Cabang Parepare" required class="form-control"></div>
        <div class="mb-3"><label class="form-label">Alamat</label><textarea name="alamat_cabang" rows="2" required class="form-control"><?= e($formCabang['alamat']) ?></textarea></div>

        <p class="fw-semibold small text-uppercase text-muted mb-2 mt-4">2. Lokasi absen</p>
        <div class="row g-2">
          <div class="col-12 col-md-4"><label class="form-label">Latitude</label><input type="text" name="lat_cabang" id="latCabang" value="<?= e($formCabang['lat']) ?>" placeholder="-5.1484089" required class="form-control" inputmode="decimal"></div>
          <div class="col-12 col-md-4"><label class="form-label">Longitude</label><input type="text" name="lng_cabang" id="lngCabang" value="<?= e($formCabang['lng']) ?>" placeholder="119.4374119" required class="form-control" inputmode="decimal"></div>
          <div class="col-12 col-md-4"><label class="form-label">Radius toleransi (meter)</label><input type="number" name="radius_cabang" min="1" value="<?= e($formCabang['radius_meter']) ?>" required class="form-control"></div>
        </div>
        <p class="text-muted small mt-1">Ambil koordinat dari Google Maps: klik kanan lokasi → klik angka koordinatnya.</p>

        <p class="fw-semibold small text-uppercase text-muted mb-2 mt-4">3. Jam kerja</p>
        <div class="row g-2">
          <div class="col-12 col-md-4"><label class="form-label">Mulai absen masuk</label><input type="time" name="jam_masuk" value="<?= e($jam5($formCabang['jam_masuk'])) ?>" required class="form-control"></div>
          <div class="col-12 col-md-4"><label class="form-label">Batas tidak terlambat</label><input type="time" name="batas_terlambat" value="<?= e($jam5($formCabang['batas_terlambat'])) ?>" required class="form-control"></div>
          <div class="col-12 col-md-4"><label class="form-label">Mulai absen pulang</label><input type="time" name="jam_pulang" value="<?= e($jam5($formCabang['jam_pulang'])) ?>" required class="form-control"></div>
        </div>
        <p class="text-muted small mt-1">Contoh: 06:00 / 08:00 / 17:00 — absen masuk dibuka jam 6, tepat waktu sampai jam 8, absen pulang mulai jam 17.</p>

        <?php if ($errorCabang): ?><p class="alert alert-danger py-2 small"><?= e($errorCabang) ?></p><?php endif; ?>
        <?php if ($successCabang): ?><p class="alert alert-success py-2 small"><?= e($successCabang) ?></p><?php endif; ?>

        <div class="d-flex gap-2 mt-2">
          <button type="submit" class="btn btn-primary"><?= $editCabang ? 'Simpan Perubahan' : '+ Tambah Cabang' ?></button>
          <?php if ($editCabang): ?><a href="pengaturan.php#cabang" class="btn btn-secondary">Batal</a><?php endif; ?>
        </div>
      </form>

      <p class="fw-semibold small mt-4 mb-2">Daftar cabang (<?= count($daftarCabangSemua) ?>)</p>
      <div class="daftar-gulir" style="display:flex;flex-direction:column;gap:10px;max-height:480px;">
        <?php if (!$daftarCabangSemua): ?>
          <p class="text-muted small">Belum ada cabang yang ditambahkan.</p>
        <?php endif; ?>
        <?php foreach ($daftarCabangSemua as $c):
          $jumlahMhsCabang = jumlahMahasiswaDiCabang($c['id']);
          $sudahDiatur = cabangSudahDiatur($c);
          $sedangDiedit = $editCabang && (int) $editCabang['id'] === (int) $c['id'];
        ?>
          <div class="list-group-item px-0 <?= $sedangDiedit ? 'border-start border-primary border-3 ps-2' : '' ?>">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <b><?= e($c['nama_cabang']) ?></b>
              <span>
                <span class="badge text-bg-secondary"><?= $jumlahMhsCabang ?> mahasiswa</span>
                <?php if (($jumlahPembimbingCabangIni = jumlahPembimbingDiCabang($c['id'])) > 0): ?>
                  <span class="badge text-bg-light text-dark"><?= $jumlahPembimbingCabangIni ?> pembimbing</span>
                <?php endif; ?>
              </span>
            </div>
            <div class="small text-muted"><?= e($c['alamat']) ?></div>
            <div class="small text-muted">Koordinat: <?= e($c['lat']) ?>, <?= e($c['lng']) ?> · Radius: <?= e($c['radius_meter']) ?> m</div>
            <div class="small text-muted">
              <?php if ($sudahDiatur): ?>
                Jam kerja: masuk <?= substr($c['jam_masuk'],0,5) ?>, terlambat lewat <?= substr($c['batas_terlambat'],0,5) ?>, pulang <?= substr($c['jam_pulang'],0,5) ?>
              <?php else: ?>
                <span class="badge text-bg-danger">Jam kerja belum diatur</span>
              <?php endif; ?>
            </div>
            <div class="d-flex flex-wrap gap-2 mt-2">
              <a href="pengaturan.php?edit_cabang=<?= $c['id'] ?>#cabang" class="btn <?= $sudahDiatur ? 'btn-outline-primary' : 'btn-primary' ?> btn-sm">✏️ <?= $sudahDiatur ? 'Edit Cabang' : 'Edit & Atur Jam Kerja' ?></a>
              <form method="POST" action="pengaturan.php#cabang" data-konfirmasi="Hapus cabang <?= e($c['nama_cabang']) ?>? Data cabang, koordinat, dan jam kerjanya akan hilang." data-konfirmasi-judul="Hapus cabang" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1" style="margin:0;">
                <?= csrfField() ?>
                <input type="hidden" name="form" value="hapus_cabang" class="form-control">
                <input type="hidden" name="id_cabang" value="<?= $c['id'] ?>" class="form-control">
                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      </div>
    </div>

    <script>
    // Link "Cek titik ini di Google Maps" selalu mengikuti koordinat yang sedang diketik.
    (function () {
      var lat = document.getElementById('latCabang'), lng = document.getElementById('lngCabang'), link = document.getElementById('cekPeta');
      if (!lat || !lng || !link) return;
      function perbarui() {
        var ada = lat.value.trim() !== '' && lng.value.trim() !== '';
        link.href = ada ? 'https://www.google.com/maps?q=' + encodeURIComponent(lat.value.trim() + ',' + lng.value.trim()) : '#';
        link.style.display = ada ? '' : 'none';
      }
      lat.addEventListener('input', perbarui); lng.addEventListener('input', perbarui); perbarui();
    })();
    </script>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Aturan hari kerja</p>
      <p class="text-muted small">
        🌍 <b>WFO/WFA sekarang dipilih mahasiswa sendiri saat absen</b> — bukan lagi otomatis berdasarkan hari tertentu. Setiap kali absen, mahasiswa memilih WFO (harus di lokasi kantor cabangnya) atau WFA/Work From Anywhere (bebas absen dari mana saja).<br><br>
        🛌 <b>Sabtu & Minggu otomatis hari libur</b> — sistem menolak semua percobaan absen di kedua hari ini secara tetap, tidak bisa diubah, berlaku untuk semua cabang.<br><br>
        📅 <b>Hari libur nasional/khusus</b> — tambahkan tanggal spesifik (mis. libur nasional, cuti bersama) di bawah ini supaya mahasiswa otomatis tidak bisa absen pada tanggal tersebut (berlaku semua cabang).
      </p>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Hari Libur Nasional / Khusus</p>
      <h2 class="h6 fw-bold mb-2">Tambah Tanggal Libur</h2>
      <p class="text-muted small" style="margin-top:6px;">Sabtu & Minggu sudah otomatis libur. Tambahkan di sini libur nasional/cuti bersama.</p>

      <form method="POST" style="margin-top:14px;display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;">
        <?= csrfField() ?>
        <input type="hidden" name="form" value="tambah_libur" class="form-control">
        <div class="mb-3" style="flex:1;min-width:150px;margin-bottom:0;">
          <label class="form-label">Tanggal</label>
          <input type="date" name="tanggal_libur" required class="form-control">
        </div>
        <div class="mb-3" style="flex:2;min-width:180px;margin-bottom:0;">
          <label class="form-label">Keterangan</label>
          <input type="text" name="keterangan_libur" placeholder="mis. Hari Kemerdekaan RI" required class="form-control">
        </div>
        <button type="submit" class="btn btn-primary" style="width:auto;padding:11px 16px;">+ Tambah</button>
      </form>

      <?php if ($errorLibur): ?><p class="alert alert-danger py-2 small" style="margin-top:10px;"><?= e($errorLibur) ?></p><?php endif; ?>
      <?php if ($successLibur): ?><p class="alert alert-success py-2 small" style="margin-top:10px;"><?= e($successLibur) ?></p><?php endif; ?>

      <div class="daftar-gulir" style="margin-top:16px;display:flex;flex-direction:column;gap:8px;max-height:360px;">
        <?php if (!$daftarLibur): ?>
          <p class="text-muted small">Belum ada hari libur khusus yang ditambahkan.</p>
        <?php endif; ?>
        <?php foreach ($daftarLibur as $lb): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 12px;border:1px solid rgba(255,255,255,0.08);border-radius:10px;">
            <div>
              <b style="font-size:13px;"><?= e(formatTanggalID($lb['tanggal'])) ?></b>
              <div class="text-muted small" style="font-size:12px;"><?= e($lb['keterangan']) ?></div>
            </div>
            <form method="POST" data-konfirmasi="Hapus hari libur ini? Mahasiswa jadi bisa absen di tanggal tersebut." data-konfirmasi-judul="Hapus hari libur" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1">
              <?= csrfField() ?>
              <input type="hidden" name="form" value="hapus_libur" class="form-control">
              <input type="hidden" name="id_libur" value="<?= $lb['id'] ?>" class="form-control">
              <button type="submit" class="btn btn-secondary" style="width:auto;padding:6px 12px;font-size:12px;">Hapus</button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
      </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
