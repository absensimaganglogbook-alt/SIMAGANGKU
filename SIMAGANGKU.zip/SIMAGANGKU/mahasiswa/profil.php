<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('mahasiswa');
$user = currentUser();
$pdo = getDB();
$errorFoto = ''; $successFoto = '';
$errorPass = ''; $successPass = '';

$stmt = $pdo->prepare("SELECT u.*, p.nama AS nama_pembimbing, p.no_hp AS hp_pembimbing, d.nama AS divisi_pembimbing, cp.nama_cabang AS cabang_pembimbing
                       FROM users u
                       LEFT JOIN users p ON p.id = u.pembimbing_id AND p.role = 'pembimbing'
                       LEFT JOIN divisi d ON d.id = p.divisi_id
                       LEFT JOIN cabang cp ON cp.id = p.cabang_id
                       WHERE u.id=?");
$stmt->execute([$user['id']]);
$data = $stmt->fetch();

// ---- Upload / ganti foto profil ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan_foto'])) {
    verifikasiCsrf();
    if (empty($_FILES['foto_profil']['name'])) {
        $errorFoto = 'Pilih file foto terlebih dahulu.';
    } else {
        $hasil = simpanFileUpload($_FILES['foto_profil'], 'profil', 'profil_' . $user['id'], ['jpg', 'jpeg', 'png']);
        if (isset($hasil['error'])) {
            $errorFoto = $hasil['error'];
        } else {
            // Hapus foto lama kalau ada, supaya file lama tidak menumpuk
            if (!empty($data['foto_profil'])) {
                $fileLama = __DIR__ . '/../uploads/' . $data['foto_profil'];
                if (is_file($fileLama)) @unlink($fileLama);
            }
            $stmt = $pdo->prepare("UPDATE users SET foto_profil=? WHERE id=?");
            $stmt->execute([$hasil['path'], $user['id']]);
            // Alihkan halaman (Post/Redirect/Get) supaya menekan Refresh tidak
            // mengunggah ulang foto yang sama dan menumpuk file di server.
            redirect('/mahasiswa/profil.php?foto=tersimpan');
        }
    }
}

// Pesan hasil unggah/hapus foto (dibaca dari URL setelah pengalihan).
if (($_GET['foto'] ?? '') === 'tersimpan') $successFoto = 'Foto profil berhasil diperbarui.';
if (($_GET['foto'] ?? '') === 'dihapus')   $successFoto = 'Foto profil dihapus.';

// ---- Hapus foto profil ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus_foto'])) {
    verifikasiCsrf();
    if (!empty($data['foto_profil'])) {
        $fileLama = __DIR__ . '/../uploads/' . $data['foto_profil'];
        if (is_file($fileLama)) @unlink($fileLama);
        $stmt = $pdo->prepare("UPDATE users SET foto_profil=NULL WHERE id=?");
        $stmt->execute([$user['id']]);
        redirect('/mahasiswa/profil.php?foto=dihapus');
    }
}

// ---- Ganti password ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ganti_password'])) {
    verifikasiCsrf();
    if (empty($data['harus_ganti_password'])) {
        $errorPass = 'Kamu sudah pernah mengganti password sendiri. Untuk ganti lagi, minta admin mereset password akunmu.';
    } else {
        $lamaPass = $_POST['password_lama'] ?? '';
        $baruPass = $_POST['password_baru'] ?? '';
        $konfirmasi = $_POST['password_konfirmasi'] ?? '';

        if (!password_verify($lamaPass, $data['password'])) {
            $errorPass = 'Kata sandi lama salah.';
        } elseif (($pesanKekuatan = validasiKekuatanPassword($baruPass)) !== null) {
            $errorPass = $pesanKekuatan;
        } elseif ($baruPass !== $konfirmasi) {
            $errorPass = 'Konfirmasi kata sandi baru tidak cocok.';
        } else {
            $hash = password_hash($baruPass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password=?, harus_ganti_password=0 WHERE id=?");
            $stmt->execute([$hash, $user['id']]);
            $data['harus_ganti_password'] = 0;
            $_SESSION['harus_ganti_password'] = 0;
            // Ganti sesi dengan id baru, lalu langsung ke halaman utama mahasiswa (Absen);
            // pemberitahuan berhasilnya ditampilkan di sana.
            session_regenerate_id(true);
            redirect(berandaRole() . '?sandi_diganti=1');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Profil — Absensi Magang</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_mahasiswa.php'; ?>
<div class="container pb-5">
    <div class="card mb-3 text-center">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1 text-start">Foto profil</p>
      <img src="<?= e(urlAvatar($data['foto_profil'], $data['nama'], 120)) ?>"
           onerror="this.onerror=null; this.src='<?= e(urlAvatar(null, $data['nama'], 120)) ?>';"
           class="rounded-circle border my-3" style="width:110px;height:110px;object-fit:cover;">

      <form method="POST" enctype="multipart/form-data" class="d-flex flex-column gap-2">
        <?= csrfField() ?>
        <div class="mb-3" style="text-align:left;">
          <label class="form-label">Ganti foto (JPG/PNG, maks 3MB)</label>
          <input type="file" name="foto_profil" accept=".jpg,.jpeg,.png" class="form-control">
        </div>
        <button type="submit" name="simpan_foto" value="1" class="btn btn-primary">Simpan Foto</button>
      </form>
      <?php if ($data['foto_profil']): ?>
        <form method="POST" data-konfirmasi="Hapus foto profil kamu?" data-konfirmasi-judul="Hapus foto profil" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1" style="margin-top:8px;">
          <?= csrfField() ?>
          <button type="submit" name="hapus_foto" value="1" class="btn btn-danger">Hapus Foto</button>
        </form>
      <?php endif; ?>

      <?php if ($errorFoto): ?><p class="alert alert-danger py-2 small text-start mt-2"><?= e($errorFoto) ?></p><?php endif; ?>
      <?php if ($successFoto): ?><p class="alert alert-success py-2 small text-start mt-2"><?= e($successFoto) ?></p><?php endif; ?>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-2">Data diri</p>
      <div class="d-flex justify-content-between small border-bottom py-2"><span class="text-muted">Nama</span><span class="fw-medium"><?= e($data['nama']) ?></span></div>
      <div class="d-flex justify-content-between small border-bottom py-2"><span class="text-muted">Username</span><span class="fw-medium"><?= e($data['identifier']) ?></span></div>
      <div class="d-flex justify-content-between small border-bottom py-2"><span class="text-muted">Kampus</span><span class="fw-medium"><?= e($data['kampus'] ?: '-') ?></span></div>
      <div class="d-flex justify-content-between small border-bottom py-2"><span class="text-muted">Pembimbing</span><span class="fw-medium text-end"><?php
        if (!$data['nama_pembimbing']) {
            echo 'Belum ditetapkan';
        } else {
            echo e($data['nama_pembimbing']);
            $detailPembimbing = array_filter([$data['divisi_pembimbing'], $data['cabang_pembimbing'], $data['hp_pembimbing']]);
            if ($detailPembimbing) {
                echo '<br><span class="text-muted fw-normal">' . e(implode(' · ', $detailPembimbing)) . '</span>';
            }
        }
      ?></span></div>
      <div class="d-flex justify-content-between small py-2"><span class="text-muted">Periode magang</span><span class="fw-medium"><?= $data['tanggal_mulai'] ? formatTanggalID($data['tanggal_mulai']).' – '.formatTanggalID($data['tanggal_selesai']) : '-' ?></span></div>
      <?php if ($data['tanggal_selesai']): ?>
        <div class="d-flex justify-content-between small border-top py-2">
          <span class="text-muted">Sertifikat magang</span>
          <span class="fw-medium">
            <?php if ($data['sertifikat_selesai_tgl']): ?>
              <span class="badge text-bg-success">✓ Sudah dibuat</span>
              <span class="text-muted fw-normal d-block"><?= e(formatTanggalID($data['sertifikat_selesai_tgl'])) ?></span>
            <?php else: ?>
              <span class="badge text-bg-secondary">Belum dibuat</span>
              <span class="text-muted fw-normal d-block">Disiapkan pembimbing/admin menjelang magangmu selesai</span>
            <?php endif; ?>
          </span>
        </div>
      <?php endif; ?>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Keamanan</p>
      <h2 class="h6 fw-bold mb-2">Ganti Kata Sandi</h2>
      <?php if (!empty($data['harus_ganti_password'])): ?>
        <?php if (isset($_GET['wajib_ganti'])): ?>
          <div class="alert alert-warning d-flex align-items-start gap-2 mt-2">
            <span class="ico">🔐</span>
            <div><b>Kamu wajib ganti kata sandi dulu</b><span>Kamu masih pakai kata sandi awal/hasil reset admin. Ganti dulu sebelum bisa membuka menu lain.</span></div>
          </div>
        <?php endif; ?>
        <form method="POST" style="margin-top:12px;">
          <?= csrfField() ?>
          <div class="mb-3"><label class="form-label">Kata sandi lama</label><input type="password" name="password_lama" required class="form-control"></div>
          <div class="mb-3">
            <label class="form-label">Kata sandi baru</label>
            <input type="password" name="password_baru" id="passwordBaru" required class="form-control">
            <div id="kekuatanBar" class="mt-2" style="height:4px;border-radius:2px;background:#e9ecef;overflow:hidden;">
              <div id="kekuatanFill" style="height:100%;width:0%;background:#dc3545;transition:width .2s,background .2s;"></div>
            </div>
            <p class="text-muted small" id="kekuatanLabel" style="margin-top:4px;font-size:12px;"><?= e(syaratPasswordTeks()) ?></p>
          </div>
          <div class="mb-3"><label class="form-label">Konfirmasi kata sandi baru</label><input type="password" name="password_konfirmasi" required class="form-control"></div>
          <?php if ($errorPass): ?><p class="alert alert-danger py-2 small"><?= e($errorPass) ?></p><?php endif; ?>
          <?php if ($successPass): ?><p class="alert alert-success py-2 small"><?= e($successPass) ?></p><?php endif; ?>
          <button type="submit" name="ganti_password" value="1" class="btn btn-primary">Simpan</button>
        </form>
        <p class="text-muted small" style="margin-top:10px;font-size:12px;">⚠️ Kata sandi hanya bisa diganti sendiri <b>satu kali</b>. Setelahnya, minta admin untuk mereset.</p>

        <script>
        (function () {
          var input = document.getElementById('passwordBaru');
          var fill = document.getElementById('kekuatanFill');
          var label = document.getElementById('kekuatanLabel');
          var SYARAT_PASSWORD = <?= jsonUntukScript(syaratPasswordTeks()) ?>;
          if (!input) return;

          input.addEventListener('input', function () {
            var v = input.value;
            // Syarat wajib (sama dengan validasi di server): huruf besar, huruf kecil,
            // angka, simbol, dan minimal 8 karakter.
            var kurang = [];
            if (v.length < 8) kurang.push('minimal 8 karakter');
            if (!/[A-Z]/.test(v)) kurang.push('huruf besar');
            if (!/[a-z]/.test(v)) kurang.push('huruf kecil');
            if (!/[0-9]/.test(v)) kurang.push('angka');
            if (!/[^A-Za-z0-9]/.test(v)) kurang.push('simbol');
            var skor = 5 - kurang.length;
            if (!kurang.length && v.length >= 12) skor = 6;

            var persen = Math.min(100, (skor / 6) * 100);
            var warna = '#F0576B', teks = 'Lemah';
            if (v.length === 0) {
              persen = 0; teks = '';
            } else if (kurang.length) {
              warna = '#F0576B'; teks = 'Belum memenuhi syarat — kurang: ' + kurang.join(', ');
            } else if (v.length < 12) {
              warna = '#f0b863'; teks = 'Sudah memenuhi syarat — lebih panjang lebih aman';
            } else {
              warna = '#7fa6a0'; teks = 'Kuat';
            }
            fill.style.width = persen + '%';
            fill.style.background = warna;
            label.textContent = teks || SYARAT_PASSWORD;
          });
        })();
        </script>
      <?php else: ?>
        <p class="text-muted small" style="margin-top:12px;">🔒 Menu ini terkunci karena kata sandi sudah pernah diganti. Minta admin untuk mereset.</p>
        <?php if ($successPass): ?><p class="alert alert-success py-2 small mt-2"><?= e($successPass) ?></p><?php endif; ?>
      <?php endif; ?>
      </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
