<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('mahasiswa');
$user = currentUser();
$pdo = getDB();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajukan'])) {
    verifikasiCsrf();
    $jenis = $_POST['jenis'] ?? '';
    $tglMulai = $_POST['tanggal_mulai'] ?? '';
    $tglSelesai = $_POST['tanggal_selesai'] ?? '';
    $keterangan = trim($_POST['keterangan'] ?? '');

    if (!in_array($jenis, ['izin','sakit']) || !$tglMulai || !$tglSelesai || !$keterangan) {
        $error = 'Mohon lengkapi semua kolom.';
    } elseif ($tglSelesai < $tglMulai) {
        $error = 'Tanggal selesai tidak boleh sebelum tanggal mulai.';
    } else {
        $pathFile = null;
        if (!empty($_FILES['lampiran']['name'])) {
            $hasil = simpanFileUpload($_FILES['lampiran'], 'izin', $jenis . '_' . $user['id']);
            if (isset($hasil['error'])) {
                $error = $hasil['error'];
            } else {
                $pathFile = $hasil['path'];
            }
        }

        if (!$error) {
            // Izin/sakit 1 hari untuk hari ini disetujui otomatis (kebijakan instansi).
            // Selebihnya tetap menunggu persetujuan admin/pembimbing.
            $cekOtomatis = cekIzinBolehOtomatis($user['id'], $tglMulai, $tglSelesai);
            $statusBaru = $cekOtomatis['otomatis'] ? 'approved' : 'pending';

            $stmt = $pdo->prepare("INSERT INTO izin (user_id, jenis, tanggal_mulai, tanggal_selesai, keterangan, file_lampiran, status, disetujui_otomatis)
                                   VALUES (?,?,?,?,?,?,?,?)");
            $stmt->execute([$user['id'], $jenis, $tglMulai, $tglSelesai, $keterangan, $pathFile,
                            $statusBaru, $cekOtomatis['otomatis'] ? 1 : 0]);

            if ($cekOtomatis['otomatis']) {
                catatAktivitas('proses_izin', 'izin', $pdo->lastInsertId(), $user['nama'],
                    'Disetujui otomatis (1 hari, ' . formatTanggalID($tglMulai) . ')');
            }

            // Setelah tersimpan, ALIHKAN halaman (pola Post/Redirect/Get). Tanpa ini,
            // menekan Refresh akan mengirim ulang formulir yang sama, sehingga pengajuan
            // bertambah sendiri setiap kali halaman dimuat ulang.
            redirect('/mahasiswa/izin.php?diajukan=' . ($cekOtomatis['otomatis'] ? 'otomatis' : 'menunggu')
                   . '&jenis=' . urlencode($jenis));
        }
    }
}

if (($_GET['dihapus'] ?? '') === '1') {
    $success = 'Pengajuan berhasil dihapus.';
} elseif (($_GET['dihapus'] ?? '') === '0') {
    $error = 'Pengajuan tidak bisa dihapus. Hanya pengajuan yang masih menunggu, atau izin otomatis yang tanggalnya belum lewat, yang bisa dihapus.';
}

// Hapus pengajuan yang masih pending (milik sendiri)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {
    verifikasiCsrf();
    // Yang boleh dihapus mahasiswa: pengajuan yang masih menunggu, ATAU izin/sakit yang
    // disetujui OTOMATIS dan tanggalnya belum lewat — supaya kalau salah memilih tanggal,
    // mahasiswa bisa menghapus lalu mengajukan ulang tanpa merepotkan pembimbing.
    $syaratBolehHapus = "(status='pending' OR (status='approved' AND disetujui_otomatis=1 AND tanggal_selesai >= CURDATE()))";
    $stmt = $pdo->prepare("DELETE FROM izin WHERE id=? AND user_id=? AND $syaratBolehHapus");
    // Ambil dulu nama lampirannya supaya filenya ikut terhapus dari server.
    $idHapusIzin = (int)$_POST['hapus'];
    $stmtLampiran = $pdo->prepare("SELECT file_lampiran, disetujui_otomatis, tanggal_mulai FROM izin WHERE id=? AND user_id=? AND $syaratBolehHapus");
    $stmtLampiran->execute([$idHapusIzin, $user['id']]);
    $izinHapus = $stmtLampiran->fetch();
    $lampiranHapus = $izinHapus['file_lampiran'] ?? null;

    $stmt->execute([$idHapusIzin, $user['id']]);
    if ($stmt->rowCount() > 0 && $lampiranHapus) {
        hapusSatuBerkas($lampiranHapus);
    }
    if ($stmt->rowCount() > 0 && !empty($izinHapus['disetujui_otomatis'])) {
        catatAktivitas('proses_izin', 'izin', $idHapusIzin, $user['nama'],
            'Izin otomatis ' . formatTanggalID($izinHapus['tanggal_mulai']) . ' dihapus sendiri oleh mahasiswa');
    }
    redirect('/mahasiswa/izin.php?dihapus=' . ($stmt->rowCount() > 0 ? '1' : '0'));
}

// Bawaannya hanya bulan berjalan. Pengajuan yang MASIH MENUNGGU selalu ikut tampil,
// walau tanggalnya di bulan lain, supaya tidak ada yang terlewat dipantau.
$bulan = bulanDipilih();
[$awalBulan, $akhirBulan] = rentangBulan($bulan);

$stmtAwal = $pdo->prepare("SELECT DATE_FORMAT(MIN(tanggal_mulai), '%Y-%m') FROM izin WHERE user_id=?");
$stmtAwal->execute([$user['id']]);
$daftarTahun = daftarTahunPilihan(substr((string) $stmtAwal->fetchColumn(), 0, 4), substr($bulan, 0, 4));

$stmt = $pdo->prepare("SELECT * FROM izin
                       WHERE user_id=? AND (status='pending' OR (tanggal_mulai <= ? AND tanggal_selesai >= ?))
                       ORDER BY (status='pending') DESC, tanggal_mulai DESC");
$stmt->execute([$user['id'], $akhirBulan, $awalBulan]);
$daftarIzin = $stmt->fetchAll();

// Pesan hasil pengajuan (dibaca dari URL setelah pengalihan di atas).
if (($_GET['diajukan'] ?? '') === 'otomatis') {
    $jenisPesan = ($_GET['jenis'] ?? '') === 'sakit' ? 'sakit' : 'izin';
    $success = 'Pengajuan ' . $jenisPesan . ' untuk hari ini langsung disetujui. '
             . 'Kamu tidak perlu menunggu persetujuan pembimbing.';
} elseif (($_GET['diajukan'] ?? '') === 'menunggu') {
    $success = 'Pengajuan berhasil dikirim dan menunggu persetujuan admin/pembimbing. '
             . 'Pengajuan lebih dari 1 hari, untuk tanggal yang sudah lewat, atau yang bersambung '
             . 'dengan hari izin lain memang perlu persetujuan.';
}

$statusLabel = ['pending' => 'Menunggu', 'approved' => 'Disetujui', 'rejected' => 'Ditolak'];
$hariIniIzin = date('Y-m-d');
$statusClass = ['pending' => 'pending', 'approved' => 'ok', 'rejected' => 'bad'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Izin/Sakit — Absensi Magang</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_mahasiswa.php'; ?>
<div class="container pb-5">
    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Ajukan baru</p>
      <h2 class="h6 fw-bold mb-2">Form Izin / Sakit</h2>

      <div class="alert alert-info small">
        ℹ️ <b>Izin/sakit 1 hari untuk hari ini langsung disetujui.</b> Selebihnya menunggu persetujuan pembimbing.
      </div>
      <form method="POST" enctype="multipart/form-data" style="margin-top:12px;">
        <?= csrfField() ?>
        <div class="mb-3">
          <label class="form-label">Jenis</label>
          <select name="jenis" required class="form-select">
            <option value="izin">Izin</option>
            <option value="sakit">Sakit</option>
          </select>
        </div>
        <div class="mb-3"><label class="form-label">Tanggal mulai</label><input type="date" name="tanggal_mulai" required class="form-control"></div>
        <div class="mb-3"><label class="form-label">Tanggal selesai</label><input type="date" name="tanggal_selesai" required class="form-control"></div>
        <div class="mb-3"><label class="form-label">Keterangan</label><textarea name="keterangan" rows="3" placeholder="Jelaskan alasan izin/sakit" required class="form-control"></textarea></div>
        <div class="mb-3"><label class="form-label">Lampiran (opsional, JPG/PNG/PDF maks 3MB)</label><input type="file" name="lampiran" accept=".jpg,.jpeg,.png,.pdf" class="form-control"></div>

        <?php if ($error): ?><p class="alert alert-danger py-2 small"><?= e($error) ?></p><?php endif; ?>
        <?php if ($success): ?><p class="alert alert-success py-2 small"><?= e($success) ?></p><?php endif; ?>

        <button type="submit" name="ajukan" value="1" class="btn btn-primary mt-2">Kirim Pengajuan</button>
      </form>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Riwayat</p>
      <h2 class="h6 fw-bold mb-2">Pengajuan Kamu — <?= e(namaBulanID($bulan)) ?></h2>
      <form method="GET" class="mb-3" style="max-width:340px;">
        <?php foreach ($_GET as $kunci => $nilai): if (in_array($kunci, ['bulan', 'tahun', 'bln', 'halaman'], true) || is_array($nilai)) continue; ?>
          <input type="hidden" name="<?= e($kunci) ?>" value="<?= e($nilai) ?>">
        <?php endforeach; ?>
        <?= dropdownBulan($daftarTahun, $bulan) ?>
        <noscript><button class="btn btn-secondary btn-sm mt-1">Tampilkan</button></noscript>
      </form>
      <p class="text-muted small mb-2">Pengajuan yang masih menunggu selalu ditampilkan, walau tanggalnya di bulan lain.</p>
      <div class="daftar-gulir" style="margin-top:10px;max-height:520px;">
        <?php if (empty($daftarIzin)): ?>
          <div class="text-muted small text-center py-3">Tidak ada pengajuan izin/sakit di <?= e(namaBulanID($bulan)) ?>. Pilih bulan lain di atas untuk melihat data lainnya.</div>
        <?php else: foreach ($daftarIzin as $i): ?>
          <div class="list-group-item px-0">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <b><?= $i['jenis']==='sakit' ? 'Sakit' : 'Izin' ?></b>
              <span class="badge text-bg-<?= ['pending'=>'warning','approved'=>'success','rejected'=>'danger'][$i['status']] ?>"><?= $statusLabel[$i['status']] ?></span>
              <?php if (!empty($i['disetujui_otomatis'])): ?>
                <span class="badge text-bg-light text-dark">otomatis</span>
              <?php endif; ?>
            </div>
            <div class="small text-muted"><?= e(formatRentangTanggal($i['tanggal_mulai'], $i['tanggal_selesai'])) ?></div>
            <div class="small mt-1"><?= e($i['keterangan']) ?></div>
            <?php if ($i['file_lampiran']): ?>
              <?= htmlLampiranIzin($i['file_lampiran']) ?>
            <?php endif; ?>
            <?php
              $izinOtomatisMasihBerlaku = $i['status'] === 'approved' && !empty($i['disetujui_otomatis'])
                                         && $i['tanggal_selesai'] >= date('Y-m-d');
            ?>
            <?php if ($i['status']==='pending' || $izinOtomatisMasihBerlaku): ?>
              <div class="d-flex flex-wrap gap-2 mt-2">
                <form method="POST" style="margin:0;"
                      data-konfirmasi="<?= $izinOtomatisMasihBerlaku
                          ? 'Hapus izin/sakit ini? Kalau kamu salah memilih tanggal, ajukan ulang dengan tanggal yang benar. Setelah dihapus, kamu bisa absen seperti biasa untuk hari ini.'
                          : 'Hapus pengajuan izin/sakit ini?' ?>"
                      data-konfirmasi-judul="Hapus pengajuan" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1">
                  <?= csrfField() ?>
                  <input type="hidden" name="hapus" value="<?= $i['id'] ?>" class="form-control">
                  <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; endif; ?>
      </div>
      </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
