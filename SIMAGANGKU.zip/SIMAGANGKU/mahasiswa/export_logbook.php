<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

/**
 * Cetak/unduh Log Book sebagai PDF (lewat fitur "Print to PDF" browser),
 * memakai pola yang sama dengan export laporan absensi.
 *
 * Dipakai 2 arah:
 * - Mahasiswa  : mencetak log book MILIKNYA SENDIRI (menu Log Book → Unduh PDF).
 * - Admin/pembimbing : mencetak log book seorang mahasiswa (?mahasiswa=ID),
 *   dengan pembatasan yang sama seperti halaman lain (pembimbing hanya bimbingannya,
 *   dan hanya yang satu cabang dengan akunnya).
 *
 * Rentang tanggal: ?bulan=YYYY-MM (dipakai halaman mahasiswa) atau ?dari= & ?sampai=.
 */

$pdo = getDB();
$userLogin = currentUser();

// ---- Tentukan pemilik log book yang dicetak ----
if ($userLogin['role'] === 'mahasiswa') {
    $mahasiswaId = (int) $userLogin['id'];
} else {
    $mahasiswaId = isset($_GET['mahasiswa']) ? (int) $_GET['mahasiswa'] : 0;
    // Admin: semua mahasiswa. Pembimbing: hanya bimbingannya (dan cabangnya, lihat di bawah).
    if (!$mahasiswaId || !bolehAksesMahasiswa($mahasiswaId)) {
        http_response_code(403);
        exit('Mahasiswa tidak ditemukan atau bukan wewenangmu.');
    }
    if (isPembimbing()) {
        $cabangPembimbing = cabangOtomatisPembimbing();
        $cekCabang = $pdo->prepare("SELECT 1 FROM users WHERE id = ? AND cabang_id <=> ?");
        $cekCabang->execute([$mahasiswaId, $cabangPembimbing['id'] ?? null]);
        if (!$cekCabang->fetchColumn()) {
            http_response_code(403);
            exit('Mahasiswa ini berada di cabang lain, jadi log book-nya tidak bisa dibuka dari akunmu.');
        }
    }
}

$stmtMhs = $pdo->prepare("SELECT u.nama, u.identifier, u.kampus, u.tanggal_mulai, u.tanggal_selesai,
                                 c.nama_cabang, k.nama AS nama_kategori, p.nama AS nama_pembimbing, d.nama AS divisi_pembimbing
                          FROM users u
                          LEFT JOIN cabang c ON c.id = u.cabang_id
                          LEFT JOIN kategori k ON k.id = u.kategori_id
                          LEFT JOIN users p ON p.id = u.pembimbing_id
                          LEFT JOIN divisi d ON d.id = p.divisi_id
                          WHERE u.id = ? AND u.role = 'mahasiswa'");
$stmtMhs->execute([$mahasiswaId]);
$mhs = $stmtMhs->fetch();
if (!$mhs) {
    http_response_code(404);
    exit('Data mahasiswa tidak ditemukan.');
}

// ---- Rentang tanggal ----
$tanggalValid = fn($t) => is_string($t) && ($d = DateTime::createFromFormat('Y-m-d', $t)) && $d->format('Y-m-d') === $t;
if (isset($_GET['bulan']) && preg_match('/^\d{4}-\d{2}$/', $_GET['bulan'])) {
    $dari = $_GET['bulan'] . '-01';
    $sampai = date('Y-m-t', strtotime($dari));
} else {
    $dari = $tanggalValid($_GET['dari'] ?? '') ? $_GET['dari'] : date('Y-m-01');
    $sampai = $tanggalValid($_GET['sampai'] ?? '') ? $_GET['sampai'] : date('Y-m-d');
}
if ($sampai < $dari) [$dari, $sampai] = [$sampai, $dari];

$stmt = $pdo->prepare("SELECT * FROM logbook WHERE user_id = ? AND tanggal BETWEEN ? AND ?
                       ORDER BY tanggal ASC, id ASC");
$stmt->execute([$mahasiswaId, $dari, $sampai]);
$perTanggal = kelompokkanLogbook($stmt->fetchAll());

$pengaturan = ambilPengaturan();
$jam5 = fn($j) => $j ? substr($j, 0, 5) : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Log Book — <?= e($mhs['nama']) ?></title>
<style>
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color:#222; margin:24px; font-size:12px; }
  h1 { font-size:17px; margin:0 0 2px; text-align:center; }
  h2 { font-size:13px; margin:0 0 14px; text-align:center; font-weight:normal; color:#555; }
  table { width:100%; border-collapse:collapse; margin-top:10px; }
  th, td { border:1px solid #999; padding:6px 7px; vertical-align:top; overflow-wrap:anywhere; word-break:break-word; }
  th { background:#eee; text-align:left; font-size:11.5px; }
  td.tgl, td.jam, td.durasi { white-space:nowrap; }
  .identitas { width:100%; margin-bottom:6px; font-size:12px; }
  .identitas td { border:none; padding:1px 0; }
  .identitas td:first-child { width:130px; }
  .ringkas { margin-top:10px; font-size:12px; }
  .ttd { margin-top:36px; width:100%; }
  .ttd td { border:none; text-align:center; width:50%; font-size:12px; vertical-align:top; }
  .tgl-ttd { display:block; margin-bottom:2px; }
  .garis-ttd { display:block; width:220px; margin:70px auto 0; border-top:1px solid #333; padding-top:4px; }
  .kosong { text-align:center; color:#777; padding:18px; }
  @media print { body { margin:12mm; } .no-print { display:none; } }
</style>
</head>
<body>
<div class="no-print" style="text-align:right;margin-bottom:10px;">
  <button onclick="window.print()" style="padding:8px 16px;cursor:pointer;">🖨️ Cetak / Simpan PDF</button>
</div>

<h1>LOG BOOK KEGIATAN HARIAN</h1>
<h2><?= e($pengaturan['nama_instansi']) ?></h2>

<table class="identitas">
  <tr><td>Nama</td><td>: <?= e($mhs['nama']) ?></td></tr>
  <tr><td>NIM/Username</td><td>: <?= e($mhs['identifier']) ?></td></tr>
  <?php if ($mhs['kampus']): ?><tr><td>Asal kampus/sekolah</td><td>: <?= e($mhs['kampus']) ?></td></tr><?php endif; ?>
  <?php if ($mhs['nama_kategori']): ?><tr><td>Kategori</td><td>: <?= e($mhs['nama_kategori']) ?></td></tr><?php endif; ?>
  <?php if ($mhs['nama_cabang']): ?><tr><td>Lokasi magang</td><td>: <?= e($mhs['nama_cabang']) ?></td></tr><?php endif; ?>
  <?php if ($mhs['nama_pembimbing']): ?>
    <tr><td>Pembimbing</td><td>: <?= e($mhs['nama_pembimbing']) ?><?= $mhs['divisi_pembimbing'] ? ' (' . e($mhs['divisi_pembimbing']) . ')' : '' ?></td></tr>
  <?php endif; ?>
  <tr><td>Periode laporan</td><td>: <?= e(formatRentangTanggal($dari, $sampai)) ?></td></tr>
</table>

<?php if (!$perTanggal): ?>
  <p class="kosong">Belum ada catatan kegiatan pada periode ini.</p>
<?php else: ?>
  <table>
    <thead>
      <tr>
        <th style="width:18%;">Hari/Tanggal</th>
        <th style="width:6%;">No</th>
        <th>Uraian Kegiatan</th>
        <th style="width:22%;">Hasil / Kendala</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($perTanggal as $tgl => $grup): $baris = 0; ?>
        <?php foreach ($grup['items'] as $it): $baris++; ?>
          <tr>
            <?php if ($baris === 1): ?>
              <td class="tgl" rowspan="<?= count($grup['items']) ?>">
                <?= namaHariID(date('N', strtotime($tgl))) ?>,<br><?= e(formatTanggalID($tgl)) ?>
                <br><span style="color:#666;"><?= count($grup['items']) ?> kegiatan</span>
              </td>
            <?php endif; ?>
            <td class="jam"><?= $baris ?></td>
            <td><?= nl2br(e($it['kegiatan'])) ?></td>
            <td>
              <?= $it['hasil'] ? e($it['hasil']) : '' ?>
              <?= $it['hasil'] && $it['kendala'] ? '<br>' : '' ?>
              <?= $it['kendala'] ? 'Kendala: ' . e($it['kendala']) : '' ?>
              <?= !$it['hasil'] && !$it['kendala'] ? '-' : '' ?>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </tbody>
  </table>

  <p class="ringkas">
    Jumlah hari terisi: <b><?= count($perTanggal) ?> hari</b> &nbsp;·&nbsp;
    Jumlah catatan kegiatan: <b><?= array_sum(array_map(fn($g) => count($g['items']), $perTanggal)) ?></b>
  </p>
<?php endif; ?>

<table class="ttd">
  <tr>
    <!-- Kedua kolom sengaja punya baris "tanggal" yang sama tingginya (yang kiri kosong)
         dan rata atas, supaya garis tanda tangan mahasiswa & pembimbing benar-benar sejajar. -->
    <td>
      <span class="tgl-ttd">&nbsp;</span>
      Mahasiswa,
      <div class="garis-ttd"><?= e($mhs['nama']) ?></div>
    </td>
    <td>
      <span class="tgl-ttd"><?= e(formatTanggalID(date('Y-m-d'))) ?></span>
      Pembimbing,
      <div class="garis-ttd"><?= e($mhs['nama_pembimbing'] ?: '.....................................') ?></div>
    </td>
  </tr>
</table>
</body>
</html>
