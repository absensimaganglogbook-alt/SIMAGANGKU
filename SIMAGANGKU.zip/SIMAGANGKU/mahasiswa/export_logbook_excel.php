<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

/**
 * Unduh Log Book sebagai file Excel (.xls).
 *
 * Memakai pola yang sama dengan export laporan absensi: tabel HTML yang dikirim
 * dengan header Excel, jadi tidak butuh library tambahan dan tetap bisa dibuka
 * di Excel, LibreOffice, maupun Google Sheets.
 *
 * Hak aksesnya sama dengan versi PDF (mahasiswa/export_logbook.php):
 * - mahasiswa  : hanya log book miliknya sendiri,
 * - pembimbing : mahasiswa bimbingannya di cabangnya,
 * - admin      : semua mahasiswa.
 */

$pdo = getDB();
$userLogin = currentUser();

// ---- Tentukan pemilik log book ----
if ($userLogin['role'] === 'mahasiswa') {
    $mahasiswaId = (int) $userLogin['id'];
} else {
    $mahasiswaId = isset($_GET['mahasiswa']) ? (int) $_GET['mahasiswa'] : 0;
    if (!$mahasiswaId || !bolehAksesMahasiswa($mahasiswaId)) {
        http_response_code(403);
        exit('Mahasiswa tidak ditemukan atau bukan wewenangmu.');
    }
    if (isPembimbing()) {
        $cabangPembimbing = cabangOtomatisPembimbing();
        $cekCabang = $pdo->prepare("SELECT 1 FROM users WHERE id = ? AND cabang_id <=> ?");
        $cekCabang->execute([$mahasiswaId, $cabangPembimbing['id'] ?? null]);
        if (!$cekCabang->fetchColumn()) {
            http_response_code(403);
            exit('Mahasiswa ini berada di cabang lain, jadi log book-nya tidak bisa dibuka dari akunmu.');
        }
    }
}

$stmtMhs = $pdo->prepare("SELECT u.nama, u.identifier, u.kampus, c.nama_cabang, k.nama AS nama_kategori,
                                 p.nama AS nama_pembimbing, d.nama AS divisi_pembimbing
                          FROM users u
                          LEFT JOIN cabang c ON c.id = u.cabang_id
                          LEFT JOIN kategori k ON k.id = u.kategori_id
                          LEFT JOIN users p ON p.id = u.pembimbing_id
                          LEFT JOIN divisi d ON d.id = p.divisi_id
                          WHERE u.id = ? AND u.role = 'mahasiswa'");
$stmtMhs->execute([$mahasiswaId]);
$mhs = $stmtMhs->fetch();
if (!$mhs) {
    http_response_code(404);
    exit('Data mahasiswa tidak ditemukan.');
}

// ---- Rentang tanggal: ?bulan=YYYY-MM atau ?dari= & ?sampai= ----
$tanggalValid = fn($t) => is_string($t) && ($d = DateTime::createFromFormat('Y-m-d', $t)) && $d->format('Y-m-d') === $t;
if (isset($_GET['bulan']) && preg_match('/^\d{4}-\d{2}$/', $_GET['bulan'])) {
    $dari = $_GET['bulan'] . '-01';
    $sampai = date('Y-m-t', strtotime($dari));
} else {
    $dari = $tanggalValid($_GET['dari'] ?? '') ? $_GET['dari'] : date('Y-m-01');
    $sampai = $tanggalValid($_GET['sampai'] ?? '') ? $_GET['sampai'] : date('Y-m-d');
}
if ($sampai < $dari) [$dari, $sampai] = [$sampai, $dari];

$stmt = $pdo->prepare("SELECT * FROM logbook WHERE user_id = ? AND tanggal BETWEEN ? AND ?
                       ORDER BY tanggal ASC, id ASC");
$stmt->execute([$mahasiswaId, $dari, $sampai]);
$baris = $stmt->fetchAll();
$perTanggal = kelompokkanLogbook($baris);

$pengaturan = ambilPengaturan();

// ---- Header file Excel ----
$namaFile = 'logbook_' . preg_replace('/[^a-zA-Z0-9]+/', '-', $mhs['nama'])
          . '_' . preg_replace('/[^0-9-]/', '', $dari) . '_sd_' . preg_replace('/[^0-9-]/', '', $sampai) . '.xls';

header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $namaFile . '"');
header('Pragma: no-cache');
header('Expires: 0');

echo "\xEF\xBB\xBF"; // BOM supaya huruf beraksen tampil benar di Excel
?>
<table border="1">
  <tr><td colspan="5" style="font-size:16px;font-weight:bold;">LOG BOOK KEGIATAN HARIAN</td></tr>
  <tr><td colspan="5"><?= e($pengaturan['nama_instansi']) ?></td></tr>
  <tr><td colspan="5"></td></tr>
  <tr><td>Nama</td><td colspan="4"><?= e($mhs['nama']) ?></td></tr>
  <tr><td>NIM/Username</td><td colspan="4"><?= e($mhs['identifier']) ?></td></tr>
  <?php if ($mhs['kampus']): ?><tr><td>Asal kampus/sekolah</td><td colspan="4"><?= e($mhs['kampus']) ?></td></tr><?php endif; ?>
  <?php if ($mhs['nama_kategori']): ?><tr><td>Kategori</td><td colspan="4"><?= e($mhs['nama_kategori']) ?></td></tr><?php endif; ?>
  <?php if ($mhs['nama_cabang']): ?><tr><td>Lokasi magang</td><td colspan="4"><?= e($mhs['nama_cabang']) ?></td></tr><?php endif; ?>
  <?php if ($mhs['nama_pembimbing']): ?>
    <tr><td>Pembimbing</td><td colspan="4"><?= e($mhs['nama_pembimbing']) ?><?= $mhs['divisi_pembimbing'] ? ' (' . e($mhs['divisi_pembimbing']) . ')' : '' ?></td></tr>
  <?php endif; ?>
  <tr><td>Periode laporan</td><td colspan="4"><?= e(formatRentangTanggal($dari, $sampai)) ?></td></tr>
  <tr><td colspan="5"></td></tr>

  <tr style="background:#eeeeee;font-weight:bold;">
    <td>No</td>
    <td>Hari</td>
    <td>Tanggal</td>
    <td>Uraian Kegiatan</td>
    <td>Hasil / Kendala</td>
  </tr>
  <?php if (!$baris): ?>
    <tr><td colspan="5">Belum ada catatan kegiatan pada periode ini.</td></tr>
  <?php else: $no = 0; foreach ($perTanggal as $tgl => $grup): ?>
    <?php foreach ($grup['items'] as $it): $no++; ?>
      <tr>
        <td><?= $no ?></td>
        <td><?= e(namaHariID(date('N', strtotime($tgl)))) ?></td>
        <td><?= e(formatTanggalID($tgl)) ?></td>
        <td><?= e($it['kegiatan']) ?></td>
        <td>
          <?php
            $ket = array_filter([
                $it['hasil'] ? 'Hasil: ' . $it['hasil'] : null,
                $it['kendala'] ? 'Kendala: ' . $it['kendala'] : null,
            ]);
            echo $ket ? e(implode(' | ', $ket)) : '-';
          ?>
        </td>
      </tr>
    <?php endforeach; ?>
  <?php endforeach; endif; ?>

  <tr><td colspan="5"></td></tr>
  <tr><td colspan="2">Jumlah hari terisi</td><td colspan="3"><?= count($perTanggal) ?> hari</td></tr>
  <tr><td colspan="2">Jumlah catatan kegiatan</td><td colspan="3"><?= count($baris) ?></td></tr>

  <tr><td colspan="5"></td></tr>
  <tr><td colspan="5"></td></tr>
  <tr>
    <td colspan="2" align="center">Mahasiswa,</td>
    <td></td>
    <td colspan="2" align="center"><?= e(formatTanggalID(date('Y-m-d'))) ?><br>Pembimbing,</td>
  </tr>
  <tr><td colspan="5"></td></tr>
  <tr><td colspan="5"></td></tr>
  <tr><td colspan="5"></td></tr>
  <tr>
    <td colspan="2" align="center"><?= e($mhs['nama']) ?></td>
    <td></td>
    <td colspan="2" align="center"><?= e($mhs['nama_pembimbing'] ?: '.....................................') ?></td>
  </tr>
</table>
