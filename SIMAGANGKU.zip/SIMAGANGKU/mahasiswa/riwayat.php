<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('mahasiswa');
$user = currentUser();
$pdo = getDB();

// Bawaannya hanya menampilkan bulan berjalan; bulan lama tetap bisa dipilih.
$bulan = bulanDipilih();
[$awalBulan, $akhirBulan] = rentangBulan($bulan);

$stmtAwal = $pdo->prepare("SELECT DATE_FORMAT(MIN(tanggal), '%Y-%m') FROM absensi WHERE user_id=?");
$stmtAwal->execute([$user['id']]);
$daftarTahun = daftarTahunPilihan(substr((string) $stmtAwal->fetchColumn(), 0, 4), substr($bulan, 0, 4));

$totalRiwayat = $pdo->prepare("SELECT COUNT(*) c FROM absensi WHERE user_id=? AND tanggal BETWEEN ? AND ?");
$totalRiwayat->execute([$user['id'], $awalBulan, $akhirBulan]);
$totalRiwayat = (int)$totalRiwayat->fetch()['c'];

$pg = paginasi($totalRiwayat, $_GET['halaman'] ?? 1, 20);

$stmt = $pdo->prepare("SELECT * FROM absensi WHERE user_id=? AND tanggal BETWEEN ? AND ?
                       ORDER BY tanggal DESC, waktu DESC LIMIT {$pg['perHalaman']} OFFSET {$pg['offset']}");
$stmt->execute([$user['id'], $awalBulan, $akhirBulan]);
$riwayat = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Riwayat — Absensi Magang</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_mahasiswa.php'; ?>
<div class="container pb-5">

    <div class="card mb-3">
      <div class="card-body">
      <p class="text-primary fw-semibold small mb-1">Riwayat</p>
      <h2 class="h6 fw-bold mb-2">Aktivitas <?= e(namaBulanID($bulan)) ?> (<?= $totalRiwayat ?>)</h2>
      <form method="GET" class="mb-3" style="max-width:340px;">
        <?php foreach ($_GET as $kunci => $nilai): if (in_array($kunci, ['bulan', 'tahun', 'bln', 'halaman'], true) || is_array($nilai)) continue; ?>
          <input type="hidden" name="<?= e($kunci) ?>" value="<?= e($nilai) ?>">
        <?php endforeach; ?>
        <?= dropdownBulan($daftarTahun, $bulan) ?>
        <noscript><button class="btn btn-secondary btn-sm mt-1">Tampilkan</button></noscript>
      </form>

      <div class="list-group list-group-flush daftar-gulir" style="max-height:520px;">
        <?php if (empty($riwayat)): ?>
          <div class="text-muted small text-center py-3">Tidak ada riwayat absen di <?= e(namaBulanID($bulan)) ?>. Pilih bulan lain di atas untuk melihat data lainnya.</div>
        <?php else: foreach ($riwayat as $r): ?>
          <div class="list-group-item px-0 d-flex align-items-center gap-2">
            <img src="<?= e(urlAvatar($r['foto'], $user['nama'] ?? '')) ?>" class="rounded" style="width:38px;height:38px;object-fit:cover;">
            <div class="flex-grow-1">
              <p class="small fw-semibold mb-0"><?= $r['jenis']==='masuk' ? 'Absen Masuk' : 'Absen Pulang' ?></p>
              <span class="text-muted" style="font-size:11.5px;">
                <?= e(formatTanggalID($r['tanggal'])) ?> · <?= substr($r['waktu'],0,5) ?>
                <?= $r['diisi_admin'] ? ' · Diisi admin ('.e(['hadir'=>'Hadir','sakit'=>'Sakit','izin'=>'Izin','lainnya'=>'Lainnya'][$r['alasan_manual']] ?? '-').')' : ' · '.$r['jarak_meter'].'m'.($r['wfa'] ? ' · WFA' : '') ?>
              </span>
            </div>
            <span class="badge text-bg-<?= $r['status']!=='valid' ? 'danger' : ($r['diisi_admin'] ? 'warning' : ($r['terlambat'] ? 'warning' : 'success')) ?>"><?= $r['status']!=='valid' ? 'Ditolak' : ($r['diisi_admin'] ? 'Diisi Admin' : ($r['terlambat'] ? 'Terlambat' : 'Berhasil')) ?></span>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <?php if ($pg['totalHalaman'] > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
          <?php if ($pg['halaman'] > 1): ?>
            <a href="<?= urlHalaman($pg['halaman'] - 1) ?>" class="btn btn-outline-secondary btn-sm">← Sebelumnya</a>
          <?php else: ?><span></span><?php endif; ?>
          <span class="text-muted small">Halaman <?= $pg['halaman'] ?> dari <?= $pg['totalHalaman'] ?></span>
          <?php if ($pg['halaman'] < $pg['totalHalaman']): ?>
            <a href="<?= urlHalaman($pg['halaman'] + 1) ?>" class="btn btn-outline-secondary btn-sm">Berikutnya →</a>
          <?php else: ?><span></span><?php endif; ?>
        </div>
      <?php endif; ?>
      </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
