<?php
/**
 * Endpoint absen (dipanggil lewat JavaScript, membalas JSON).
 *
 * Dijaga supaya balasannya SELALU JSON yang bersih: peringatan PHP yang tercetak
 * (mis. di Laragon/XAMPP yang menampilkan error di layar) dibuang sebelum JSON
 * dikirim, dan error fatal ditangkap lalu dibalas sebagai pesan JSON yang jelas.
 * Tanpa ini, satu peringatan kecil membuat halaman absen hanya menampilkan
 * "kesalahan jaringan" yang menyesatkan.
 */
ob_start();
register_shutdown_function(function () {
    $galat = error_get_last();
    if ($galat && in_array($galat['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        while (ob_get_level() > 0) ob_end_clean();
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json');
        }
        error_log('absen_proses fatal: ' . $galat['message'] . ' di ' . $galat['file'] . ':' . $galat['line']);
        echo json_encode(['ok' => false, 'message' => 'Terjadi kesalahan di server saat memproses absen. Hubungi admin.']);
    }
});

require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');

/** Kirim balasan JSON bersih (buang keluaran lain yang terlanjur tercetak), lalu berhenti. */
function balasJson($data, $status = 200) {
    while (ob_get_level() > 0) ob_end_clean();
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

if (!isLoggedIn() || $_SESSION['user_role'] !== 'mahasiswa') {
    balasJson(['ok' => false, 'message' => 'Sesi habis, silakan login ulang.'], 401);
}

// Kalau masa magang mahasiswa ini sudah lewat, tolak absen & nonaktifkan otomatis, paksa login ulang.
if (cekDanNonaktifkanJikaMagangSelesai($_SESSION['user_id'])) {
    session_unset();
    session_destroy();
    balasJson(['ok' => false, 'message' => 'Masa magang kamu sudah berakhir, akun otomatis dinonaktifkan. Silakan login ulang / hubungi admin.'], 403);
}

$input = json_decode(file_get_contents('php://input'), true);
// Token CSRF: endpoint ini menerima JSON, jadi tokennya dikirim di dalam body oleh
// halaman Absen. Tanpa ini, permintaan dari situs lain secara teori masih mungkin
// (walau sudah tertahan cookie SameSite=Lax) — sekarang konsisten dengan form lain.
$tokenKiriman = $input['csrf_token'] ?? '';
if (!is_string($tokenKiriman) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $tokenKiriman)) {
    balasJson(['ok' => false, 'message' => 'Sesi tidak valid atau sudah berubah. Muat ulang halaman ini lalu coba absen lagi.'], 403);
}

$jenis = $input['jenis'] ?? '';
$foto = $input['foto'] ?? '';
$lat = $input['lat'] ?? null;
$lng = $input['lng'] ?? null;
$mode = $input['mode'] ?? '';

if (!in_array($jenis, ['masuk', 'pulang']) || !$foto || $lat === null || $lng === null || !in_array($mode, ['wfo', 'wfa'])) {
    balasJson(['ok' => false, 'message' => 'Data tidak lengkap. Pilih mode WFO atau WFA dulu sebelum absen.']);
}
$isWFA = $mode === 'wfa';

$user = currentUser();
$today = date('Y-m-d');
$pdo = getDB();

// Tolak absen kalau tanggal mulai magang mahasiswa ini masih di masa depan
// (akun sudah dibuat/aktif lebih awal dari tanggal mulai yang diatur admin).
$stmtMulai = $pdo->prepare("SELECT tanggal_mulai FROM users WHERE id=?");
$stmtMulai->execute([$user['id']]);
$tanggalMulaiUser = $stmtMulai->fetchColumn();
if (magangBelumMulai($tanggalMulaiUser)) {
    balasJson(['ok' => false, 'message' => 'Masa magang kamu belum mulai. Absen baru dibuka mulai tanggal ' . formatTanggalID($tanggalMulaiUser) . '.']);
}

// Cabang/lokasi tempat mahasiswa ini magang — dipakai sebagai patokan jam kerja
// & jarak, bukan pengaturan global lagi, supaya mahasiswa di cabang berbeda-beda
// tetap divalidasi terhadap jam kerja & kantor cabangnya masing-masing.
$cabang = ambilCabangMahasiswa($user['id']);
if (!$cabang) {
    balasJson(['ok' => false, 'message' => 'Akun kamu belum terdaftar ke cabang/lokasi manapun. Hubungi admin untuk mengatur cabang magangmu dulu.']);
}
if (!cabangSudahDiatur($cabang)) {
    balasJson(['ok' => false, 'message' => 'Cabang tempat kamu magang belum diatur jam kerjanya oleh admin. Hubungi admin untuk mengaturnya dulu sebelum bisa absen.']);
}

// Hari libur: Sabtu/Minggu otomatis, atau tanggal yang didaftarkan admin sebagai libur nasional/khusus
$cekLibur = cekHariLibur($today);
if ($cekLibur['libur']) {
    balasJson(['ok' => false, 'message' => 'Hari ini libur (' . $cekLibur['keterangan'] . '), absen tidak dibuka.']);
}

// Cek sedang izin/sakit disetujui
$stmt = $pdo->prepare("SELECT id FROM izin WHERE user_id=? AND status='approved' AND ? BETWEEN tanggal_mulai AND tanggal_selesai LIMIT 1");
$stmt->execute([$user['id'], $today]);
if ($stmt->fetch()) {
    balasJson(['ok' => false, 'message' => 'Kamu sedang izin/sakit yang disetujui untuk hari ini, absen dikunci.']);
}

// Cek sudah absen jenis ini hari ini
$stmt = $pdo->prepare("SELECT status FROM absensi WHERE user_id=? AND tanggal=? AND jenis=? LIMIT 1");
$stmt->execute([$user['id'], $today, $jenis]);
$existing = $stmt->fetch();
if ($existing && $existing['status'] === 'valid') {
    balasJson(['ok' => false, 'message' => 'Kamu sudah absen ' . $jenis . ' hari ini.']);
}

// Absen pulang harus setelah absen masuk yang valid
if ($jenis === 'pulang') {
    $stmt = $pdo->prepare("SELECT status, wfa FROM absensi WHERE user_id=? AND tanggal=? AND jenis='masuk' LIMIT 1");
    $stmt->execute([$user['id'], $today]);
    $masuk = $stmt->fetch();
    if (!$masuk || $masuk['status'] !== 'valid') {
        balasJson(['ok' => false, 'message' => 'Kamu belum absen masuk hari ini.']);
    }
    // Mode absen pulang harus sama dengan mode absen masuk hari ini (WFO tetap WFO, WFA tetap WFA).
    $modeMasuk = (int)$masuk['wfa'] === 1 ? 'wfa' : 'wfo';
    if ($modeMasuk !== $mode) {
        $labelModeMasuk = $modeMasuk === 'wfa' ? 'WFA' : 'WFO';
        balasJson(['ok' => false, 'message' => "Absen masuk kamu tadi pakai mode $labelModeMasuk, jadi absen pulang hari ini juga harus $labelModeMasuk. Tidak bisa beda mode dalam satu hari."]);
    }
}

$jamSekarang = date('H:i:s');

// Validasi jam: absen masuk paling awal jam_masuk, absen pulang paling awal jam_pulang (jam kerja cabang ini)
if ($jenis === 'masuk' && $jamSekarang < $cabang['jam_masuk']) {
    balasJson(['ok' => false, 'message' => 'Belum waktunya absen masuk. Absen masuk dibuka mulai jam ' . substr($cabang['jam_masuk'], 0, 5) . '.']);
}
// Absen masuk DITUTUP setelah jam pulang cabang — lewat dari itu hari ini tercatat tidak hadir.
if ($jenis === 'masuk' && absenMasukSudahDitutup($cabang, $today, $jamSekarang)) {
    balasJson(['ok' => false, 'message' => 'Absen masuk sudah ditutup (batas jam ' . substr($cabang['jam_pulang'], 0, 5) . '). '
        . 'Hari ini tercatat tidak hadir. Kalau kamu sebenarnya hadir, minta admin/pembimbing mengisikannya lewat Absen Manual.']);
}
if ($jenis === 'pulang' && $jamSekarang < $cabang['jam_pulang']) {
    balasJson(['ok' => false, 'message' => 'Absen pulang baru bisa dilakukan mulai jam ' . substr($cabang['jam_pulang'], 0, 5) . '.']);
}

// Tentukan terlambat: hanya berlaku untuk absen masuk yang melewati batas_terlambat (cabang ini)
$terlambat = ($jenis === 'masuk' && $jamSekarang > $cabang['batas_terlambat']) ? 1 : 0;

// Validasi jarak ke lokasi cabang mahasiswa ini — dilewati kalau mahasiswa memilih mode WFA
$jarak = hitungJarakMeter((float)$lat, (float)$lng, (float)$cabang['lat'], (float)$cabang['lng']);
if ($isWFA) {
    $statusAbsen = 'valid';
    $keterangan = $terlambat ? 'WFA · Terlambat' : 'WFA';
} else {
    $statusAbsen = $jarak <= (int)$cabang['radius_meter'] ? 'valid' : 'ditolak';
    $keterangan = $statusAbsen === 'ditolak' ? "Di luar radius ({$jarak}m > {$cabang['radius_meter']}m)" : ($terlambat ? 'Terlambat' : null);
}

// Foto hanya disimpan ke server kalau lokasinya memang valid (di dalam radius / mode WFA).
// Kalau ditolak karena di luar jangkauan, foto TIDAK disimpan sama sekali — supaya percobaan
// absen berulang-ulang dari lokasi yang jauh (mis. iseng/spam) tidak numpuk jadi banyak file
// di folder uploads/absen tanpa guna.
if ($statusAbsen === 'ditolak') {
    $pathFoto = null;
} else {
    $pathFoto = simpanFotoBase64($foto, 'absen', $jenis . '_' . $user['id']);
    if ($pathFoto === false) {
        balasJson(['ok' => false, 'message' => 'Foto gagal disimpan di server. Coba lagi; kalau tetap gagal, hubungi admin untuk memeriksa folder penyimpanan (uploads).']);
    }
}

try {
    if ($existing) {
        // absen sebelumnya ditolak, timpa dengan percobaan baru.
        // Kalau data lama masih menyimpan foto (mis. dari sebelum perubahan ini berlaku)
        // dan sekarang ditimpa, hapus dulu file fisiknya supaya tidak jadi file "yatim"
        // yang menumpuk percuma di folder uploads/absen.
        if (!empty($existing['foto']) && $existing['foto'] !== $pathFoto) {
            $fileLama = __DIR__ . '/../uploads/' . $existing['foto'];
            if (is_file($fileLama)) @unlink($fileLama);
        }
        $stmt = $pdo->prepare("UPDATE absensi SET waktu=?, foto=?, lat=?, lng=?, jarak_meter=?, status=?, terlambat=?, wfa=?, keterangan=?, created_at=NOW()
                                WHERE user_id=? AND tanggal=? AND jenis=?");
        $stmt->execute([date('H:i:s'), $pathFoto, $lat, $lng, $jarak, $statusAbsen, $terlambat, $isWFA ? 1 : 0, $keterangan, $user['id'], $today, $jenis]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO absensi (user_id, tanggal, jenis, waktu, foto, lat, lng, jarak_meter, status, terlambat, wfa, keterangan)
                                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$user['id'], $today, $jenis, date('H:i:s'), $pathFoto, $lat, $lng, $jarak, $statusAbsen, $terlambat, $isWFA ? 1 : 0, $keterangan]);
    }

    if ($statusAbsen === 'ditolak') {
        balasJson(['ok' => false, 'message' => "Absen ditolak: kamu berada {$jarak}m dari lokasi magang (maksimal {$cabang['radius_meter']}m)."]);
    } elseif ($isWFA && $terlambat) {
        balasJson(['ok' => true, 'message' => 'Absen WFA berhasil dicatat, tapi kamu terlambat.']);
    } elseif ($isWFA) {
        balasJson(['ok' => true, 'message' => 'Absen WFA berhasil dicatat. Selamat bekerja dari mana saja!']);
    } elseif ($terlambat) {
        balasJson(['ok' => true, 'message' => 'Absen masuk berhasil dicatat, tapi kamu terlambat.']);
    } else {
        balasJson(['ok' => true, 'message' => 'Absen berhasil dicatat.']);
    }
} catch (Throwable $e) {
    error_log('absen_proses: ' . $e->getMessage() . ' di ' . $e->getFile() . ':' . $e->getLine());
    balasJson(['ok' => false, 'message' => 'Terjadi kesalahan di server saat menyimpan absen. Coba lagi; kalau tetap gagal, hubungi admin.'], 500);
}
