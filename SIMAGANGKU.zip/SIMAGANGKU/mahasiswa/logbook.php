<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('mahasiswa');
$user = currentUser();
$pdo = getDB();
$error = '';
$success = '';

/**
 * Log Book mahasiswa: catatan aktivitas harian.
 * 1 baris = 1 aktivitas (ada jam mulai & selesai), jadi 1 hari bisa berisi
 * beberapa aktivitas. Mahasiswa bebas menambah, mengubah, dan menghapus
 * catatannya sendiri selama masih dalam periode magang.
 * Pembimbing & admin hanya melihat dan mengekspornya ke PDF.
 */

$stmtUser = $pdo->prepare("SELECT id, nama, identifier, tanggal_mulai, tanggal_selesai FROM users WHERE id = ?");
$stmtUser->execute([$user['id']]);
$dataUser = $stmtUser->fetch();

// Aturan: log book HANYA untuk hari ini, dan hanya setelah absen masuk tercatat.
// Catatan hari-hari sebelumnya terkunci (tidak bisa ditambah, diubah, atau dihapus).
$hariIni = date('Y-m-d');
$alasanTerkunci = alasanTidakBolehIsiLogbook($dataUser, $hariIni);
$bolehIsi = $alasanTerkunci === null;

// ---- Tambah / simpan perubahan ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    verifikasiCsrf();
    $idEdit = (int) ($_POST['id'] ?? 0);
    // Tanggal tidak diambil dari form: selalu hari ini, supaya tidak bisa diakali.
    $tanggal = $hariIni;
    $kegiatan = trim($_POST['kegiatan'] ?? '');
    $hasil = trim($_POST['hasil'] ?? '');
    $kendala = trim($_POST['kendala'] ?? '');

    $error = validasiLogbook($tanggal, $kegiatan, $dataUser) ?? '';

    if (!$error && $idEdit) {
        // Entri yang diedit harus milik mahasiswa ini DAN masih tanggal hari ini.
        $cek = $pdo->prepare("SELECT tanggal FROM logbook WHERE id = ? AND user_id = ?");
        $cek->execute([$idEdit, $user['id']]);
        $tanggalCatatan = $cek->fetchColumn();
        if (!$tanggalCatatan) {
            $error = 'Catatan tidak ditemukan atau bukan milikmu.';
        } elseif (!bolehUbahLogbook($tanggalCatatan, $hariIni)) {
            $error = 'Catatan hari ' . formatTanggalID($tanggalCatatan) . ' sudah terkunci dan tidak bisa diubah lagi.';
        }
    }

    if (!$error) {
        if ($idEdit) {
            $stmt = $pdo->prepare("UPDATE logbook SET tanggal=?, kegiatan=?, hasil=?, kendala=?
                                   WHERE id=? AND user_id=?");
            $stmt->execute([$tanggal, $kegiatan, $hasil ?: null, $kendala ?: null, $idEdit, $user['id']]);
            redirect('/mahasiswa/logbook.php?tersimpan=1');
        }
        $stmt = $pdo->prepare("INSERT INTO logbook (user_id, tanggal, kegiatan, hasil, kendala)
                               VALUES (?,?,?,?,?)");
        $stmt->execute([$user['id'], $tanggal, $kegiatan, $hasil ?: null, $kendala ?: null]);
        redirect('/mahasiswa/logbook.php?ditambahkan=1');
    }
}

// ---- Hapus ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus'])) {
    verifikasiCsrf();
    // Hanya catatan hari ini yang boleh dihapus (hari sebelumnya terkunci).
    $stmt = $pdo->prepare("DELETE FROM logbook WHERE id = ? AND user_id = ? AND tanggal = ?");
    $stmt->execute([(int) $_POST['hapus'], $user['id'], $hariIni]);
    redirect('/mahasiswa/logbook.php?dihapus=' . ($stmt->rowCount() > 0 ? '1' : '0'));
}

if (isset($_GET['ditambahkan'])) $success = 'Catatan kegiatan berhasil ditambahkan ke log book.';
if (isset($_GET['tersimpan'])) $success = 'Perubahan catatan kegiatan berhasil disimpan.';
if (($_GET['dihapus'] ?? '') === '1') $success = 'Catatan kegiatan berhasil dihapus.';
if (($_GET['dihapus'] ?? '') === '0') $error = 'Catatan tidak bisa dihapus. Catatan hari-hari sebelumnya sudah terkunci.';

// ---- Data yang sedang diedit ----
$editData = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM logbook WHERE id = ? AND user_id = ? AND tanggal = ?");
    $stmt->execute([(int) $_GET['edit'], $user['id'], $hariIni]);
    $editData = $stmt->fetch() ?: null;
}

// Nilai form: input terakhir kalau gagal, data yang diedit, atau nilai awal.
$gagalSubmit = $error !== '' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan']);
$jam5 = fn($j) => $j ? substr($j, 0, 5) : '';
if ($gagalSubmit) {
    $form = [
        'id' => (int) ($_POST['id'] ?? 0),
        'tanggal' => $_POST['tanggal'] ?? '',
        'kegiatan' => $_POST['kegiatan'] ?? '',
        'hasil' => $_POST['hasil'] ?? '',
        'kendala' => $_POST['kendala'] ?? '',
    ];
} elseif ($editData) {
    $form = $editData;
} else {
    $form = ['id' => 0, 'tanggal' => $hariIni, 'kegiatan' => '', 'hasil' => '', 'kendala' => ''];
}

// ---- Filter bulan (default: bulan berjalan) ----
// Pilihan bulan dibaca lewat bulanDipilih(), yang mengenali dua bentuk:
//  - bentuk baru dari dropdown Tahun+Bulan : ?tahun=2026&bln=9
//  - bentuk lama (tautan/bookmark)         : ?bulan=2026-09
// Sebelumnya halaman ini hanya membaca bentuk lama, sehingga memilih bulan di
// dropdown tidak berpengaruh dan tampilan selalu kembali ke bulan berjalan.
$bulanPilihan = bulanDipilih();
$awalBulan = $bulanPilihan . '-01';
$akhirBulan = date('Y-m-t', strtotime($awalBulan));

$stmtList = $pdo->prepare("SELECT * FROM logbook WHERE user_id = ? AND tanggal BETWEEN ? AND ?
                           ORDER BY tanggal DESC, id ASC");
$stmtList->execute([$user['id'], $awalBulan, $akhirBulan]);
$perTanggal = kelompokkanLogbook($stmtList->fetchAll());

$jumlahHariTerisi = count($perTanggal);

// Status tiap tanggal (diisi / tidak diisi / izin / sakit / tidak hadir / libur),
// dihitung otomatis dari absensi + izin + hari libur + isi log book.
$statusBulan = statusLogbookRentang($user['id'], $awalBulan, $akhirBulan, $dataUser);
$rekapBulan = rekapStatusLogbook($statusBulan);

// Pilihan bulan: dari bulan mulai magang sampai bulan ini
// (memakai fungsi bersama, sama seperti halaman Riwayat, Izin & Absen Manual).
$daftarTahun = daftarTahunPilihan(
    $dataUser['tanggal_mulai'] ? date('Y', strtotime($dataUser['tanggal_mulai'])) : date('Y'),
    substr($bulanPilihan, 0, 4)
);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Log Book — Absensi Magang</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_mahasiswa.php'; ?>
<div class="container pb-5">
  <h1 class="h5 fw-bold mb-3">Log Book Kegiatan</h1>

  <div class="alert alert-info small">
    📓 Satu baris untuk satu kegiatan. Hanya bisa diisi untuk <b>hari ini</b> setelah <b>absen masuk</b>,
    dan terkunci setelah hari berganti.
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <p class="text-primary fw-semibold small mb-1"><?= $form['id'] ? 'Ubah catatan' : 'Tambah catatan' ?></p>
      <h2 class="h6 fw-bold mb-3"><?= $form['id'] ? 'Edit Kegiatan' : 'Kegiatan Baru' ?> — <?= e(formatTanggalID($hariIni)) ?></h2>

      <?php if (!$bolehIsi): ?>
        <div class="alert alert-warning small mb-0">
          🔒 <?= e($alasanTerkunci) ?>
          <?php if (!sudahAbsenMasuk($user['id'], $hariIni)): ?>
            <div class="mt-2"><a href="<?= BASE_URL ?>/mahasiswa/absen.php" class="btn btn-warning btn-sm">Absen sekarang</a></div>
          <?php endif; ?>
        </div>
      <?php else: ?>
      <form method="POST">
        <?= csrfField() ?>
        <input type="hidden" name="id" value="<?= (int) $form['id'] ?>">
        <div class="row g-2">
          <div class="col-12">
            <label class="form-label small">Tanggal</label>
            <input type="text" class="form-control" value="<?= e(formatTanggalID($hariIni)) ?>" readonly>
            <p class="text-muted small mt-1 mb-0">Log book hanya untuk hari ini.</p>
          </div>
        </div>

        <div class="mb-3 mt-2">
          <label class="form-label small">Uraian kegiatan</label>
          <textarea name="kegiatan" rows="3" maxlength="2000" required class="form-control"
                    placeholder="Contoh: Membantu input data peserta BPJS ke aplikasi internal"><?= e($form['kegiatan']) ?></textarea>
        </div>
        <div class="row g-2">
          <div class="col-12 col-md-6">
            <label class="form-label small">Hasil/output <span class="text-muted">(opsional)</span></label>
            <input type="text" name="hasil" maxlength="255" class="form-control" value="<?= e($form['hasil']) ?>"
                   placeholder="Contoh: 120 data terinput">
          </div>
          <div class="col-12 col-md-6">
            <label class="form-label small">Kendala <span class="text-muted">(opsional)</span></label>
            <input type="text" name="kendala" maxlength="255" class="form-control" value="<?= e($form['kendala']) ?>"
                   placeholder="Contoh: Aplikasi sempat lambat">
          </div>
        </div>

        <?php if ($error): ?><div class="alert alert-danger py-2 small mt-3 mb-0"><?= e($error) ?></div><?php endif; ?>

        <div class="d-flex gap-2 mt-3">
          <button type="submit" name="simpan" value="1" class="btn btn-primary"><?= $form['id'] ? 'Simpan Perubahan' : 'Tambah Catatan' ?></button>
          <?php if ($form['id']): ?><a href="logbook.php" class="btn btn-secondary">Batal</a><?php endif; ?>
        </div>
      </form>
      <?php endif; ?>
      <div class="mt-3">
        <a href="export_logbook.php?bulan=<?= e($bulanPilihan) ?>" target="_blank" rel="noopener" class="btn btn-outline-secondary btn-sm">🖨️ Unduh PDF bulan ini</a>
        <a href="export_logbook_excel.php?bulan=<?= e($bulanPilihan) ?>" class="btn btn-outline-success btn-sm">📊 Unduh Excel bulan ini</a>
      </div>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <form method="GET" class="row g-2 align-items-end mb-3">
        <div class="col-12 col-md-6">
          <?= dropdownBulan($daftarTahun, $bulanPilihan) ?>
        </div>
        <div class="col-4 col-md-3"><noscript><button class="btn btn-secondary btn-sm">Tampilkan</button></noscript></div>
      </form>

      <p class="small mb-3">
        <span class="badge text-bg-success"><?= (int) $rekapBulan['diisi'] ?> hari diisi</span>
        <span class="badge text-bg-danger"><?= (int) $rekapBulan['tidak_diisi'] ?> hari tidak diisi</span>
        <?php if ($rekapBulan['izin'] + $rekapBulan['sakit'] > 0): ?>
          <span class="badge text-bg-primary"><?= (int) ($rekapBulan['izin'] + $rekapBulan['sakit']) ?> hari izin/sakit</span>
        <?php endif; ?>
        <?php if ($rekapBulan['tidak_hadir'] > 0): ?>
          <span class="badge text-bg-secondary"><?= (int) $rekapBulan['tidak_hadir'] ?> hari tidak hadir</span>
        <?php endif; ?>
      </p>

      <?php
        // Daftar hari yang terlewat (hadir tapi tidak mencatat) — sekadar informasi,
        // karena hari-hari itu sudah tidak bisa diisi lagi.
        $hariTerlewat = array_keys(array_filter($statusBulan, fn($d) => $d['status'] === 'tidak_diisi'));
      ?>
      <?php if ($hariTerlewat): ?>
        <div class="alert alert-warning small">
          ⚠️ Kamu hadir tapi tidak mengisi log book pada:
          <?= e(implode(', ', array_map('formatTanggalID', array_slice($hariTerlewat, 0, 8)))) ?><?= count($hariTerlewat) > 8 ? ', dan ' . (count($hariTerlewat) - 8) . ' hari lainnya' : '' ?>.

        </div>
      <?php endif; ?>

      <?php if (!$perTanggal): ?>
        <div class="text-muted small text-center py-3">Belum ada catatan kegiatan di bulan ini.</div>
      <?php else: ?>
      <!-- Daftar dibatasi tingginya & bisa digulir (sama seperti daftar di Kelola Mahasiswa),
           supaya catatan yang panjang tidak membuat halaman memanjang ke bawah. -->
      <div class="daftar-logbook" style="max-height:520px;overflow-y:auto;padding-right:4px;">
      <?php foreach ($perTanggal as $tgl => $grup): ?>
        <div class="mb-3">
          <div class="d-flex justify-content-between align-items-center border-bottom pb-1 mb-2 bg-white"
               style="position:sticky;top:0;z-index:1;">
            <b class="small"><?= e(formatTanggalID($tgl)) ?></b>
            <span class="text-muted small"><?= count($grup['items']) ?> kegiatan</span>
          </div>
          <?php foreach ($grup['items'] as $it): ?>
            <div class="mb-2">
              <div class="small" style="white-space:pre-line;overflow-wrap:anywhere;"><?= e($it['kegiatan']) ?></div>
              <?php if ($it['hasil']): ?><div class="small text-muted" style="overflow-wrap:anywhere;">Hasil: <?= e($it['hasil']) ?></div><?php endif; ?>
              <?php if ($it['kendala']): ?><div class="small text-muted" style="overflow-wrap:anywhere;">Kendala: <?= e($it['kendala']) ?></div><?php endif; ?>
              <?php if (bolehUbahLogbook($it['tanggal'], $hariIni)): ?>
                <div class="d-flex gap-2 mt-1">
                  <a href="logbook.php?edit=<?= $it['id'] ?>&bulan=<?= e($bulanPilihan) ?>" class="btn btn-outline-primary btn-sm">✏️ Edit</a>
                  <form method="POST" class="m-0" data-konfirmasi="Hapus catatan kegiatan ini?" data-konfirmasi-judul="Hapus catatan" data-konfirmasi-ya="Ya, hapus" data-konfirmasi-bahaya="1">
                    <?= csrfField() ?>
                    <input type="hidden" name="hapus" value="<?= $it['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                  </form>
                </div>
              <?php else: ?>
                <div class="text-muted small mt-1">🔒 Terkunci (catatan hari sebelumnya)</div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/foot.php'; ?>
</body>
</html>
