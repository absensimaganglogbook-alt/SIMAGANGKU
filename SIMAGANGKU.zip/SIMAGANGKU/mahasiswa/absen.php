<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin('mahasiswa');

$user = currentUser();

// Pemberitahuan setelah mahasiswa mengganti kata sandinya sendiri di halaman Profil.
$success = isset($_GET['sandi_diganti'])
    ? 'Kata sandi berhasil diganti. Menu ganti kata sandi sekarang terkunci — hubungi admin kalau perlu ganti lagi.'
    : '';
$pengaturan = ambilPengaturan();
$cabang = ambilCabangMahasiswa($user['id']);
$cabangDiatur = $cabang && cabangSudahDiatur($cabang);
$today = date('Y-m-d');

// Cek apakah tanggal mulai magang mahasiswa ini masih di masa depan — kalau iya,
// absen dikunci dulu sampai tanggalnya tiba (walau akunnya sudah dibuat/aktif).
$stmtMulai = getDB()->prepare("SELECT tanggal_mulai FROM users WHERE id=?");
$stmtMulai->execute([$user['id']]);
$tanggalMulaiUser = $stmtMulai->fetchColumn();
$belumMulai = magangBelumMulai($tanggalMulaiUser);
$hariKe = (int) date('N'); // 1=Senin ... 6=Sabtu, 7=Minggu
$cekLibur = cekHariLibur($today);
$isLibur = $cekLibur['libur'];
$namaHari = namaHariID($hariKe);

// Cek status absen hari ini
$stmt = getDB()->prepare("SELECT jenis, waktu, status, terlambat, wfa FROM absensi WHERE user_id=? AND tanggal=?");
$stmt->execute([$user['id'], $today]);
$absenHariIni = ['masuk' => null, 'pulang' => null];
foreach ($stmt->fetchAll() as $row) {
    $absenHariIni[$row['jenis']] = $row;
}

// Cek apakah sedang izin/sakit yang disetujui, mencakup hari ini
$stmt = getDB()->prepare("SELECT * FROM izin WHERE user_id=? AND status='approved' AND ? BETWEEN tanggal_mulai AND tanggal_selesai LIMIT 1");
$stmt->execute([$user['id'], $today]);
$izinAktif = $stmt->fetch();

$sudahMasuk = $absenHariIni['masuk'] && $absenHariIni['masuk']['status'] === 'valid';

// Pengingat log book: muncul kalau hari ini sudah absen masuk (valid) tapi catatan
// kegiatan hari ini masih kosong, supaya log book tidak menumpuk di akhir magang.
$perluIsiLogbook = $sudahMasuk && !sudahIsiLogbook($user['id'], $today);
$sudahPulang = $absenHariIni['pulang'] && $absenHariIni['pulang']['status'] === 'valid';

// Kalau sudah absen masuk hari ini, mode kerja untuk absen pulang WAJIB sama dengan
// mode yang dipakai saat absen masuk (WFO tetap WFO, WFA tetap WFA) — tidak boleh beda.
$modeTerkunci = $sudahMasuk ? (((int)($absenHariIni['masuk']['wfa'] ?? 0) === 1) ? 'wfa' : 'wfo') : null;

$jamSekarang = date('H:i:s');
$masukSudahDibuka = $cabangDiatur && $jamSekarang >= $cabang['jam_masuk'];
// Absen masuk ditutup setelah jam pulang cabang — lewat itu hari ini tercatat tidak hadir.
$masukSudahDitutup = $cabangDiatur && absenMasukSudahDitutup($cabang, $today, $jamSekarang);
$pulangSudahDibuka = $cabangDiatur && $jamSekarang >= $cabang['jam_pulang'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Absen — Absensi Magang</title>
<?php include __DIR__ . '/../includes/head.php'; ?>
</head>
<body>
<?php include __DIR__ . '/../includes/nav_mahasiswa.php'; ?>
<div class="container pb-5">

    <?php if (!$cabang): ?>
      <div class="alert alert-warning d-flex align-items-start gap-2">
        <span class="ico">⚠️</span>
        <div><b>Akun kamu belum diatur ke cabang manapun</b><span>Hubungi admin/pembimbing untuk mengatur cabang tempat magangmu dulu sebelum bisa absen.</span></div>
      </div>
    <?php elseif (!$cabangDiatur): ?>
      <div class="alert alert-warning d-flex align-items-start gap-2">
        <span class="ico">⚠️</span>
        <div><b>Jam kerja cabang kamu belum diatur admin</b><span>Cabang <?= e($cabang['nama_cabang']) ?> belum diatur jam kerjanya. Hubungi admin untuk mengaturnya dulu sebelum kamu bisa absen.</span></div>
      </div>
    <?php elseif ($isLibur): ?>
      <div class="alert alert-secondary d-flex align-items-start gap-2">
        <span class="ico">🛌</span>
        <div><b>Hari ini libur (<?= e($cekLibur['keterangan'] ?? $namaHari) ?>)</b><span>Absen tidak dibuka hari ini. Selamat beristirahat!</span></div>
      </div>
    <?php endif; ?>

    <?php if ($belumMulai): ?>
      <div class="alert alert-warning d-flex align-items-start gap-2">
        <span class="ico">📅</span>
        <div><b>Masa magang kamu belum mulai</b><span>Absen baru dibuka mulai tanggal <?= e(formatTanggalID($tanggalMulaiUser)) ?>.</span></div>
      </div>
    <?php elseif ($izinAktif): ?>
      <div class="alert alert-success d-flex align-items-start gap-2">
        <span class="ico">✅</span>
        <div>
          <b>Kamu sedang <?= $izinAktif['jenis']==='sakit' ? 'sakit' : 'izin' ?></b>
          <span><?= e(formatRentangTanggal($izinAktif['tanggal_mulai'], $izinAktif['tanggal_selesai'])) ?> — absen dikunci untuk hari ini.</span>
        </div>
      </div>
    <?php elseif ($cabangDiatur && !$isLibur && !$sudahMasuk && $jamSekarang > $cabang['batas_terlambat']): ?>
      <div class="alert alert-warning d-flex align-items-start gap-2">
        <span class="ico">🔔</span>
        <div><b>Kamu belum absen masuk</b><span>Sudah lewat jam <?= substr($cabang['batas_terlambat'],0,5) ?>, absen masuk sekarang akan tercatat terlambat.</span></div>
      </div>
    <?php endif; ?>

    <div class="card mb-3 p-3" id="stepIntro">
      <p class="text-primary fw-semibold small mb-1">Absen hari ini · <?= $namaHari ?></p>
      <h2 class="h6 fw-bold mb-2">Halo 👋 <?= e($user['nama']) ?></h2>
      <p class="text-muted small" style="margin-top:6px;">Lokasi magang: <b><?= e($pengaturan['nama_instansi']) ?> — <?= $cabang ? e($cabang['nama_cabang']) . ' · ' . e($cabang['alamat']) : 'Cabang belum diatur, hubungi admin' ?></b></p>
      <div style="margin-top:14px;">
        <span class="badge text-bg-secondary"><span id="clockText">--:--</span></span>
      </div>
      <?php if ($cabangDiatur && !$isLibur && !$belumMulai && !$izinAktif && !$sudahMasuk): ?>
        <?php if ($masukSudahDitutup): ?>
          <div class="alert alert-danger small mt-3 mb-0">
            ⛔ Absen masuk hari ini sudah ditutup (batas jam <?= substr($cabang['jam_pulang'],0,5) ?>),
            jadi hari ini tercatat <b>tidak hadir</b>. Kalau kamu sebenarnya hadir, hubungi admin/pembimbing
            untuk mengisikannya lewat Absen Manual.
          </div>
        <?php else: ?>
          <div class="alert alert-warning small mt-3 mb-0">
            ⏰ Absen masuk ditutup jam <b><?= substr($cabang['jam_pulang'],0,5) ?></b>. Lewat dari itu,
            hari ini otomatis tercatat tidak hadir.
          </div>
        <?php endif; ?>
      <?php endif; ?>
      <?php if ($perluIsiLogbook): ?>
        <div class="alert alert-warning small mt-3 mb-0 d-flex justify-content-between align-items-center gap-2">
          <span>📓 Log book hari ini belum diisi. Isi hari ini juga, karena besok sudah terkunci.</span>
          <a href="<?= BASE_URL ?>/mahasiswa/logbook.php" class="btn btn-warning btn-sm text-nowrap">Isi sekarang</a>
        </div>
      <?php endif; ?>
      <?php if ($cabangDiatur): ?>
      <p class="text-muted small" style="margin-top:8px;font-size:12px;">
        🟢 Masuk <?= substr($cabang['jam_masuk'],0,5) ?>–<?= substr($cabang['batas_terlambat'],0,5) ?> (lewat itu terlambat) · 🔵 Pulang mulai <?= substr($cabang['jam_pulang'],0,5) ?>
      </p>
      <?php endif; ?>

      <?php if ($cabangDiatur && !$isLibur && !$izinAktif && !$belumMulai): ?>
      <div class="mb-3" style="margin-top:14px;margin-bottom:0;">
        <label class="form-label">Mode kerja hari ini</label>
        <div class="btn-group w-100" role="group" id="modeToggleRow">
          <button type="button" class="btn btn-outline-primary mode-opt <?= $modeTerkunci !== 'wfa' ? 'active' : '' ?>" id="btnModeWfo" onclick="pilihMode('wfo')" <?= ($modeTerkunci === 'wfa') ? 'disabled' : '' ?>>🏢 WFO</button>
          <button type="button" class="btn btn-outline-primary mode-opt <?= $modeTerkunci === 'wfa' ? 'active' : '' ?>" id="btnModeWfa" onclick="pilihMode('wfa')" <?= ($modeTerkunci === 'wfo') ? 'disabled' : '' ?>>🌍 WFA</button>
        </div>
        <p class="text-muted small" style="margin-top:6px;font-size:12px;" id="modeHint">
          <?php if ($modeTerkunci): ?>
            🔒 Absen masuk kamu tadi pakai mode <?= $modeTerkunci === 'wfa' ? 'WFA' : 'WFO' ?>, jadi absen pulang hari ini juga harus <?= $modeTerkunci === 'wfa' ? 'WFA' : 'WFO' ?> (tidak bisa beda).
          <?php else: ?>
            WFO: kamu harus absen dari lokasi kantor cabangmu (lokasi divalidasi). WFA: kamu boleh absen dari mana saja.
          <?php endif; ?>
        </p>
      </div>
      <?php endif; ?>

      <div class="row g-2 mt-1" id="absenBtnRow" style="<?= ($izinAktif || $isLibur || !$cabangDiatur || $belumMulai) ? 'opacity:.45;pointer-events:none;' : '' ?>">
        <div class="col-6">
          <button class="btn btn-primary w-100" id="btnAbsenMasuk" onclick="bukaKamera('masuk')" <?= ($sudahMasuk || !$masukSudahDibuka || $masukSudahDitutup || $isLibur || !$cabangDiatur || $belumMulai) ? 'disabled' : '' ?>>📸 Absen Masuk</button>
          <div class="text-muted text-center small mt-1">
            <?php if ($belumMulai): ?>
              Belum mulai magang
            <?php elseif (!$cabangDiatur): ?>
              Cabang belum siap
            <?php elseif ($isLibur): ?>
              Hari libur
            <?php elseif ($sudahMasuk): ?>
              Masuk <?= substr($absenHariIni['masuk']['waktu'],0,5) ?><?= $absenHariIni['masuk']['terlambat'] ? ' · Terlambat' : '' ?><?= $absenHariIni['masuk']['wfa'] ? ' · WFA' : '' ?>
            <?php elseif ($masukSudahDitutup): ?>
              <span class="text-danger">Ditutup jam <?= substr($cabang['jam_pulang'],0,5) ?></span>
            <?php elseif (!$masukSudahDibuka): ?>
              Dibuka jam <?= substr($cabang['jam_masuk'],0,5) ?>
            <?php else: ?>
              <?= $absenHariIni['masuk'] ? 'Ditolak — ulangi' : 'Belum absen' ?>
            <?php endif; ?>
          </div>
        </div>
        <div class="col-6">
          <button class="btn btn-secondary w-100" id="btnAbsenPulang" onclick="bukaKamera('pulang')" <?= (!$sudahMasuk || $sudahPulang || !$pulangSudahDibuka || $isLibur || !$cabangDiatur || $belumMulai) ? 'disabled' : '' ?>>🏁 Absen Pulang</button>
          <div class="text-muted text-center small mt-1">
            <?php if ($belumMulai): ?>
              Belum mulai magang
            <?php elseif (!$cabangDiatur): ?>
              Cabang belum siap
            <?php elseif ($isLibur): ?>
              Hari libur
            <?php elseif ($sudahPulang): ?>
              Pulang <?= substr($absenHariIni['pulang']['waktu'],0,5) ?>
            <?php elseif (!$sudahMasuk): ?>
              Absen masuk dulu
            <?php elseif (!$pulangSudahDibuka): ?>
              Dibuka jam <?= substr($cabang['jam_pulang'],0,5) ?>
            <?php else: ?>
              <?= $absenHariIni['pulang'] ? 'Ditolak — ulangi' : 'Belum absen' ?>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Kartu kamera, disembunyikan sampai tombol absen ditekan -->
    <div class="card mb-3 p-3" id="cardKamera" style="display:none;">
      <p class="text-primary fw-semibold small mb-1" id="kameraLabel">Absen Masuk</p>
      <p class="text-muted small" style="margin-top:-8px;margin-bottom:10px;font-size:12px;" id="kameraModeLabel">Mode: <?= $modeTerkunci === 'wfa' ? 'WFA' : 'WFO' ?></p>
      <div class="cam-wrap" id="camWrap">
        <video id="video" autoplay playsinline></video>
        <div class="cam-frame-corner c-tl"></div>
        <div class="cam-frame-corner c-tr"></div>
        <div class="cam-frame-corner c-bl"></div>
        <div class="cam-frame-corner c-br"></div>
      </div>
      <canvas id="canvas" style="display:none;"></canvas>

      <div class="d-flex justify-content-end" style="margin-top:8px;">
        <button type="button" class="btn btn-outline-secondary btn-sm" id="btnCermin" onclick="ubahCermin()">
          🔄 Balik cermin
        </button>
      </div>
      <p class="text-muted" style="font-size:11px;margin:6px 0 0;" id="ketCermin"></p>

      <div class="d-flex justify-content-between small border-bottom py-2"><span class="text-muted">Lokasi</span><span id="geoStatus" class="fw-medium">Mencari lokasi…</span></div>
      <div class="d-flex justify-content-between small py-2"><span class="text-muted">Perkiraan jarak</span><span id="geoJarak" class="fw-medium">-</span></div>

      <div id="camActions" style="margin-top:14px;display:flex;flex-direction:column;gap:10px;">
        <button class="btn btn-primary" id="btnJepret" onclick="jepretFoto()" disabled>📷 Ambil Foto</button>
        <button class="btn btn-secondary" onclick="tutupKamera()">Batal</button>
      </div>

      <div id="konfirmasiActions" style="margin-top:14px;display:none;flex-direction:column;gap:10px;">
        <button class="btn btn-primary" id="btnKirim" onclick="kirimAbsen()">✅ Kirim Absen</button>
        <button class="btn btn-secondary" onclick="ulangiFoto()">Ambil ulang</button>
      </div>

      <p class="alert alert-danger py-2 small" id="absenError" style="display:none;margin-top:10px;"></p>
    </div>

</div>

<?php include __DIR__ . '/../includes/foot.php'; ?>
<script>
const OFFICE = { lat: <?= $cabang ? $cabang['lat'] : 0 ?>, lng: <?= $cabang ? $cabang['lng'] : 0 ?> };
const RADIUS = <?= $cabang ? (int)$cabang['radius_meter'] : 0 ?>;
const BASE_URL = '<?= BASE_URL ?>';
// Token CSRF ikut dikirim bersama data absen; diperiksa oleh absen_proses.php.
const CSRF_TOKEN = <?= jsonUntukScript(csrfToken()) ?>;

let stream = null;
let currentJenis = 'masuk';
let currentPos = null;
let snapshotDataUrl = null;
const MODE_TERKUNCI = <?= $modeTerkunci ? "'{$modeTerkunci}'" : 'null' ?>; // null = bebas pilih (belum absen masuk hari ini)
let modeAbsen = MODE_TERKUNCI || 'wfo'; // 'wfo' atau 'wfa', dipilih mahasiswa sebelum absen

function pilihMode(mode){
  // Kalau mode sudah terkunci (sudah absen masuk hari ini), tidak boleh diganti lewat cara apapun —
  // jaga-jaga selain tombolnya yang sudah disabled di server.
  if (MODE_TERKUNCI && mode !== MODE_TERKUNCI) return;
  modeAbsen = mode;
  document.getElementById('btnModeWfo').classList.toggle('active', mode === 'wfo');
  document.getElementById('btnModeWfa').classList.toggle('active', mode === 'wfa');
  document.getElementById('modeHint').textContent = mode === 'wfo'
    ? 'WFO: kamu harus absen dari lokasi kantor cabangmu (lokasi divalidasi).'
    : 'WFA (Work From Anywhere): kamu boleh absen dari mana saja, validasi lokasi kantor dilewati.';
  const labelKamera = document.getElementById('kameraModeLabel');
  if (labelKamera) labelKamera.textContent = 'Mode: ' + (mode === 'wfo' ? 'WFO' : 'WFA');
  // Kalau kartu kamera sedang terbuka dan lokasi sudah didapat, perbarui tampilan status lokasi.
  if (currentPos) tampilkanStatusLokasi();
}

function tick(){
  const now = new Date();
  document.getElementById('clockText').textContent =
    String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
}
setInterval(tick, 1000); tick();

function haversine(lat1,lng1,lat2,lng2){
  const R = 6371000, toRad = d => d*Math.PI/180;
  const dLat = toRad(lat2-lat1), dLng = toRad(lng2-lng1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLng/2)**2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)));
}

async function bukaKamera(jenis){
  currentJenis = jenis;
  document.getElementById('kameraLabel').textContent = jenis === 'masuk' ? 'Absen Masuk' : 'Absen Pulang';
  document.getElementById('cardKamera').style.display = 'block';
  document.getElementById('cardKamera').scrollIntoView({ behavior: 'smooth', block: 'start' });
  document.getElementById('camActions').style.display = 'flex';
  document.getElementById('konfirmasiActions').style.display = 'none';
  document.getElementById('absenError').style.display = 'none';
  document.getElementById('btnJepret').disabled = true;
  document.getElementById('geoStatus').textContent = 'Mencari lokasi…';
  document.getElementById('geoJarak').textContent = '-';
  snapshotDataUrl = null;
  currentPos = null;

  const camWrap = document.getElementById('camWrap');
  camWrap.innerHTML = `<video id="video" autoplay playsinline></video>
    <div class="cam-frame-corner c-tl"></div><div class="cam-frame-corner c-tr"></div>
    <div class="cam-frame-corner c-bl"></div><div class="cam-frame-corner c-br"></div>`;

  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
    document.getElementById('video').srcObject = stream;
    terapkanCermin();
  } catch(e) {
    tampilkanError('Tidak bisa mengakses kamera. Pastikan izin kamera diaktifkan.');
  }

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(pos => {
      currentPos = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      tampilkanStatusLokasi();
      document.getElementById('btnJepret').disabled = false;
    }, err => {
      document.getElementById('geoStatus').textContent = 'Gagal mengambil lokasi';
      tampilkanError('Tidak bisa mengambil lokasi GPS. Aktifkan izin lokasi lalu coba lagi.');
    }, { enableHighAccuracy: true, timeout: 10000 });
  } else {
    tampilkanError('Browser ini tidak mendukung geolokasi.');
  }
}

function tampilkanStatusLokasi(){
  if (!currentPos) return;
  const jarak = haversine(currentPos.lat, currentPos.lng, OFFICE.lat, OFFICE.lng);
  if (modeAbsen === 'wfa') {
    document.getElementById('geoStatus').textContent = 'WFA — lokasi tidak divalidasi';
    document.getElementById('geoJarak').textContent = jarak + ' m (bebas, mode WFA)';
  } else {
    document.getElementById('geoStatus').textContent = jarak <= RADIUS ? 'Dalam jangkauan ✓' : 'Di luar jangkauan';
    document.getElementById('geoJarak').textContent = jarak + ' m (maks ' + RADIUS + ' m)';
  }
}

// Dimensi maksimum foto absen yang disimpan (sisi terpanjang). Foto tetap cukup
// jelas untuk verifikasi wajah, tapi ukuran filenya jauh lebih hemat storage
// dibanding resolusi asli kamera HP yang sekarang umumnya sudah beberapa MP.
const MAX_DIMENSI_FOTO = 800;
const KUALITAS_JPEG = 0.8;

/**
 * Sebagian HP mengirimkan gambar kamera depan dalam keadaan TERCERMIN (seperti
 * berkaca), sebagian lagi tidak. Karena itu pembalikan tidak bisa dipaksakan dari
 * aplikasi — disediakan tombol, dan pilihannya diingat per perangkat lewat
 * localStorage. Pembalikan berlaku untuk pratinjau MAUPUN foto yang disimpan,
 * jadi foto yang tersimpan sama persis dengan yang dilihat mahasiswa.
 */
let cerminAktif = localStorage.getItem('absen_cermin') === '1';

function terapkanCermin(){
  const v = document.getElementById('video');
  if (v) v.style.transform = cerminAktif ? 'scaleX(-1)' : 'none';
  const ket = document.getElementById('ketCermin');
  if (ket) ket.textContent = cerminAktif
    ? 'Tampilan kamera dibalik. Tekan tombol di atas kalau tulisan malah terbaca terbalik.'
    : 'Kalau tampilan kamera terlihat seperti cermin (tulisan terbalik), tekan tombol di atas.';
}

function ubahCermin(){
  cerminAktif = !cerminAktif;
  localStorage.setItem('absen_cermin', cerminAktif ? '1' : '0');
  terapkanCermin();
}

function jepretFoto(){
  const video = document.getElementById('video');
  const canvas = document.getElementById('canvas');

  // Hitung ukuran akhir: skala turun kalau sisi terpanjang video melebihi MAX_DIMENSI_FOTO,
  // aspect ratio asli tetap dipertahankan. Kalau video sudah lebih kecil, tidak diperbesar.
  const sisiTerpanjang = Math.max(video.videoWidth, video.videoHeight);
  const skala = sisiTerpanjang > MAX_DIMENSI_FOTO ? MAX_DIMENSI_FOTO / sisiTerpanjang : 1;
  canvas.width = Math.round(video.videoWidth * skala);
  canvas.height = Math.round(video.videoHeight * skala);
  const ctx = canvas.getContext('2d');
  if (cerminAktif) {          // foto disimpan sama seperti yang terlihat di layar
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  snapshotDataUrl = canvas.toDataURL('image/jpeg', KUALITAS_JPEG);

  const camWrap = document.getElementById('camWrap');
  camWrap.innerHTML = `<img class="snapshot" src="${snapshotDataUrl}">`;
  if (stream) stream.getTracks().forEach(t => t.stop());

  document.getElementById('camActions').style.display = 'none';
  document.getElementById('konfirmasiActions').style.display = 'flex';
}

function ulangiFoto(){
  bukaKamera(currentJenis);
}

function tutupKamera(){
  if (stream) stream.getTracks().forEach(t => t.stop());
  document.getElementById('cardKamera').style.display = 'none';
}

function tampilkanError(msg){
  const el = document.getElementById('absenError');
  el.textContent = msg;
  el.style.display = 'block';
  if (window.Dialog) Dialog.error(msg, 'Absen gagal');
}

async function kirimAbsen(){
  if (!snapshotDataUrl || !currentPos){
    tampilkanError('Foto atau lokasi belum lengkap.');
    return;
  }
  const btn = document.getElementById('btnKirim');
  btn.disabled = true; btn.textContent = 'Mengirim…';

  try {
    const res = await fetch(BASE_URL + '/mahasiswa/absen_proses.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        csrf_token: CSRF_TOKEN, jenis: currentJenis, foto: snapshotDataUrl, lat: currentPos.lat, lng: currentPos.lng, mode: modeAbsen })
    });
    // Bedakan "server membalas tapi isinya bukan data" dari "jaringan benar-benar putus",
    // supaya pesan ke mahasiswa tidak menyesatkan.
    let data;
    try {
      data = await res.json();
    } catch (galatBaca) {
      btn.disabled = false; btn.textContent = '✅ Kirim Absen';
      tampilkanError('Server sedang bermasalah (kode ' + res.status + '), absen belum tersimpan. Coba lagi sebentar; kalau tetap gagal, hubungi admin.');
      return;
    }
    if (data.ok) {
      // Tampilkan popup berhasil dulu; halaman dimuat ulang setelah popup ditutup.
      if (window.Dialog) await Dialog.sukses(data.message || 'Absen berhasil dicatat.', 'Berhasil!');
      window.location.reload();
      return;
    } else {
      btn.disabled = false; btn.textContent = '✅ Kirim Absen';
      tampilkanError(data.message || 'Gagal mengirim absen.');
    }
  } catch(e) {
    btn.disabled = false; btn.textContent = '✅ Kirim Absen';
    tampilkanError(navigator.onLine === false
      ? 'Tidak ada koneksi internet. Periksa jaringanmu, lalu coba lagi.'
      : 'Gagal terhubung ke server. Periksa koneksi internet, lalu coba lagi.');
  }
}
</script>
</body>
</html>
