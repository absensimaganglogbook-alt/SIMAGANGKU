<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<?php
// Popup pemberitahuan hasil aksi (berhasil/gagal) + konfirmasi, tampil di tengah layar.
// Diletakkan di sini supaya otomatis aktif di SEMUA halaman yang memuat foot.php.
include __DIR__ . '/dialog.php';
?>

<style>
/* Sembunyikan ikon mata BAWAAN browser Microsoft Edge (dan IE) pada kolom kata sandi,
   supaya tidak muncul dua tombol sekaligus — aplikasi sudah memasang tombol "lihat
   kata sandi" sendiri yang berfungsi sama di semua browser. */
/* Sengaja dipisah per aturan: kalau satu selektor tidak dikenal browser, hanya
   aturan itu yang diabaikan, bukan keduanya. */
input[type="password"]::-ms-reveal { display: none; }
input[type="password"]::-ms-clear { display: none; }
</style>

<script>
/**
 * Tombol "lihat kata sandi" (ikon mata) — dipasang OTOMATIS ke setiap kolom
 * kata sandi di seluruh aplikasi (login, ganti kata sandi, buat akun baru),
 * jadi halaman-halaman itu tidak perlu diubah satu per satu.
 */
(function () {
  function pasangTombolLihatSandi(input) {
    if (input.dataset.adaTombolLihat === '1') return;
    input.dataset.adaTombolLihat = '1';

    // Bungkus kolom input supaya tombolnya bisa diletakkan di dalam kolom.
    var pembungkus = document.createElement('div');
    pembungkus.className = 'position-relative';
    input.parentNode.insertBefore(pembungkus, input);
    pembungkus.appendChild(input);
    input.style.paddingRight = '2.75rem';

    var tombol = document.createElement('button');
    tombol.type = 'button'; // penting: jangan ikut mengirim form
    tombol.className = 'btn btn-sm border-0 bg-transparent position-absolute top-50 end-0 translate-middle-y px-2 py-0 text-secondary';
    tombol.style.lineHeight = '1';
    tombol.textContent = '👁';
    tombol.title = 'Lihat kata sandi';
    tombol.setAttribute('aria-label', 'Lihat kata sandi');

    tombol.addEventListener('click', function () {
      var sedangTersembunyi = input.type === 'password';
      input.type = sedangTersembunyi ? 'text' : 'password';
      tombol.textContent = sedangTersembunyi ? '🙈' : '👁';
      tombol.title = sedangTersembunyi ? 'Sembunyikan kata sandi' : 'Lihat kata sandi';
      tombol.setAttribute('aria-label', tombol.title);
      input.focus();
    });

    pembungkus.appendChild(tombol);
  }

  function pasangSemua() {
    document.querySelectorAll('input[type="password"]').forEach(pasangTombolLihatSandi);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', pasangSemua);
  } else {
    pasangSemua();
  }
})();
</script>
