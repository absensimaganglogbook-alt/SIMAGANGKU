<?php
/**
 * Mengambil gabungan data absensi + izin dalam rentang tanggal tertentu,
 * dipakai bareng oleh halaman preview laporan, export Excel, dan export PDF.
 *
 * $pembimbingId: kalau diisi, data dibatasi hanya untuk mahasiswa bimbingan
 * pembimbing tersebut. Halaman yang dibuka pembimbing WAJIB mengisi ini lewat
 * idPembimbingScope() — admin mengirim null (semua mahasiswa).
 */
function ambilDataLaporan($dariTanggal, $sampaiTanggal, $userId = null, $kategoriId = null, $cabangId = null, $pembimbingId = null) {
    $pdo = getDB();

    $sqlAbsen = "
        SELECT u.nama, a.tanggal, a.jenis, a.waktu, a.jarak_meter, a.status, a.terlambat, a.wfa, a.foto,
               a.diisi_admin, a.alasan_manual, a.keterangan AS catatan_manual
        FROM absensi a JOIN users u ON u.id = a.user_id
        WHERE a.tanggal BETWEEN ? AND ?
    ";
    $paramsAbsen = [$dariTanggal, $sampaiTanggal];
    if ($userId) { $sqlAbsen .= " AND a.user_id = ?"; $paramsAbsen[] = $userId; }
    if ($kategoriId) { $sqlAbsen .= " AND u.kategori_id = ?"; $paramsAbsen[] = $kategoriId; }
    if ($cabangId) { $sqlAbsen .= " AND u.cabang_id = ?"; $paramsAbsen[] = $cabangId; }
    if ($pembimbingId) { $sqlAbsen .= " AND u.pembimbing_id = ?"; $paramsAbsen[] = $pembimbingId; }
    $sqlAbsen .= " ORDER BY a.tanggal ASC, a.waktu ASC";

    $stmtAbsen = $pdo->prepare($sqlAbsen);
    $stmtAbsen->execute($paramsAbsen);

    $labelAlasanManual = ['hadir' => 'Hadir', 'sakit' => 'Sakit', 'izin' => 'Izin', 'lainnya' => 'Lainnya'];

    $items = [];
    foreach ($stmtAbsen->fetchAll() as $r) {
        if ($r['diisi_admin']) {
            $statusTampil = 'Diisi Admin';
            $alasan = $labelAlasanManual[$r['alasan_manual']] ?? '-';
            $keteranganTampil = "Diisi admin — $alasan" . ($r['catatan_manual'] ? ' — ' . $r['catatan_manual'] : '');
        } else {
            $statusTampil = $r['status'] === 'valid' ? ($r['terlambat'] ? 'Terlambat' : 'Berhasil') : 'Ditolak';
            $keteranganTampil = $r['wfa'] ? 'WFA (Work From Anywhere)' : '-';
        }
        $items[] = [
            'tanggal_iso' => $r['tanggal'],
            'tanggal_tampil' => formatTanggalID($r['tanggal']),
            'nama' => $r['nama'],
            'jenis' => $r['jenis'] === 'masuk' ? 'Masuk' : 'Pulang',
            'jam' => substr($r['waktu'], 0, 5),
            'jarak' => $r['diisi_admin'] ? '-' : $r['jarak_meter'] . ' m',
            'status' => $statusTampil,
            'keterangan' => $keteranganTampil,
            'foto' => $r['foto'],
        ];
    }

    $sqlIzin = "
        SELECT u.nama, i.tanggal_mulai, i.tanggal_selesai, i.jenis, i.keterangan, i.status, i.file_lampiran
        FROM izin i JOIN users u ON u.id = i.user_id
        WHERE i.tanggal_mulai <= ? AND i.tanggal_selesai >= ?
    ";
    $paramsIzin = [$sampaiTanggal, $dariTanggal];
    if ($userId) { $sqlIzin .= " AND i.user_id = ?"; $paramsIzin[] = $userId; }
    if ($kategoriId) { $sqlIzin .= " AND u.kategori_id = ?"; $paramsIzin[] = $kategoriId; }
    if ($cabangId) { $sqlIzin .= " AND u.cabang_id = ?"; $paramsIzin[] = $cabangId; }
    if ($pembimbingId) { $sqlIzin .= " AND u.pembimbing_id = ?"; $paramsIzin[] = $pembimbingId; }

    $stmtIzin = $pdo->prepare($sqlIzin);
    $stmtIzin->execute($paramsIzin);

    $labelStatusIzin = ['pending' => 'Menunggu', 'approved' => 'Disetujui', 'rejected' => 'Ditolak'];
    foreach ($stmtIzin->fetchAll() as $r) {
        $items[] = [
            'tanggal_iso' => $r['tanggal_mulai'],
            'tanggal_tampil' => formatRentangTanggal($r['tanggal_mulai'], $r['tanggal_selesai']),
            'nama' => $r['nama'],
            'jenis' => $r['jenis'] === 'sakit' ? 'Sakit' : 'Izin',
            'jam' => '-',
            'jarak' => '-',
            'status' => $labelStatusIzin[$r['status']],
            'keterangan' => $r['keterangan'],
            'foto' => $r['file_lampiran'],
        ];
    }

    // ---- "Tidak Hadir": hari kerja yang seharusnya diisi tapi mahasiswa sama sekali tidak absen
    // masuk dan tidak sedang izin/sakit yang disetujui. Cuma dihitung untuk hari yang SUDAH lewat
    // (bukan hari ini yang belum tentu selesai) dan hanya dalam rentang tanggal magangnya masing-masing.
    $sqlMhsCek = "SELECT id, nama, cabang_id, tanggal_mulai, tanggal_selesai, DATE(created_at) AS dibuat_tgl FROM users WHERE role='mahasiswa'";
    $paramsMhsCek = [];
    if ($userId) { $sqlMhsCek .= " AND id = ?"; $paramsMhsCek[] = $userId; }
    if ($kategoriId) { $sqlMhsCek .= " AND kategori_id = ?"; $paramsMhsCek[] = $kategoriId; }
    if ($cabangId) { $sqlMhsCek .= " AND cabang_id = ?"; $paramsMhsCek[] = $cabangId; }
    if ($pembimbingId) { $sqlMhsCek .= " AND pembimbing_id = ?"; $paramsMhsCek[] = $pembimbingId; }
    $stmtMhsCek = $pdo->prepare($sqlMhsCek);
    $stmtMhsCek->execute($paramsMhsCek);
    $daftarMhsCek = $stmtMhsCek->fetchAll();

    // Hari ini ikut dihitung kalau kesempatan absen masuknya sudah lewat (lihat
    // absenMasukSudahDitutup()); kalau belum, batasnya tetap sampai kemarin.
    $kemarin = date('Y-m-d', strtotime('-1 day'));
    $hariIniTgl = date('Y-m-d');
    $batasAkhirCek = min($sampaiTanggal, $hariIniTgl);

    if ($daftarMhsCek && $dariTanggal <= $batasAkhirCek) {
        // Tanggal yang sudah ada absen masuk (apapun statusnya — valid/ditolak/diisi admin — tetap
        // dianggap "sudah mengisi sesuatu", jadi bukan tidak hadir).
        $sqlSudahMasuk = "SELECT user_id, tanggal FROM absensi WHERE jenis='masuk' AND tanggal BETWEEN ? AND ?";
        $stmtSudahMasuk = $pdo->prepare($sqlSudahMasuk);
        $stmtSudahMasuk->execute([$dariTanggal, $batasAkhirCek]);
        $setSudahMasuk = [];
        foreach ($stmtSudahMasuk->fetchAll() as $row) {
            $setSudahMasuk[$row['user_id'] . '|' . $row['tanggal']] = true;
        }

        // Rentang izin/sakit yang disetujui per mahasiswa, dipakai untuk melewati tanggal yang memang izin.
        $sqlIzinApproved = "SELECT user_id, tanggal_mulai, tanggal_selesai FROM izin WHERE status='approved' AND tanggal_mulai <= ? AND tanggal_selesai >= ?";
        $stmtIzinApproved = $pdo->prepare($sqlIzinApproved);
        $stmtIzinApproved->execute([$batasAkhirCek, $dariTanggal]);
        $izinPerUser = [];
        foreach ($stmtIzinApproved->fetchAll() as $row) {
            $izinPerUser[$row['user_id']][] = [$row['tanggal_mulai'], $row['tanggal_selesai']];
        }

        foreach ($daftarMhsCek as $mhs) {
            $mulaiCek = $dariTanggal;
            if ($mhs['tanggal_mulai'] && $mhs['tanggal_mulai'] > $mulaiCek) $mulaiCek = $mhs['tanggal_mulai'];
            // Kalau tanggal_mulai belum diisi admin, jangan hitung "tidak hadir" untuk tanggal
            // sebelum akunnya dibuat — pasti belum bisa absen sebelum akun ada.
            if (!$mhs['tanggal_mulai'] && $mhs['dibuat_tgl'] && $mhs['dibuat_tgl'] > $mulaiCek) $mulaiCek = $mhs['dibuat_tgl'];
            $akhirCek = $batasAkhirCek;
            // Hari ini hanya dihitung untuk mahasiswa yang batas absen masuknya sudah lewat
            // (jam pulang cabangnya masing-masing).
            if ($akhirCek === $hariIniTgl && !absenMasukSudahDitutup($mhs['cabang_id'], $hariIniTgl)) {
                $akhirCek = $kemarin;
            }
            if ($mhs['tanggal_selesai'] && $mhs['tanggal_selesai'] < $akhirCek) $akhirCek = $mhs['tanggal_selesai'];
            if ($mulaiCek > $akhirCek) continue;

            $tgl = $mulaiCek;
            while ($tgl <= $akhirCek) {
                $cekLibur = cekHariLibur($tgl);
                if ($cekLibur['libur']) { $tgl = date('Y-m-d', strtotime($tgl . ' +1 day')); continue; }

                $sudahMasuk = isset($setSudahMasuk[$mhs['id'] . '|' . $tgl]);
                $sedangIzin = false;
                if (!$sudahMasuk && !empty($izinPerUser[$mhs['id']])) {
                    foreach ($izinPerUser[$mhs['id']] as [$mulaiIzin, $selesaiIzin]) {
                        if ($tgl >= $mulaiIzin && $tgl <= $selesaiIzin) { $sedangIzin = true; break; }
                    }
                }

                if (!$sudahMasuk && !$sedangIzin) {
                    $items[] = [
                        'tanggal_iso' => $tgl,
                        'tanggal_tampil' => formatTanggalID($tgl),
                        'nama' => $mhs['nama'],
                        'jenis' => '-',
                        'jam' => '-',
                        'jarak' => '-',
                        'status' => 'Tidak Hadir',
                        'keterangan' => 'Tidak ada absen masuk & tidak sedang izin/sakit yang disetujui',
                        'foto' => null,
                    ];
                }
                $tgl = date('Y-m-d', strtotime($tgl . ' +1 day'));
            }
        }
    }

    usort($items, fn($a, $b) => strcmp($b['tanggal_iso'], $a['tanggal_iso']));
    return $items;
}

/**
 * Ringkasan angka dari hasil ambilDataLaporan(): berapa kali tepat waktu,
 * terlambat, tidak hadir, izin, sakit, dan seterusnya.
 *
 * Dihitung dari baris yang sama persis dengan yang ditampilkan/diexport, jadi
 * angkanya selalu cocok dengan isi tabelnya (termasuk saat difilter per
 * mahasiswa, kategori, cabang, atau rentang tanggal).
 */
function ringkasanLaporan($items) {
    $r = [
        'masuk_tepat' => 0, 'terlambat' => 0, 'pulang' => 0,
        'diisi_admin' => 0,        // baris MASUK yang diisi admin (dipakai menghitung kehadiran)
        'diisi_admin_baris' => 0,  // SEMUA baris diisi admin (masuk + pulang), untuk ditampilkan
        'ditolak' => 0, 'izin' => 0, 'sakit' => 0, 'tidak_hadir' => 0, 'wfa' => 0,
    ];

    foreach ($items as $it) {
        $jenis = $it['jenis'];
        $status = $it['status'];

        if ($status === 'Tidak Hadir')      { $r['tidak_hadir']++; continue; }
        if ($jenis === 'Izin')              { if ($status === 'Disetujui') $r['izin']++;  continue; }
        if ($jenis === 'Sakit')             { if ($status === 'Disetujui') $r['sakit']++; continue; }

        if (strpos($it['keterangan'], 'WFA') !== false) $r['wfa']++;

        if ($status === 'Ditolak') { $r['ditolak']++; continue; }

        // Catatan: baris "Diisi Admin" bisa berjenis Masuk MAUPUN Pulang.
        // Dulu baris Pulang yang diisi admin tidak terhitung di mana pun,
        // sehingga angka "Absen pulang" lebih kecil dari kenyataan.
        if ($status === 'Diisi Admin') $r['diisi_admin_baris']++;

        if ($jenis === 'Masuk') {
            if ($status === 'Diisi Admin')       $r['diisi_admin']++;
            elseif ($status === 'Terlambat')     $r['terlambat']++;
            else                                 $r['masuk_tepat']++;
            continue;
        }
        if ($jenis === 'Pulang') { $r['pulang']++; }
    }

    $r['total_hadir'] = $r['masuk_tepat'] + $r['terlambat'] + $r['diisi_admin'];
    return $r;
}

/** Label & warna tiap angka ringkasan, dipakai halaman Laporan & export. */
function daftarRingkasanLaporan($r) {
    return [
        ['Hadir (absen masuk)', $r['total_hadir'], 'success'],
        ['Tepat waktu',         $r['masuk_tepat'], 'success'],
        ['Terlambat',           $r['terlambat'],   'warning'],
        ['Tidak hadir',         $r['tidak_hadir'], 'danger'],
        ['Izin',                $r['izin'],        'primary'],
        ['Sakit',               $r['sakit'],       'primary'],
        ['Diisi admin',         $r['diisi_admin_baris'], 'secondary'],
        ['Absen pulang',        $r['pulang'],      'secondary'],
        ['WFA',                 $r['wfa'],         'info'],
        ['Absen ditolak',       $r['ditolak'],     'dark'],
    ];
}

/**
 * Kelas pill (dipakai di Pratinjau, tema navy/gold) untuk 1 baris data laporan.
 * Warna ditentukan dari jenis (Izin/Sakit) dulu, baru dari status kalau bukan izin/sakit:
 * - biru   -> jenis Izin
 * - oranye -> jenis Sakit
 * - kuning -> status Terlambat
 * - merah  -> status Tidak Hadir / Ditolak
 * - hijau  -> status Berhasil / Disetujui
 * - abu2   -> status lain (Menunggu, Diisi Admin, dst.)
 */
function warnaLaporan($item) {
    if ($item['jenis'] === 'Izin') return 'izin';
    if ($item['jenis'] === 'Sakit') return 'sakit';
    if ($item['status'] === 'Terlambat') return 'late';
    if (in_array($item['status'], ['Tidak Hadir', 'Ditolak'], true)) return 'bad';
    if (in_array($item['status'], ['Berhasil', 'Disetujui'], true)) return 'ok';
    return 'wait'; // Menunggu, Diisi Admin, dll.
}

/**
 * Versi warna untuk export Excel/PDF (latar putih) — dipakai sebagai warna latar baris
 * supaya laporan yang diekspor gampang dipindai sekilas: kuning=terlambat, merah=tidak
 * hadir/ditolak, biru=izin, oranye=sakit, hijau=hadir/berhasil (termasuk izin yang disetujui
 * tidak kena hijau karena sudah kepakai biru duluan). Status lain (Menunggu, Diisi Admin)
 * dibiarkan tanpa warna khusus.
 */
function warnaLaporanCetak($item) {
    return match (warnaLaporan($item)) {
        'izin' => ['bg' => '#DCEBFF', 'teks' => '#0B4A8F'],
        'sakit' => ['bg' => '#FFE3C2', 'teks' => '#8A4B00'],
        'late' => ['bg' => '#FFF2A8', 'teks' => '#6B5900'],
        'bad' => ['bg' => '#FFD4D9', 'teks' => '#8E1B2C'],
        'ok' => ['bg' => '#D3F5E4', 'teks' => '#0E6B47'],
        default => null, // status lain (Menunggu, Diisi Admin, dll.): tidak diberi warna latar khusus
    };
}
