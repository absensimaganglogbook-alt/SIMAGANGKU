<?php
/**
 * Navbar panel admin & pembimbing (satu file, menu menyesuaikan role).
 * Pembimbing tidak melihat menu Mahasiswa (kelola akun) dan Atur (pengaturan),
 * dan semua link-nya mengarah ke /pembimbing/... bukan /admin/...
 */
$current = basename($_SERVER['PHP_SELF']);
$panel = BASE_URL . panelBase();
$navPembimbing = isPembimbing();
$navSuper = isSuperAdmin();

$menuNav = [
    ['dashboard.php', 'bi-speedometer2', 'Dashboard', true],
    ['mahasiswa.php', 'bi-mortarboard-fill', 'Mahasiswa', !$navPembimbing],
    ['kategori.php', 'bi-tags-fill', 'Kategori', !$navPembimbing],
    ['kelola_pembimbing.php', 'bi-person-badge-fill', 'Pembimbing', !$navPembimbing],
    ['divisi.php', 'bi-diagram-3-fill', 'Divisi', !$navPembimbing],
    ['izin.php', 'bi-file-earmark-text-fill', 'Izin/Sakit', true],
    ['absen_manual.php', 'bi-pencil-square', 'Absen Manual', $navPembimbing],
    ['logbook.php', 'bi-journal-text', 'Log Book', true],
    ['sertifikat.php', 'bi-award-fill', 'Sertifikat', true],
    ['laporan.php', 'bi-download', 'Laporan', true],
    ['log_aktivitas.php', 'bi-clock-history', 'Riwayat', !$navPembimbing],
    ['pengaturan.php', 'bi-gear-fill', 'Atur', !$navPembimbing],
];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= $panel ?>/dashboard.php">
      <i class="bi bi-clipboard2-check-fill me-1"></i> Absensi Magang
      <span class="badge text-bg-<?= $navPembimbing ? 'info' : ($navSuper ? 'danger' : 'warning') ?> ms-1 align-middle" style="font-size:.65rem;"><?= e($navSuper ? 'Super Admin' : labelRole(roleSekarang())) ?></span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navAdmin">
      <ul class="navbar-nav me-auto">
        <?php foreach ($menuNav as [$file, $ikon, $label, $tampil]): if (!$tampil) continue; ?>
        <li class="nav-item">
          <a class="nav-link <?= $current === $file ? 'active' : '' ?>" href="<?= $panel ?>/<?= $file ?>">
            <i class="bi <?= $ikon ?> me-1"></i><?= $label ?>
          </a>
        </li>
        <?php endforeach; ?>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link <?= $current==='profil.php' ? 'active' : '' ?>" href="<?= $panel ?>/profil.php">
            <i class="bi bi-person-circle me-1"></i>Profil
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= BASE_URL ?>/logout.php">
            <i class="bi bi-box-arrow-right me-1"></i>Keluar
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
