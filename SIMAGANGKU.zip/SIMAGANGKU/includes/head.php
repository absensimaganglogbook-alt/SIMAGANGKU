<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
/**
 * Mesin pencari: seluruh halaman DALAM aplikasi (dashboard, absen, laporan, dsb.)
 * sengaja tidak boleh diindeks, karena isinya data pribadi & hanya untuk pengguna
 * yang login. Hanya halaman yang secara khusus menyetel $halamanPublik = true
 * (yaitu halaman login) yang boleh muncul di hasil pencarian.
 */
?>
<?php if (empty($halamanPublik)): ?>
<meta name="robots" content="noindex, nofollow">
<?php else: ?>
<meta name="robots" content="index, follow">
<meta name="description" content="<?= e($deskripsiHalaman ?? 'Aplikasi absensi dan log book kegiatan harian untuk peserta magang: absen dengan foto & lokasi, pengajuan izin, serta laporan siap cetak.') ?>">
<?php endif; ?>
<?php
/**
 * Ikon situs (favicon). Inilah gambar kecil yang tampil di tab browser, di layar
 * utama HP saat halaman disimpan sebagai pintasan, dan di samping alamat situs
 * pada hasil pencarian Google.
 */
?>
<link rel="icon" href="<?= BASE_URL ?>/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="48x48" href="<?= BASE_URL ?>/assets/img/favicon-48.png">
<link rel="icon" type="image/png" sizes="512x512" href="<?= BASE_URL ?>/assets/img/favicon-512.png">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/assets/img/apple-touch-icon.png">
<meta name="theme-color" content="#0E2344">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<!-- Bootstrap 5 (CDN) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<!-- Penyesuaian kecil di luar Bootstrap default (lihat isi file untuk detail) -->
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
