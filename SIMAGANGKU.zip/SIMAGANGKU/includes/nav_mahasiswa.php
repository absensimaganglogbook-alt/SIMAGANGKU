<?php $current = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= BASE_URL ?>/mahasiswa/absen.php">
      <i class="bi bi-clipboard2-check-fill me-1"></i> Absensi Magang
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMhs">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMhs">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link <?= $current==='absen.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/mahasiswa/absen.php">
            <i class="bi bi-camera-fill me-1"></i>Absen
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current==='riwayat.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/mahasiswa/riwayat.php">
            <i class="bi bi-clock-history me-1"></i>Riwayat
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current==='logbook.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/mahasiswa/logbook.php">
            <i class="bi bi-journal-text me-1"></i>Log Book
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current==='izin.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/mahasiswa/izin.php">
            <i class="bi bi-file-earmark-text-fill me-1"></i>Izin/Sakit
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current==='profil.php' ? 'active' : '' ?>" href="<?= BASE_URL ?>/mahasiswa/profil.php">
            <i class="bi bi-person-circle me-1"></i>Profil
          </a>
        </li>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="<?= BASE_URL ?>/logout.php">
            <i class="bi bi-box-arrow-right me-1"></i>Keluar
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
