<?php
/**
 * Session guard. Include file ini di paling atas setiap halaman yang butuh login.
 */

if (session_status() === PHP_SESSION_NONE) {
    // Keraskan pengaturan cookie sesi sebelum session_start():
    // - httponly: cookie sesi tidak bisa dibaca lewat JavaScript (mitigasi XSS/pencurian sesi)
    // - samesite=Lax: cookie tidak ikut terkirim pada request cross-site pihak ketiga,
    //   tapi tetap jalan normal untuk navigasi biasa (klik link, submit form dari halaman sendiri)
    // - secure: hanya dikirim lewat HTTPS — otomatis aktif SENDIRI kalau koneksi memang
    //   HTTPS (baik dideteksi langsung maupun lewat header proxy/load balancer umum),
    //   supaya tetap tidak menghalangi development lokal di XAMPP/Laragon yang masih HTTP.
    $httpsAktif = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['SERVER_PORT'] ?? '') == 443);

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => $httpsAktif,
    ]);
    session_start();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

/**
 * ============================================================
 *  SINKRONISASI SESI DENGAN DATABASE (tiap request)
 * ============================================================
 * Sesi PHP hanya menyimpan salinan data user saat login. Tanpa pengecekan
 * ulang, akun yang sudah DINONAKTIFKAN, DIHAPUS, atau DIGANTI role-nya oleh
 * admin tetap bisa memakai sesinya sampai logout sendiri. Karena itu, di setiap
 * request data akun dibaca ulang dari database:
 * - akun tidak ada / nonaktif / role berubah → sesi langsung dicabut;
 * - nama & flag harus_ganti_password disegarkan (mis. baru direset admin).
 */
/**
 * Batas waktu sesi MENGANGGUR (idle). Kalau tidak ada aktivitas selama sekian menit,
 * sesi otomatis diakhiri — supaya akun tidak tetap terbuka di komputer bersama yang
 * ditinggal pergi. Ubah angkanya kalau instansi ingin lebih longgar/ketat.
 */
const MENIT_SESI_MENGANGGUR = 120;

$GLOBALS['_sesi_dicabut'] = false;
$GLOBALS['_sesi_kedaluwarsa'] = false;

/**
 * Akhiri sesi kalau sudah terlalu lama tidak ada aktivitas, lalu catat waktu
 * aktivitas terakhir untuk permintaan berikutnya.
 */
function cekSesiMenganggur() {
    if (!isset($_SESSION['user_id'])) return;

    $batas = MENIT_SESI_MENGANGGUR * 60;
    $terakhir = $_SESSION['_aktivitas_terakhir'] ?? time();

    if (time() - $terakhir > $batas) {
        $_SESSION = [];
        session_destroy();
        session_start();
        session_regenerate_id(true);
        $GLOBALS['_sesi_kedaluwarsa'] = true;
        return;
    }
    $_SESSION['_aktivitas_terakhir'] = time();
}

function sinkronkanSesiDenganDatabase() {
    if (!isset($_SESSION['user_id'])) return;

    $stmt = getDB()->prepare("SELECT id, role, super_admin, nama, identifier, status, harus_ganti_password FROM users WHERE id = ?");
    $stmt->execute([(int) $_SESSION['user_id']]);
    $u = $stmt->fetch();

    if (!$u || $u['status'] !== 'aktif' || $u['role'] !== ($_SESSION['user_role'] ?? null)) {
        $_SESSION = [];
        session_destroy();
        // Mulai sesi kosong yang baru, supaya halaman yang tetap tampil di request ini
        // (mis. login.php) bisa menyimpan token CSRF baru dengan normal.
        session_start();
        session_regenerate_id(true);
        $GLOBALS['_sesi_dicabut'] = true;
        return;
    }

    // Status super admin selalu diambil ulang dari database, jadi pencabutan
    // kewenangan langsung berlaku tanpa perlu menunggu pengguna login ulang.
    $_SESSION['user_super_admin'] = (int) $u['super_admin'];
    $_SESSION['user_nama'] = $u['nama'];
    $_SESSION['user_identifier'] = $u['identifier'];
    $_SESSION['harus_ganti_password'] = (int) $u['harus_ganti_password'];
}

sinkronkanSesiDenganDatabase();
cekSesiMenganggur();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function currentUser() {
    if (!isLoggedIn()) return null;
    return [
        'id' => $_SESSION['user_id'],
        'nama' => $_SESSION['user_nama'],
        'role' => $_SESSION['user_role'],
        'identifier' => $_SESSION['user_identifier'],
        'super_admin' => (int) ($_SESSION['user_super_admin'] ?? 0),
    ];
}

/**
 * Panggil di awal halaman yang wajib login dengan role tertentu.
 * $role: 'admin', 'pembimbing', 'mahasiswa', array beberapa role
 *        (mis. ['admin', 'pembimbing']), atau null (asal login, role apa saja).
 */
function requireLogin($role = null) {
    if (!isLoggedIn()) {
        $alasan = !empty($GLOBALS['_sesi_kedaluwarsa']) ? '?kedaluwarsa=1'
                : (!empty($GLOBALS['_sesi_dicabut']) ? '?dicabut=1' : '');
        redirect('/login.php' . $alasan);
    }

    $roleUser = $_SESSION['user_role'];

    // Kalau mahasiswa dan masa magangnya sudah lewat, nonaktifkan otomatis & paksa keluar.
    if ($roleUser === 'mahasiswa' && cekDanNonaktifkanJikaMagangSelesai($_SESSION['user_id'])) {
        session_unset();
        session_destroy();
        redirect('/login.php?selesai=1');
    }

    // Role tidak diizinkan untuk halaman ini → kembalikan ke beranda role-nya sendiri
    // (bukan ke login, karena user-nya memang sudah login).
    if ($role !== null) {
        $roleDiizinkan = (array) $role;
        if (!in_array($roleUser, $roleDiizinkan, true)) {
            redirect(berandaRole($roleUser));
        }
    }

    // Sinkronkan status semua mahasiswa yang masa magangnya sudah lewat tiap kali
    // admin/pembimbing membuka panelnya, supaya daftar status selalu akurat.
    if ($roleUser === 'admin' || $roleUser === 'pembimbing') {
        cekDanNonaktifkanSemuaMagangSelesai();
    }
    // Pembersihan file foto cukup dijalankan dari sisi admin.
    if ($roleUser === 'admin') {
        hapusFotoAbsenKedaluwarsa();
        hapusLogKedaluwarsa();
    }

    // Halaman bersama admin & pembimbing fisiknya ada di folder /admin, lalu dipanggil
    // lewat file pembungkus di /pembimbing. Kalau pembimbing membuka URL /admin/...
    // secara langsung, arahkan ke URL /pembimbing/... yang setara supaya navigasi,
    // redirect, dan link relatif di halaman tetap konsisten.
    // (Berlaku kebalikannya juga: admin yang membuka /pembimbing/... diarahkan ke /admin/...)
    $folderSekarang = basename(dirname($_SERVER['SCRIPT_FILENAME']));
    $folderSeharusnya = ltrim(panelBase($roleUser), '/');
    if ($_SERVER['REQUEST_METHOD'] === 'GET'
        && in_array($folderSekarang, ['admin', 'pembimbing'], true)
        && $folderSekarang !== $folderSeharusnya) {
        $qs = $_SERVER['QUERY_STRING'] ?? '';
        redirect(panelBase($roleUser) . '/' . basename($_SERVER['SCRIPT_NAME']) . ($qs !== '' ? '?' . $qs : ''));
    }

    // Wajibkan akun (semua role) yang masih pakai password awal/hasil reset untuk
    // ganti password dulu SEBELUM bisa membuka halaman lain manapun. Halaman Profil
    // (tempat ganti password) dan Keluar (logout) tetap boleh diakses.
    if (!empty($_SESSION['harus_ganti_password'])) {
        $halamanSekarang = basename($_SERVER['SCRIPT_NAME']);
        if (!in_array($halamanSekarang, ['profil.php', 'logout.php'], true)) {
            redirect(panelBase($roleUser) . '/profil.php?wajib_ganti=1');
        }
    }
}
