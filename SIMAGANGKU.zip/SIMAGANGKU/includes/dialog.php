<?php
/**
 * ============================================================
 *  POPUP PEMBERITAHUAN & KONFIRMASI (dialog tengah layar)
 * ============================================================
 * Dipakai untuk SEMUA aksi di aplikasi (simpan, edit, hapus, reset password,
 * setujui izin, absen, dll) supaya pemberitahuan "berhasil / gagal" tampil
 * seragam sebagai popup di tengah layar.
 *
 * Dibuat mandiri (tanpa library tambahan), jadi tidak ada file/CDN baru yang
 * perlu diunduh dan tetap jalan walau koneksi internet lambat.
 *
 * Cara pakai dari PHP (biasanya TIDAK perlu dipanggil manual):
 *   tambahDialog('sukses', 'Data berhasil disimpan.');
 *   tambahDialog('error', 'Data gagal disimpan.', 'Judul opsional');
 * File ini otomatis mengumpulkan variabel pesan yang sudah dipakai halaman
 * lama ($success, $error, $successCabang, $errorLibur, ...) lewat
 * kumpulkanDialogOtomatis(), jadi tiap halaman langsung dapat popup.
 *
 * Cara pakai dari JavaScript:
 *   Dialog.sukses('Berhasil disimpan.');
 *   Dialog.error('Gagal menyimpan.');
 *   Dialog.info('Sekadar pemberitahuan.');
 *   if (await Dialog.konfirmasi({ pesan: 'Hapus data ini?', bahaya: true })) { ... }
 *   const nilai = await Dialog.prompt({ pesan: 'Password baru:' }); // null = batal
 *
 * Konfirmasi juga bisa tanpa menulis JS: cukup tambahkan atribut data-konfirmasi
 * pada <form>, <a>, atau <button>:
 *   <form method="POST" data-konfirmasi="Hapus data ini?" data-konfirmasi-bahaya="1">
 */

/** Masukkan 1 pesan ke antrean popup halaman ini. */
function tambahDialog($tipe, $pesan, $judul = null) {
    if (!is_string($pesan) || trim($pesan) === '') return;
    if (!isset($GLOBALS['_antrean_dialog'])) $GLOBALS['_antrean_dialog'] = [];
    $GLOBALS['_antrean_dialog'][] = [
        'tipe' => in_array($tipe, ['sukses', 'error', 'info'], true) ? $tipe : 'info',
        'pesan' => trim($pesan),
        'judul' => $judul,
    ];
}

/**
 * Kumpulkan otomatis variabel pesan milik halaman yang sedang dirender:
 * nama variabel berawalan success/sukses → popup berhasil, error/gagal → popup gagal.
 * Nilai non-string (mis. penanda boolean $gagalSubmit) dan string kosong diabaikan.
 */
function kumpulkanDialogOtomatis() {
    $sudah = [];
    foreach ($GLOBALS as $nama => $nilai) {
        if (!is_string($nilai) || trim($nilai) === '') continue;
        if (preg_match('/^(success|sukses)/i', $nama)) {
            $tipe = 'sukses';
        } elseif (preg_match('/^(error|gagal)/i', $nama)) {
            $tipe = 'error';
        } else {
            continue;
        }
        $kunci = $tipe . '|' . trim($nilai); // hindari pesan kembar dari 2 variabel
        if (isset($sudah[$kunci])) continue;
        $sudah[$kunci] = true;
        tambahDialog($tipe, $nilai);
    }
}

kumpulkanDialogOtomatis();
$antreanDialog = $GLOBALS['_antrean_dialog'] ?? [];
?>
<style>
.dlg-overlay{position:fixed;inset:0;z-index:2000;display:flex;align-items:center;justify-content:center;
  padding:16px;background:rgba(15,23,42,.45);opacity:0;visibility:hidden;transition:opacity .18s ease,visibility .18s ease;}
.dlg-overlay.tampil{opacity:1;visibility:visible;}
.dlg-kartu{width:100%;max-width:340px;background:#fff;border-radius:10px;padding:26px 22px 18px;
  box-shadow:0 12px 40px rgba(15,23,42,.22);text-align:center;transform:scale(.88);transition:transform .18s ease;}
.dlg-overlay.tampil .dlg-kartu{transform:scale(1);}
.dlg-ikon{width:76px;height:76px;margin:0 auto 18px;border-radius:50%;border:4px solid currentColor;
  display:flex;align-items:center;justify-content:center;animation:dlgIkon .3s ease;}
.dlg-ikon svg{width:40px;height:40px;stroke:currentColor;stroke-width:4;fill:none;stroke-linecap:round;stroke-linejoin:round;}
@keyframes dlgIkon{from{transform:scale(.6);opacity:0}to{transform:scale(1);opacity:1}}
.dlg-ikon--sukses{color:#5ac77e;}
.dlg-ikon--error{color:#ef5350;}
.dlg-ikon--info{color:#42a5f5;}
.dlg-ikon--tanya{color:#f0ad4e;}
.dlg-judul{font-size:21px;font-weight:700;color:#3f4a56;margin:0 0 8px;}
.dlg-pesan{font-size:13.5px;color:#8d98a5;margin:0;white-space:pre-line;line-height:1.55;}
.dlg-input{margin-top:14px;width:100%;border:1px solid #d7dde4;border-radius:6px;padding:9px 12px;font-size:14px;}
.dlg-input:focus{outline:none;border-color:#42a5f5;box-shadow:0 0 0 3px rgba(66,165,245,.18);}
.dlg-tautan{margin-top:14px;display:flex;flex-direction:column;gap:6px;text-align:left;}
.dlg-tautan a{display:block;border:1px solid #d7dde4;border-radius:6px;padding:7px 12px;font-size:13px;
  color:#2f6fb5;text-decoration:none;background:#f7f9fc;}
.dlg-tautan a:hover{background:#eef3f9;}
.dlg-aksi{display:flex;justify-content:flex-end;gap:8px;margin-top:22px;}
.dlg-btn{border:none;border-radius:6px;padding:8px 20px;font-size:14px;font-weight:600;cursor:pointer;color:#fff;
  box-shadow:0 0 0 3px transparent;transition:box-shadow .15s ease,filter .15s ease;}
.dlg-btn:hover{filter:brightness(1.06);}
.dlg-btn:focus-visible{outline:none;box-shadow:0 0 0 3px rgba(66,165,245,.35);}
.dlg-btn--utama{background:#4fc3f7;}
.dlg-btn--bahaya{background:#ef5350;}
.dlg-btn--batal{background:#eceff1;color:#5b6773;}
@media (max-width:400px){.dlg-aksi{justify-content:stretch;}.dlg-btn{flex:1;}}
</style>

<div class="dlg-overlay" id="dlgOverlay" role="dialog" aria-modal="true" aria-labelledby="dlgJudul">
  <div class="dlg-kartu" role="document">
    <div class="dlg-ikon" id="dlgIkon"></div>
    <h2 class="dlg-judul" id="dlgJudul"></h2>
    <p class="dlg-pesan" id="dlgPesan"></p>
    <input type="text" class="dlg-input" id="dlgInput" style="display:none;" autocomplete="off">
    <div class="dlg-tautan" id="dlgTautan" style="display:none;"></div>
    <div class="dlg-aksi" id="dlgAksi"></div>
  </div>
</div>

<script>
(function () {
  var overlay = document.getElementById('dlgOverlay');
  var ikonEl = document.getElementById('dlgIkon');
  var judulEl = document.getElementById('dlgJudul');
  var pesanEl = document.getElementById('dlgPesan');
  var inputEl = document.getElementById('dlgInput');
  var aksiEl = document.getElementById('dlgAksi');
  var tautanEl = document.getElementById('dlgTautan');

  // Ikon digambar sebagai SVG supaya bentuknya rapi di semua ukuran layar.
  var SVG = {
    sukses: '<svg viewBox="0 0 52 52"><path d="M14 27l9 9 16-18"/></svg>',
    error: '<svg viewBox="0 0 52 52"><path d="M17 17l18 18M35 17L17 35"/></svg>',
    info: '<svg viewBox="0 0 52 52"><path d="M26 22v16"/><path d="M26 15v.5"/></svg>',
    tanya: '<svg viewBox="0 0 52 52"><path d="M20 20a6 6 0 1 1 6 7v4"/><path d="M26 38v.5"/></svg>'
  };
  var JUDUL = { sukses: 'Berhasil!', error: 'Gagal!', info: 'Pemberitahuan', tanya: 'Konfirmasi' };

  var antre = [];
  var sedangTampil = false;
  var selesaikan = null;

  function tutup(hasil) {
    var fn = selesaikan;
    selesaikan = null;
    overlay.classList.remove('tampil');
    sedangTampil = false;
    if (fn) fn(hasil);
    setTimeout(jalankanAntrean, 180); // tunggu animasi tutup selesai
  }

  function tombol(label, kelas, ambilHasil) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'dlg-btn ' + kelas;
    b.textContent = label;
    b.addEventListener('click', function () { tutup(ambilHasil()); });
    return b;
  }

  function jalankanAntrean() {
    if (sedangTampil || !antre.length) return;
    var item = antre.shift();
    var o = item.opsi;
    var tipe = o.tipe || 'info';

    sedangTampil = true;
    selesaikan = item.resolve;

    ikonEl.className = 'dlg-ikon dlg-ikon--' + tipe;
    ikonEl.innerHTML = SVG[tipe] || SVG.info;
    judulEl.textContent = o.judul || JUDUL[tipe] || JUDUL.info;
    pesanEl.textContent = o.pesan || '';
    pesanEl.style.display = o.pesan ? '' : 'none';

    if (o.jenis === 'prompt') {
      inputEl.style.display = '';
      inputEl.type = o.password ? 'password' : 'text';
      inputEl.value = o.nilaiAwal || '';
      inputEl.placeholder = o.placeholder || '';
    } else {
      inputEl.style.display = 'none';
      inputEl.value = '';
    }

    // Tautan pendukung (mis. "unduh laporan dulu" sebelum menghapus akun).
    tautanEl.innerHTML = '';
    var tautan = o.tautan || [];
    tautanEl.style.display = tautan.length ? '' : 'none';
    tautan.forEach(function (t) {
      var a = document.createElement('a');
      a.href = t.url; a.target = '_blank'; a.rel = 'noopener';
      a.textContent = t.label;   // textContent, bukan innerHTML, supaya aman dari XSS
      tautanEl.appendChild(a);
    });

    aksiEl.innerHTML = '';
    if (o.jenis === 'konfirmasi' || o.jenis === 'prompt') {
      aksiEl.appendChild(tombol(o.labelTidak || 'Batal', 'dlg-btn--batal', function () {
        return o.jenis === 'prompt' ? null : false;
      }));
      aksiEl.appendChild(tombol(o.labelYa || 'Ya', o.bahaya ? 'dlg-btn--bahaya' : 'dlg-btn--utama', function () {
        return o.jenis === 'prompt' ? inputEl.value : true;
      }));
    } else {
      aksiEl.appendChild(tombol('OK', 'dlg-btn--utama', function () { return true; }));
    }

    overlay.classList.add('tampil');
    setTimeout(function () {
      if (o.jenis === 'prompt') inputEl.focus();
      else aksiEl.lastChild.focus();
    }, 60);
  }

  function tampilkan(opsi) {
    return new Promise(function (resolve) {
      antre.push({ opsi: opsi, resolve: resolve });
      jalankanAntrean();
    });
  }

  // Esc = batal, Enter di kolom input = tombol utama
  document.addEventListener('keydown', function (e) {
    if (!sedangTampil) return;
    if (e.key === 'Escape') {
      e.preventDefault();
      tutup(inputEl.style.display === 'none' ? false : null);
    } else if (e.key === 'Enter' && inputEl.style.display !== 'none' && document.activeElement === inputEl) {
      e.preventDefault();
      tutup(inputEl.value);
    }
  });

  window.Dialog = {
    sukses: function (pesan, judul) { return tampilkan({ tipe: 'sukses', pesan: pesan, judul: judul }); },
    error: function (pesan, judul) { return tampilkan({ tipe: 'error', pesan: pesan, judul: judul }); },
    info: function (pesan, judul) { return tampilkan({ tipe: 'info', pesan: pesan, judul: judul }); },
    konfirmasi: function (o) {
      o = o || {};
      return tampilkan({ jenis: 'konfirmasi', tipe: 'tanya', pesan: o.pesan, judul: o.judul, tautan: o.tautan,
                         labelYa: o.labelYa || 'Ya, lanjutkan', labelTidak: o.labelTidak, bahaya: o.bahaya });
    },
    prompt: function (o) {
      o = o || {};
      return tampilkan({ jenis: 'prompt', tipe: 'info', pesan: o.pesan, judul: o.judul,
                         placeholder: o.placeholder, nilaiAwal: o.nilaiAwal, password: o.password,
                         labelYa: o.labelYa || 'Lanjutkan', labelTidak: o.labelTidak || 'Batal' });
    }
  };

  // ---- Konfirmasi otomatis untuk elemen ber-atribut data-konfirmasi ----
  function opsiKonfirmasi(node) {
    return {
      pesan: node.getAttribute('data-konfirmasi'),
      judul: node.getAttribute('data-konfirmasi-judul') || undefined,
      labelYa: node.getAttribute('data-konfirmasi-ya') || undefined,
      bahaya: node.hasAttribute('data-konfirmasi-bahaya'),
      tautan: (node.getAttribute('data-konfirmasi-tautan') || '')
        .split('||')
        .map(function (bagian) {
          var p = bagian.split('|');
          return p.length >= 2 ? { label: p[0].trim(), url: p.slice(1).join('|').trim() } : null;
        })
        .filter(Boolean)
    };
  }

  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form.matches('[data-konfirmasi]') || form.dataset.konfirmasiLolos === '1') return;
    e.preventDefault();
    Dialog.konfirmasi(opsiKonfirmasi(form)).then(function (ya) {
      if (!ya) return;
      form.dataset.konfirmasiLolos = '1';
      if (typeof form.requestSubmit === 'function') form.requestSubmit(); else form.submit();
    });
  }, true);

  document.addEventListener('click', function (e) {
    var node = e.target.closest('a[data-konfirmasi], button[data-konfirmasi]:not([type=submit])');
    if (!node || node.dataset.konfirmasiLolos === '1') return;
    e.preventDefault();
    Dialog.konfirmasi(opsiKonfirmasi(node)).then(function (ya) {
      if (!ya) return;
      node.dataset.konfirmasiLolos = '1';
      node.click();
    });
  }, true);

  // ---- Pesan hasil aksi dari server ----
  var pesanServer = <?= jsonUntukScript(array_map(fn($d) => ['tipe' => $d['tipe'], 'pesan' => $d['pesan'], 'judul' => $d['judul']], $antreanDialog)) ?>;

  // Bersihkan penanda notifikasi dari alamat URL setelah pesannya tampil, supaya
  // menekan Refresh tidak menampilkan notifikasi yang sama lagi. Filter lain
  // (bulan, status, halaman, dsb.) sengaja dibiarkan agar tampilan tidak berubah.
  if (pesanServer.length && window.history && history.replaceState) {
    try {
      var alamat = new URL(window.location.href);
      <?= jsonUntukScript(paramPesanUrl()) ?>.forEach(function (k) { alamat.searchParams.delete(k); });
      var sisa = alamat.searchParams.toString();
      history.replaceState({}, '', alamat.pathname + (sisa ? '?' + sisa : '') + alamat.hash);
    } catch (e) { /* alamat tidak standar — abaikan saja */ }
  }

  function tampilkanPesanServer() {
    pesanServer.forEach(function (p) {
      // Alert di halaman yang teksnya sama persis dihapus, supaya pesannya tidak dobel.
      document.querySelectorAll('.alert').forEach(function (a) {
        if (a.textContent.trim() === p.pesan) a.remove();
      });
      tampilkan({ tipe: p.tipe, pesan: p.pesan, judul: p.judul || undefined });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tampilkanPesanServer);
  } else {
    tampilkanPesanServer();
  }
})();
</script>
