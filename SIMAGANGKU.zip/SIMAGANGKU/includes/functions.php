<?php
/**
 * Kumpulan fungsi bantu yang dipakai di berbagai halaman.
 */

/**
 * Hitung jarak antara 2 koordinat pakai formula Haversine, hasil dalam meter.
 */
function hitungJarakMeter($lat1, $lng1, $lat2, $lng2) {
    $earthRadius = 6371000; // meter
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat / 2) * sin($dLat / 2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLng / 2) * sin($dLng / 2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    return (int) round($earthRadius * $c);
}

/**
 * Simpan file base64 (dari kamera / hasil canvas) ke folder uploads.
 * Mengembalikan nama file relatif yang disimpan, atau false jika gagal.
 *
 * Foto sudah diperkecil di sisi klien (JS) sebelum dikirim, TAPI resize di sini
 * dipertahankan sebagai lapisan kedua di SERVER — supaya batas ukuran/dimensi
 * foto tidak bisa dilewati walau ada yang memanggil endpoint absen_proses.php
 * langsung (mis. lewat curl/Postman) tanpa lewat kamera bawaan aplikasi ini.
 */
function simpanFotoBase64($base64String, $folder, $prefixNama, $maxDimensi = 1000) {
    if (empty($base64String) || strpos($base64String, 'base64,') === false) {
        return false;
    }

    // Batasi ukuran string base64 mentah SEBELUM decode, supaya tidak ada yang
    // coba kirim file raksasa (menghabiskan memori/CPU saat diproses GD, atau
    // memenuhi disk server) — ~15MB base64 masih longgar untuk foto HP modern.
    if (strlen($base64String) > 15 * 1024 * 1024) {
        return false;
    }

    list(, $data) = explode('base64,', $base64String);
    $data = base64_decode($data);
    if ($data === false || $data === '') return false;

    // Kalau ekstensi GD tersedia (default di hampir semua instalasi PHP/XAMPP/Laragon),
    // pastikan foto tidak melebihi $maxDimensi px di sisi terpanjang, lalu re-encode
    // sebagai JPEG terkompresi, sebelum disimpan ke disk.
    if (extension_loaded('gd')) {
        $image = @imagecreatefromstring($data);
        if ($image === false) return false; // bukan file gambar yang valid

        $lebar = imagesx($image);
        $tinggi = imagesy($image);
        $sisiTerpanjang = max($lebar, $tinggi);

        if ($sisiTerpanjang > $maxDimensi) {
            $skala = $maxDimensi / $sisiTerpanjang;
            $lebarBaru = max(1, (int) round($lebar * $skala));
            $tinggiBaru = max(1, (int) round($tinggi * $skala));
            $diperkecil = imagecreatetruecolor($lebarBaru, $tinggiBaru);
            imagecopyresampled($diperkecil, $image, 0, 0, 0, 0, $lebarBaru, $tinggiBaru, $lebar, $tinggi);
            imagedestroy($image);
            $image = $diperkecil;
        }

        ob_start();
        imagejpeg($image, null, 80);
        $data = ob_get_clean();
        imagedestroy($image);
    }

    $namaFile = $prefixNama . '_' . date('Ymd_His') . '_' . uniqid() . '.jpg';
    if (!pastikanFolderUpload($folder)) {
        return false;
    }
    $tujuan = __DIR__ . '/../uploads/' . $folder . '/' . $namaFile;

    if (@file_put_contents($tujuan, $data) === false) {
        error_log("Gagal menyimpan foto ke $tujuan (periksa izin tulis folder uploads/$folder).");
        return false;
    }
    return $folder . '/' . $namaFile;
}

/**
 * Simpan file upload biasa ($_FILES) untuk lampiran izin/sakit.
 * Hanya izinkan gambar & PDF, maksimal 3MB.
 */
/**
 * Pastikan folder uploads/<nama> ada & bisa ditulisi; dibuat otomatis kalau belum ada.
 * Mencegah absen/unggahan gagal hanya karena folder kosong tidak ikut tersalin saat
 * aplikasi dipindahkan (zip/FTP sering tidak membawa folder kosong).
 */
function pastikanFolderUpload($folder) {
    $dir = __DIR__ . '/../uploads/' . $folder;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        error_log("Folder uploads/$folder tidak ada dan gagal dibuat.");
        return false;
    }
    if (!is_writable($dir)) {
        error_log("Folder uploads/$folder tidak bisa ditulisi (periksa izin folder).");
        return false;
    }
    return true;
}

/**
 * Simpan berkas unggahan dengan pemeriksaan BERLAPIS:
 * 1. ekstensi harus termasuk yang diizinkan,
 * 2. ukuran maksimal 3MB,
 * 3. ISI berkasnya benar-benar diperiksa — gambar harus terbaca sebagai gambar,
 *    PDF harus diawali penanda "%PDF-". Jadi berkas berbahaya yang sekadar
 *    diganti namanya jadi .jpg tetap ditolak.
 *
 * $jenisDiizinkan: batasi lebih ketat per tempat pemakaian, mis. foto profil
 * hanya ['jpg','jpeg','png'] supaya PDF tidak bisa dipasang sebagai foto.
 */
function simpanFileUpload($fileArray, $folder, $prefixNama, $jenisDiizinkan = ['jpg', 'jpeg', 'png', 'pdf']) {
    if (empty($fileArray) || $fileArray['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    $ext = strtolower(pathinfo($fileArray['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $jenisDiizinkan, true)) {
        $labelJenis = strtoupper(implode(', ', $jenisDiizinkan));
        return ['error' => "Format file harus $labelJenis."];
    }
    if ($fileArray['size'] > 3 * 1024 * 1024) {
        return ['error' => 'Ukuran file maksimal 3MB.'];
    }

    // --- Periksa isi berkasnya, bukan cuma namanya ---
    if (in_array($ext, ['jpg', 'jpeg', 'png'], true)) {
        $info = @getimagesize($fileArray['tmp_name']);
        $tipeCocok = [IMAGETYPE_JPEG, IMAGETYPE_PNG];
        if ($info === false || !in_array($info[2], $tipeCocok, true)) {
            return ['error' => 'Berkas itu bukan gambar JPG/PNG yang sah. Pastikan kamu mengunggah foto, bukan berkas lain yang namanya diubah.'];
        }
    } elseif ($ext === 'pdf') {
        $awal = @file_get_contents($fileArray['tmp_name'], false, null, 0, 5);
        if ($awal !== '%PDF-') {
            return ['error' => 'Berkas itu bukan PDF yang sah.'];
        }
    }

    $namaFile = $prefixNama . '_' . date('Ymd_His') . '_' . uniqid() . '.' . $ext;
    if (!pastikanFolderUpload($folder)) {
        return ['error' => 'Folder penyimpanan berkas tidak bisa dibuat di server. Hubungi admin.'];
    }
    $tujuan = __DIR__ . '/../uploads/' . $folder . '/' . $namaFile;

    if (!@move_uploaded_file($fileArray['tmp_name'], $tujuan)) {
        return ['error' => 'Gagal menyimpan file.'];
    }
    return ['path' => $folder . '/' . $namaFile];
}

function formatTanggalID($tanggalISO) {
    if (empty($tanggalISO)) return '-';
    $bulan = ['', 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    $ts = strtotime($tanggalISO);
    return date('j', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
}

function formatRentangTanggal($mulai, $selesai) {
    if ($mulai === $selesai) return formatTanggalID($mulai);
    return formatTanggalID($mulai) . ' – ' . formatTanggalID($selesai);
}

function ambilPengaturan() {
    static $pengaturan = null;
    if ($pengaturan === null) {
        $stmt = getDB()->query("SELECT * FROM pengaturan LIMIT 1");
        $pengaturan = $stmt->fetch();
    }
    return $pengaturan;
}

/**
 * ============================================================
 *  BATAS AKHIR ABSEN MASUK
 * ============================================================
 * Absen masuk ditutup setiap hari begitu lewat JAM PULANG cabang mahasiswa
 * (ikut pengaturan tiap cabang, bukan jam tetap). Lewat dari itu:
 * - absen masuk ditolak, dan
 * - hari itu langsung dihitung "Tidak Hadir" di dashboard, riwayat, dan laporan —
 *   tidak perlu menunggu pergantian hari.
 * Kalau mahasiswanya sebenarnya hadir (mis. absennya gagal), admin/pembimbing
 * memperbaikinya lewat menu Absen Manual, dan statusnya otomatis ikut berubah.
 */

/** Jam tutup absen masuk untuk sebuah cabang (= jam pulang), atau null kalau belum diatur. */
function jamTutupAbsenMasuk($cabang) {
    if (!is_array($cabang)) $cabang = ambilCabang($cabang);
    return $cabang['jam_pulang'] ?? null;
}

/**
 * Apakah kesempatan absen masuk untuk $tanggal sudah lewat?
 * - tanggal sebelum hari ini  → sudah lewat,
 * - hari ini                  → sudah lewat kalau jam sekarang melewati jam pulang cabang,
 * - cabang belum diatur       → dianggap BELUM lewat (biar tidak menghukum mahasiswa
 *                               karena pengaturan cabang belum lengkap).
 */
function absenMasukSudahDitutup($cabang, $tanggal, $jamSekarang = null) {
    $hariIni = date('Y-m-d');
    if ($tanggal < $hariIni) return true;
    if ($tanggal > $hariIni) return false;

    $jamTutup = jamTutupAbsenMasuk($cabang);
    if (!$jamTutup) return false;
    return ($jamSekarang ?? date('H:i:s')) > $jamTutup;
}

/**
 * Cek apakah data jam kerja sebuah cabang SUDAH lengkap diisi admin
 * (jam masuk, batas terlambat, jam pulang). Cabang yang baru
 * ditambahkan belum punya jam kerja (NULL) sampai admin mengaturnya lewat
 * menu Pengaturan → Umum & Jam Kerja → pilih cabang itu. Selama belum
 * diatur, cabang ini tidak boleh dipakai untuk mendaftarkan mahasiswa baru
 * ataupun dipakai absen (supaya tidak ada absen yang divalidasi terhadap
 * jam kerja yang belum jelas).
 */
function cabangSudahDiatur($cabang) {
    return $cabang
        && $cabang['jam_masuk'] !== null
        && $cabang['batas_terlambat'] !== null
        && $cabang['jam_pulang'] !== null;
}

/**
 * Cabang yang dipakai OTOMATIS di panel pembimbing (diambil dari akun pembimbing,
 * ditetapkan admin) — pembimbing tidak perlu, dan tidak bisa, memilih cabang sendiri.
 * Mengembalikan data cabang, atau null kalau yang login bukan pembimbing ATAU
 * cabang pada akunnya belum diatur admin.
 */
function cabangOtomatisPembimbing() {
    if (!isPembimbing()) return null;
    $pb = ambilPembimbing($_SESSION['user_id'] ?? 0);
    return ($pb && $pb['cabang_id']) ? ambilCabang($pb['cabang_id']) : null;
}

/**
 * ============================================================
 *  RIWAYAT AKTIVITAS (audit log aksi penting)
 * ============================================================
 * Mencatat siapa melakukan apa: hapus/tambah/ubah akun, reset password, ubah
 * status, kelola cabang/kategori/divisi/hari libur, absen manual, proses izin.
 *
 * Sifatnya TAMBAH SAJA — tidak ada fungsi ubah/hapus di sini selain pembersihan
 * otomatis berdasarkan masa simpan (pengaturan.retensi_log_bulan).
 * Catatan TIDAK PERNAH menyimpan isi kata sandi.
 */

/** Daftar aksi yang dikenal + labelnya untuk ditampilkan & difilter. */
function daftarAksiLog() {
    return [
        'tambah_akun'     => 'Tambah akun',
        'ubah_akun'       => 'Ubah data akun',
        'hapus_akun'      => 'Hapus akun',
        'ubah_status'     => 'Ubah status aktif/nonaktif',
        'ubah_level'      => 'Ubah level admin',
        'sertifikat'      => 'Tandai sertifikat',
        'reset_password'  => 'Reset kata sandi',
        'tambah_data'     => 'Tambah data',
        'ubah_data'       => 'Ubah data',
        'hapus_data'      => 'Hapus data',
        'absen_manual'    => 'Isi absen manual',
        'hapus_absen'     => 'Hapus absen manual',
        'proses_izin'     => 'Proses izin/sakit',
        'ubah_pengaturan' => 'Ubah pengaturan',
        'login_diblokir'  => 'Login diblokir sementara',
    ];
}

function labelAksiLog($aksi) {
    return daftarAksiLog()[$aksi] ?? $aksi;
}

/**
 * Catat 1 aksi ke riwayat aktivitas. Dipanggil SETELAH aksinya berhasil.
 * Sengaja tidak pernah melempar error supaya kegagalan pencatatan tidak
 * menggagalkan aksi yang sudah terlanjur tersimpan.
 */
function catatAktivitas($aksi, $objekTipe = null, $objekId = null, $objekNama = null, $keterangan = null) {
    try {
        $stmt = getDB()->prepare("INSERT INTO log_aktivitas
            (user_id, nama_pelaku, role_pelaku, aksi, objek_tipe, objek_id, objek_nama, keterangan, ip_address)
            VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $_SESSION['user_id'] ?? null,
            $_SESSION['user_nama'] ?? 'Sistem',
            $_SESSION['user_role'] ?? 'sistem',
            $aksi,
            $objekTipe,
            $objekId ? (int) $objekId : null,
            $objekNama !== null ? mb_substr_aman($objekNama, 191) : null,
            $keterangan !== null ? mb_substr_aman($keterangan, 500) : null,
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (PDOException $e) {
        // Diamkan: pencatatan tidak boleh menggagalkan aksi utama.
    }
}

/** Potong teks berdasarkan karakter tanpa bergantung ekstensi mbstring. */
function mb_substr_aman($teks, $maks) {
    $teks = trim((string) $teks);
    if (preg_match('/^.{0,' . (int) $maks . '}/us', $teks, $m)) {
        return $m[0];
    }
    return substr($teks, 0, $maks);
}

/**
 * Hapus riwayat aktivitas yang sudah melewati masa simpan (pengaturan.retensi_log_bulan).
 * 0 = disimpan selamanya. Dijalankan maksimal 1x per hari per sesi admin.
 */
function hapusLogKedaluwarsa() {
    if (($_SESSION['_terakhir_bersihkan_log'] ?? '') === date('Y-m-d')) {
        return;
    }
    $_SESSION['_terakhir_bersihkan_log'] = date('Y-m-d');

    $bulan = (int) (ambilPengaturan()['retensi_log_bulan'] ?? 0);
    if ($bulan <= 0) return;

    $stmt = getDB()->prepare("DELETE FROM log_aktivitas WHERE created_at < DATE_SUB(CURDATE(), INTERVAL ? MONTH)");
    $stmt->execute([$bulan]);
}

/**
 * ============================================================
 *  IZIN/SAKIT 1 HARI — PERSETUJUAN OTOMATIS
 * ============================================================
 * Kebijakan instansi: izin/sakit 1 hari tidak perlu menunggu persetujuan
 * pembimbing. Supaya aturan "hari kedua dan seterusnya harus disetujui" benar-benar
 * berjalan, pengajuan 1 hari yang BERSAMBUNG dengan hari izin lain tetap dianggap
 * izin panjang dan harus disetujui.
 *
 * Mengembalikan:
 *   ['otomatis' => true,  'alasan' => null]
 *   ['otomatis' => false, 'alasan' => 'kalimat penjelasan untuk mahasiswa']
 */
function cekIzinBolehOtomatis($userId, $tglMulai, $tglSelesai) {
    $hariIni = date('Y-m-d');

    if ($tglMulai !== $tglSelesai) {
        return ['otomatis' => false, 'alasan' => 'Pengajuan lebih dari 1 hari perlu persetujuan admin/pembimbing.'];
    }
    if ($tglMulai !== $hariIni) {
        return ['otomatis' => false, 'alasan' => 'Pengajuan untuk tanggal selain hari ini perlu persetujuan admin/pembimbing.'];
    }

    // Bersambung dengan hari izin lain (H-1 atau H+1), atau sudah ada pengajuan di
    // hari yang sama → pada kenyataannya izin lebih dari 1 hari, jadi butuh persetujuan.
    $kemarin = date('Y-m-d', strtotime($tglMulai . ' -1 day'));
    $besok = date('Y-m-d', strtotime($tglMulai . ' +1 day'));
    $stmt = getDB()->prepare("SELECT COUNT(*) FROM izin
                              WHERE user_id = ? AND status IN ('pending','approved')
                                AND tanggal_mulai <= ? AND tanggal_selesai >= ?");
    $stmt->execute([(int) $userId, $besok, $kemarin]);
    if ((int) $stmt->fetchColumn() > 0) {
        return ['otomatis' => false, 'alasan' => 'Kamu sudah punya pengajuan izin/sakit di hari yang berdekatan, jadi pengajuan ini dihitung lanjutan dan perlu persetujuan admin/pembimbing.'];
    }

    return ['otomatis' => true, 'alasan' => null];
}

/**
 * ============================================================
 *  LOG BOOK (catatan aktivitas harian mahasiswa)
 * ============================================================
 * 1 baris = 1 aktivitas, jadi 1 hari bisa berisi beberapa aktivitas.
 * Diisi sendiri oleh mahasiswa; pembimbing & admin hanya melihat + export PDF.
 */

/**
 * Validasi isi 1 entri log book. Mengembalikan pesan error, atau null kalau valid.
 * $dataUser = baris users milik mahasiswa (butuh tanggal_mulai & tanggal_selesai).
 */
function validasiLogbook($tanggal, $kegiatan, $dataUser) {
    // Aturan tanggal (hanya hari ini + wajib sudah absen masuk) dicek terpisah lewat
    // alasanTidakBolehIsiLogbook(); di sini tinggal validasi isi catatannya.
    $pesanTanggal = alasanTidakBolehIsiLogbook($dataUser, $tanggal);
    if ($pesanTanggal) {
        return $pesanTanggal;
    }
    $kegiatan = trim($kegiatan);
    if ($kegiatan === '') {
        return 'Uraian kegiatan wajib diisi.';
    }
    if (!preg_match('/^.{1,2000}$/us', $kegiatan)) {
        return 'Uraian kegiatan maksimal 2000 karakter.';
    }
    return null;
}

/**
 * Kelompokkan baris log book per tanggal:
 * ['2026-09-18' => ['items' => [...]], ...]
 */
function kelompokkanLogbook($baris) {
    $hasil = [];
    foreach ($baris as $b) {
        $tgl = $b['tanggal'];
        if (!isset($hasil[$tgl])) $hasil[$tgl] = ['items' => []];
        $hasil[$tgl]['items'][] = $b;
    }
    return $hasil;
}

/**
 * Cek apakah mahasiswa sudah mengisi log book pada tanggal tertentu.
 * Dipakai untuk pengingat "log book hari ini belum diisi" di halaman Absen.
 */
function sudahIsiLogbook($userId, $tanggal) {
    $stmt = getDB()->prepare("SELECT 1 FROM logbook WHERE user_id = ? AND tanggal = ? LIMIT 1");
    $stmt->execute([(int) $userId, $tanggal]);
    return (bool) $stmt->fetchColumn();
}

/**
 * Cek apakah mahasiswa SUDAH absen masuk (status valid) pada tanggal tertentu.
 * Absen yang diisikan admin/pembimbing lewat menu Absen Manual ikut dihitung sah,
 * supaya mahasiswa yang absennya gagal karena kendala teknis tidak terkunci.
 */
function sudahAbsenMasuk($userId, $tanggal) {
    $stmt = getDB()->prepare("SELECT 1 FROM absensi WHERE user_id = ? AND tanggal = ? AND jenis = 'masuk' AND status = 'valid' LIMIT 1");
    $stmt->execute([(int) $userId, $tanggal]);
    return (bool) $stmt->fetchColumn();
}

/**
 * Cek apakah mahasiswa punya izin/sakit yang DISETUJUI mencakup tanggal tertentu.
 */
function adaIzinDisetujui($userId, $tanggal) {
    $stmt = getDB()->prepare("SELECT jenis FROM izin WHERE user_id = ? AND status = 'approved'
                              AND ? BETWEEN tanggal_mulai AND tanggal_selesai LIMIT 1");
    $stmt->execute([(int) $userId, $tanggal]);
    return $stmt->fetchColumn() ?: null;
}

/**
 * Aturan pengisian log book (disepakati bersama pengguna aplikasi):
 * - Log book HANYA bisa diisi untuk HARI INI, tidak bisa untuk tanggal lain.
 * - Syaratnya mahasiswa sudah absen masuk hari ini (absen manual admin ikut sah).
 * - Catatan hanya bisa diubah/dihapus di hari yang sama; hari-hari sebelumnya terkunci.
 *
 * Mengembalikan pesan alasan kalau TIDAK boleh mengisi, atau null kalau boleh.
 */
function alasanTidakBolehIsiLogbook($dataUser, $tanggal, $hariIni = null) {
    $hariIni = $hariIni ?? date('Y-m-d');

    if ($tanggal !== $hariIni) {
        return 'Log book hanya bisa diisi untuk hari ini (' . formatTanggalID($hariIni) . '). '
             . 'Catatan hari-hari sebelumnya sudah terkunci dan tidak bisa ditambah lagi.';
    }
    if (!empty($dataUser['tanggal_mulai']) && $tanggal < $dataUser['tanggal_mulai']) {
        return 'Magang kamu baru dimulai ' . formatTanggalID($dataUser['tanggal_mulai']) . '.';
    }
    if (!empty($dataUser['tanggal_selesai']) && $tanggal > $dataUser['tanggal_selesai']) {
        return 'Masa magang kamu sudah berakhir ' . formatTanggalID($dataUser['tanggal_selesai']) . '.';
    }
    if (!sudahAbsenMasuk($dataUser['id'], $tanggal)) {
        return 'Kamu belum absen masuk hari ini. Log book baru bisa diisi setelah absen masuk tercatat. '
             . 'Kalau absenmu bermasalah, minta admin/pembimbing mengisikannya lewat Absen Manual.';
    }
    return null;
}

/** Catatan log book hanya boleh diubah/dihapus pada hari yang sama. */
function bolehUbahLogbook($tanggalCatatan, $hariIni = null) {
    return $tanggalCatatan === ($hariIni ?? date('Y-m-d'));
}

/**
 * Status log book satu mahasiswa untuk rentang tanggal, dihitung otomatis dari
 * absensi + izin + hari libur + isi log book (tidak disimpan sebagai data, supaya
 * selalu ikut terkoreksi kalau absen/izin diperbaiki admin).
 *
 * Status per tanggal: 'diisi', 'tidak_diisi', 'izin', 'sakit', 'tidak_hadir', 'libur'.
 * Mengembalikan ['tanggal' => ['status' => ..., 'jumlah' => n], ...]
 * beserta ringkasannya lewat rekapStatusLogbook().
 */
function statusLogbookRentang($userId, $dari, $sampai, $dataUser = null) {
    $pdo = getDB();
    $userId = (int) $userId;

    if (!$dataUser || !array_key_exists('cabang_id', $dataUser)) {
        $stmt = $pdo->prepare("SELECT id, cabang_id, tanggal_mulai, tanggal_selesai FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $dataUser = $stmt->fetch();
    }

    // Ambil semua data sekaligus (bukan query per tanggal) supaya tetap ringan.
    $stmt = $pdo->prepare("SELECT DISTINCT tanggal FROM absensi WHERE user_id=? AND jenis='masuk' AND status='valid' AND tanggal BETWEEN ? AND ?");
    $stmt->execute([$userId, $dari, $sampai]);
    $hadir = array_flip($stmt->fetchAll(PDO::FETCH_COLUMN));

    $stmt = $pdo->prepare("SELECT jenis, tanggal_mulai, tanggal_selesai FROM izin WHERE user_id=? AND status='approved' AND tanggal_mulai <= ? AND tanggal_selesai >= ?");
    $stmt->execute([$userId, $sampai, $dari]);
    $izin = $stmt->fetchAll();

    $stmt = $pdo->prepare("SELECT tanggal, COUNT(*) jumlah
                           FROM logbook WHERE user_id=? AND tanggal BETWEEN ? AND ? GROUP BY tanggal");
    $stmt->execute([$userId, $dari, $sampai]);
    $isiLogbook = [];
    foreach ($stmt->fetchAll() as $r) $isiLogbook[$r['tanggal']] = $r;

    $stmt = $pdo->prepare("SELECT tanggal, keterangan FROM hari_libur WHERE tanggal BETWEEN ? AND ?");
    $stmt->execute([$dari, $sampai]);
    $liburKhusus = [];
    foreach ($stmt->fetchAll() as $r) $liburKhusus[$r['tanggal']] = $r['keterangan'];

    // Batasi rentang ke periode magang mahasiswa & tidak melewati hari ini.
    $mulai = max($dari, $dataUser['tanggal_mulai'] ?: $dari);
    $akhir = min($sampai, date('Y-m-d'), $dataUser['tanggal_selesai'] ?: $sampai);

    $hasil = [];
    for ($tgl = $mulai; $tgl <= $akhir; $tgl = date('Y-m-d', strtotime($tgl . ' +1 day'))) {
        $hariKe = (int) date('N', strtotime($tgl));
        $jenisIzin = null;
        foreach ($izin as $iz) {
            if ($tgl >= $iz['tanggal_mulai'] && $tgl <= $iz['tanggal_selesai']) { $jenisIzin = $iz['jenis']; break; }
        }

        if (isset($isiLogbook[$tgl])) {
            $status = 'diisi';
        } elseif ($hariKe >= 6 || isset($liburKhusus[$tgl])) {
            $status = 'libur';
        } elseif ($jenisIzin) {
            $status = $jenisIzin; // 'izin' atau 'sakit'
        } elseif (isset($hadir[$tgl])) {
            $status = 'tidak_diisi';
        } elseif (!absenMasukSudahDitutup($dataUser['cabang_id'] ?? null, $tgl)) {
            // Hari ini & absen masuk masih dibuka → belum bisa disebut alpa.
            $status = 'berjalan';
        } else {
            $status = 'tidak_hadir';
        }

        $hasil[$tgl] = [
            'status' => $status,
            'keterangan' => $liburKhusus[$tgl] ?? null,
            'jumlah' => (int) ($isiLogbook[$tgl]['jumlah'] ?? 0),
        ];
    }
    return $hasil;
}

/** Ringkasan jumlah hari per status, dari hasil statusLogbookRentang(). */
function rekapStatusLogbook($statusPerTanggal) {
    $rekap = ['diisi' => 0, 'tidak_diisi' => 0, 'izin' => 0, 'sakit' => 0, 'tidak_hadir' => 0, 'libur' => 0, 'berjalan' => 0];
    foreach ($statusPerTanggal as $d) {
        if (isset($rekap[$d['status']])) $rekap[$d['status']]++;
    }
    return $rekap;
}

/** Label & warna badge untuk tiap status log book. */
function labelStatusLogbook($status) {
    return [
        'diisi'       => ['Diisi', 'success'],
        'tidak_diisi' => ['Tidak diisi', 'danger'],
        'izin'        => ['Izin', 'primary'],
        'sakit'       => ['Sakit', 'warning'],
        'tidak_hadir' => ['Tidak hadir', 'secondary'],
        'berjalan'    => ['Hari berjalan', 'info'],
        'libur'       => ['Libur', 'light'],
    ][$status] ?? ['-', 'light'];
}

/**
 * Hapus SEMUA file fisik milik seorang pengguna: foto absen, lampiran izin, dan
 * foto profil. Dipanggil SEBELUM baris users-nya dihapus, supaya tidak ada file
 * yatim yang menumpuk di server — sekaligus supaya data pribadi (foto wajah,
 * surat sakit) benar-benar ikut hilang saat akunnya dihapus.
 * Mengembalikan jumlah file yang berhasil dihapus.
 */
function hapusBerkasMilikUser($userId) {
    $pdo = getDB();
    $userId = (int) $userId;
    $jumlah = 0;

    $daftar = [];
    foreach ([
        "SELECT foto AS f FROM absensi WHERE user_id = ? AND foto IS NOT NULL",
        "SELECT file_lampiran AS f FROM izin WHERE user_id = ? AND file_lampiran IS NOT NULL",
        "SELECT foto_profil AS f FROM users WHERE id = ? AND foto_profil IS NOT NULL",
    ] as $sql) {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$userId]);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $f) $daftar[] = $f;
    }

    foreach (array_unique($daftar) as $f) {
        $path = __DIR__ . '/../uploads/' . $f;
        if (is_file($path) && @unlink($path)) $jumlah++;
    }
    return $jumlah;
}

/**
 * Hapus 1 file upload (dipakai saat entri absen/izin dihapus atau ditimpa).
 */
function hapusSatuBerkas($namaFile) {
    if (!$namaFile) return false;
    $path = __DIR__ . '/../uploads/' . $namaFile;
    return is_file($path) ? @unlink($path) : false;
}

/**
 * URL aman untuk file upload (foto absen, foto profil, lampiran izin).
 * Semua akses lewat file.php yang memeriksa hak akses dulu — folder uploads/
 * sendiri sudah ditutup lewat .htaccess.
 */
function urlFileUpload($namaFile) {
    return BASE_URL . '/file.php?f=' . rawurlencode($namaFile);
}

/**
 * Avatar/foto kecil. Kalau belum ada fotonya, digambar sendiri sebagai inisial
 * nama di dalam lingkaran (SVG) — tidak memanggil layanan gambar dari internet,
 * jadi tetap tampil walau offline.
 */
function urlAvatar($namaFile, $nama = '', $ukuran = 40) {
    if ($namaFile) {
        return urlFileUpload($namaFile);
    }
    $huruf = strtoupper(substr(trim($nama) !== '' ? trim($nama) : '?', 0, 1));
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' . (int) $ukuran . '" height="' . (int) $ukuran . '" viewBox="0 0 40 40">'
         . '<rect width="40" height="40" rx="20" fill="#dee2e6"/>'
         . '<text x="50%" y="50%" dy=".35em" text-anchor="middle" font-family="Arial,Helvetica,sans-serif"'
         . ' font-size="18" fill="#6c757d">' . htmlspecialchars($huruf, ENT_QUOTES, 'UTF-8') . '</text></svg>';
    return 'data:image/svg+xml;base64,' . base64_encode($svg);
}

/**
 * Tampilan lampiran izin/sakit (JPG/PNG/PDF) untuk halaman mahasiswa, admin, & pembimbing.
 *
 * Sebelumnya lampiran selalu dipaksa dirender sebagai <img> dan disembunyikan kalau gagal
 * dimuat — akibatnya lampiran PDF tidak pernah kelihatan sama sekali (tidak ada yang bisa
 * diklik). Sekarang: gambar ditampilkan sebagai pratinjau yang bisa diklik, file lain
 * (PDF) ditampilkan sebagai tautan. Kalau gambar gagal dimuat (mis. filenya sudah dihapus),
 * pratinjau otomatis diganti tautan, bukan disembunyikan.
 */
function htmlLampiranIzin($fileLampiran) {
    if (!$fileLampiran) return '';

    $url = e(urlFileUpload($fileLampiran));
    $ekstensi = strtolower(pathinfo($fileLampiran, PATHINFO_EXTENSION));
    $adalahGambar = in_array($ekstensi, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true);
    $labelTautan = '📎 Lihat lampiran' . ($ekstensi ? ' (' . strtoupper($ekstensi) . ')' : '');

    $tautan = '<a href="' . $url . '" target="_blank" rel="noopener" class="btn btn-outline-secondary btn-sm mt-2">'
            . $labelTautan . '</a>';

    if (!$adalahGambar) {
        return $tautan;
    }

    // Pratinjau gambar; kalau gagal dimuat, diganti tautan biasa lewat onerror.
    $idFallback = 'lampiran' . substr(md5($fileLampiran), 0, 8);
    return '<div class="mt-2">'
         . '<a href="' . $url . '" target="_blank" rel="noopener">'
         . '<img class="rounded border" style="width:100%;max-width:120px;" src="' . $url . '" alt="Lampiran"'
         . ' onerror="document.getElementById(\'' . $idFallback . '\').style.display=\'\'; this.remove();"></a>'
         . '<span id="' . $idFallback . '" style="display:none;">' . $tautan . '</span>'
         . '</div>';
}

/**
 * Validasi & rapikan input jam "HH:MM" (atau "HH:MM:SS") → "HH:MM:00". null kalau tidak valid.
 */
function normalisasiJam($jam) {
    if (!is_string($jam) || !preg_match('/^([01]\d|2[0-3]):([0-5]\d)(:[0-5]\d)?$/', trim($jam))) {
        return null;
    }
    return substr(trim($jam), 0, 5) . ':00';
}

/**
 * Validasi urutan 3 jam kerja cabang. Mengembalikan pesan error atau null kalau sudah benar.
 * Aturan: ketiganya wajib diisi, batas terlambat tidak lebih awal dari jam masuk,
 * dan jam pulang harus setelah batas terlambat.
 */
function validasiUrutanJamKerja($jamMasuk, $batasTerlambat, $jamPulang) {
    if (!$jamMasuk || !$batasTerlambat || !$jamPulang) {
        return 'Jam mulai absen masuk, batas terlambat, dan jam absen pulang wajib diisi dengan benar.';
    }
    if ($batasTerlambat < $jamMasuk) {
        return 'Batas terlambat tidak boleh lebih awal dari jam mulai absen masuk.';
    }
    if ($jamPulang <= $batasTerlambat) {
        return 'Jam absen pulang harus setelah batas terlambat.';
    }
    return null;
}

/**
 * Cek apakah tanggal (format Y-m-d) termasuk hari libur:
 * - Sabtu/Minggu otomatis, ATAU
 * - terdaftar di tabel hari_libur (libur nasional/khusus yang diatur admin).
 * Mengembalikan array ['libur' => bool, 'keterangan' => string|null].
 */
function cekHariLibur($tanggalISO) {
    $hariKe = (int) date('N', strtotime($tanggalISO));
    if ($hariKe === 6 || $hariKe === 7) {
        return ['libur' => true, 'keterangan' => 'Akhir pekan'];
    }
    $stmt = getDB()->prepare("SELECT keterangan FROM hari_libur WHERE tanggal = ? LIMIT 1");
    $stmt->execute([$tanggalISO]);
    $row = $stmt->fetch();
    if ($row) {
        return ['libur' => true, 'keterangan' => $row['keterangan']];
    }
    return ['libur' => false, 'keterangan' => null];
}

/**
 * ============================================================
 *  STATISTIK KEHADIRAN MAHASISWA (dipakai di menu Riwayat mahasiswa)
 * ============================================================
 * Mengumpulkan ringkasan: total hadir, terlambat, WFA, diisi admin, absen
 * ditolak, izin & sakit yang disetujui, serta tidak hadir — supaya mahasiswa
 * bisa lihat sekilas rekap kehadirannya sendiri tanpa harus menghitung manual
 * dari daftar riwayat yang panjang.
 *
 * "Tidak Hadir" dihitung dengan logika yang SAMA dengan yang dipakai di
 * Laporan/Export admin (includes/laporan_data.php): hari kerja (bukan
 * Sabtu/Minggu/libur) di antara tanggal_mulai magang s/d kemarin (hari ini
 * belum tentu selesai jadi tidak dihitung), yang tidak ada absen masuk sama
 * sekali dan tidak sedang izin/sakit yang disetujui. Kalau tanggal_mulai
 * belum diisi admin, dipakai tanggal akun dibuat sebagai gantinya.
 */
function ambilStatistikMahasiswa($userId) {
    $pdo = getDB();

    $stmtUser = $pdo->prepare("SELECT cabang_id, tanggal_mulai, tanggal_selesai, DATE(created_at) AS dibuat_tgl FROM users WHERE id = ?");
    $stmtUser->execute([$userId]);
    $u = $stmtUser->fetch();
    if (!$u) return null;

    // Rentang tanggal yang dihitung untuk "tidak hadir": mulai dari tanggal_mulai
    // (atau tanggal akun dibuat kalau tanggal_mulai belum diisi) sampai kemarin,
    // dipangkas kalau magangnya sudah selesai (tanggal_selesai) sebelum kemarin.
    $mulaiCek = $u['tanggal_mulai'] ?: $u['dibuat_tgl'];
    // Hari ini ikut dihitung "tidak hadir" kalau batas absen masuk (jam pulang cabang) sudah lewat.
    $akhirCek = absenMasukSudahDitutup($u['cabang_id'], date('Y-m-d'))
        ? date('Y-m-d')
        : date('Y-m-d', strtotime('-1 day'));
    if ($u['tanggal_selesai'] && $u['tanggal_selesai'] < $akhirCek) {
        $akhirCek = $u['tanggal_selesai'];
    }

    // Agregat langsung dari seluruh data absen mahasiswa ini (tidak dibatasi rentang
    // tanggal_mulai/selesai, supaya tetap akurat walau ada data absen dari sebelum
    // tanggal_mulai sempat diisi/diubah admin).
    $stmtAgg = $pdo->prepare("
        SELECT
          SUM(CASE WHEN jenis='masuk' AND status='valid' THEN 1 ELSE 0 END) AS hadir,
          SUM(CASE WHEN jenis='masuk' AND status='valid' AND terlambat=1 THEN 1 ELSE 0 END) AS terlambat,
          SUM(CASE WHEN jenis='masuk' AND status='valid' AND wfa=1 THEN 1 ELSE 0 END) AS wfa,
          SUM(CASE WHEN jenis='masuk' AND status='valid' AND diisi_admin=1 THEN 1 ELSE 0 END) AS diisi_admin,
          SUM(CASE WHEN status='ditolak' THEN 1 ELSE 0 END) AS ditolak
        FROM absensi WHERE user_id = ?
    ");
    $stmtAgg->execute([$userId]);
    $agg = $stmtAgg->fetch();

    // Izin/sakit yang sudah disetujui, dihitung per pengajuan (bukan per hari).
    $stmtIzin = $pdo->prepare("SELECT jenis, COUNT(*) c FROM izin WHERE user_id = ? AND status = 'approved' GROUP BY jenis");
    $stmtIzin->execute([$userId]);
    $izinCount = ['izin' => 0, 'sakit' => 0];
    foreach ($stmtIzin->fetchAll() as $row) {
        $izinCount[$row['jenis']] = (int) $row['c'];
    }

    // Tidak hadir: loop hari kerja dalam rentang, cek tidak ada absen masuk & tidak sedang izin disetujui.
    $tidakHadir = 0;
    if ($mulaiCek && $mulaiCek <= $akhirCek) {
        $stmtMasuk = $pdo->prepare("SELECT tanggal FROM absensi WHERE user_id = ? AND jenis = 'masuk' AND tanggal BETWEEN ? AND ?");
        $stmtMasuk->execute([$userId, $mulaiCek, $akhirCek]);
        $setMasuk = array_fill_keys(array_column($stmtMasuk->fetchAll(), 'tanggal'), true);

        $stmtIzinApproved = $pdo->prepare("SELECT tanggal_mulai, tanggal_selesai FROM izin WHERE user_id = ? AND status = 'approved' AND tanggal_mulai <= ? AND tanggal_selesai >= ?");
        $stmtIzinApproved->execute([$userId, $akhirCek, $mulaiCek]);
        $rentangIzin = $stmtIzinApproved->fetchAll();

        $tgl = $mulaiCek;
        while ($tgl <= $akhirCek) {
            $cekLibur = cekHariLibur($tgl);
            if (!$cekLibur['libur'] && !isset($setMasuk[$tgl])) {
                $sedangIzin = false;
                foreach ($rentangIzin as $r) {
                    if ($tgl >= $r['tanggal_mulai'] && $tgl <= $r['tanggal_selesai']) { $sedangIzin = true; break; }
                }
                if (!$sedangIzin) $tidakHadir++;
            }
            $tgl = date('Y-m-d', strtotime($tgl . ' +1 day'));
        }
    }

    $hadir = (int) ($agg['hadir'] ?? 0);
    $totalHariKerja = $hadir + $tidakHadir; // dipakai untuk hitung persentase kehadiran

    return [
        'hadir' => $hadir,
        'terlambat' => (int) ($agg['terlambat'] ?? 0),
        'wfa' => (int) ($agg['wfa'] ?? 0),
        'diisi_admin' => (int) ($agg['diisi_admin'] ?? 0),
        'ditolak' => (int) ($agg['ditolak'] ?? 0),
        'izin' => $izinCount['izin'],
        'sakit' => $izinCount['sakit'],
        'tidak_hadir' => $tidakHadir,
        'persentase_kehadiran' => $totalHariKerja > 0 ? round($hadir / $totalHariKerja * 100) : null,
    ];
}

/**
 * Nonaktifkan otomatis SEMUA mahasiswa yang masa magangnya sudah lewat tapi
 * statusnya masih tercatat aktif. Dipanggil tiap admin membuka halaman admin,
 * supaya daftar status di dashboard/menu Mahasiswa selalu sinkron meski
 * mahasiswa yang bersangkutan belum sempat mencoba login/absen lagi.
 */
function cekDanNonaktifkanSemuaMagangSelesai() {
    getDB()->exec("UPDATE users SET status = 'nonaktif'
                    WHERE role = 'mahasiswa' AND status = 'aktif'
                      AND tanggal_selesai IS NOT NULL AND tanggal_selesai < CURDATE()");
}

/**
 * ============================================================
 *  RETENSI FOTO ABSEN (bisa diatur per mahasiswa)
 * ============================================================
 * Foto absen (BUKAN data absensinya) dihapus otomatis X bulan setelah
 * tanggal_selesai magang, supaya folder uploads/absen tidak menumpuk foto
 * wajah mahasiswa selamanya. Data jam/status/terlambat/WFA/jarak TETAP
 * tersimpan permanen — cuma file fisik fotonya yang dihapus, dan kolom
 * "foto" di-set NULL.
 *
 * Lama retensi diambil dari users.retensi_foto_bulan (diatur admin saat
 * membuat/mengedit akun mahasiswa). Kalau NULL, dipakai nilai default di
 * menu Atur → Privasi & Storage. Nilai 0 = foto tidak pernah dihapus.
 * ============================================================
 */

/** Pilihan cepat lama retensi (bulan) di form mahasiswa. Nilai lain 0–60 tetap diterima. */
function pilihanRetensiFoto() {
    return [1, 2, 3, 6, 12];
}

/**
 * Normalisasi input retensi dari form. Mengembalikan:
 *   ['ok' => true, 'nilai' => null|int]  (null = ikuti default)
 *   ['ok' => false, 'pesan' => '...']
 */
function retensiFotoDariInput($nilai) {
    if ($nilai === null || $nilai === '') return ['ok' => true, 'nilai' => null];
    if (!is_scalar($nilai) || !ctype_digit((string) $nilai) || (int) $nilai > 60) {
        return ['ok' => false, 'pesan' => 'Retensi foto absen harus 0–60 bulan (0 = simpan selamanya), atau pilih "ikuti default".'];
    }
    return ['ok' => true, 'nilai' => (int) $nilai];
}

/** Lama retensi yang benar-benar berlaku untuk 1 mahasiswa (bulan; 0 = selamanya). */
function retensiFotoBerlaku($retensiMahasiswa) {
    if ($retensiMahasiswa !== null && $retensiMahasiswa !== '') return (int) $retensiMahasiswa;
    return (int) (ambilPengaturan()['retensi_foto_bulan'] ?? 0);
}

/** Teks singkat lama retensi, mis. "3 bulan setelah magang selesai" / "Disimpan selamanya". */
function labelRetensiFoto($bulan) {
    return (int) $bulan > 0 ? ((int) $bulan . ' bulan setelah magang selesai') : 'Disimpan selamanya';
}

/**
 * Tambah N bulan ke tanggal dengan aturan yang SAMA dengan MySQL DATE_ADD(... INTERVAL N MONTH):
 * kalau tanggalnya tidak ada di bulan tujuan, dibulatkan ke akhir bulan (31 Jan + 1 bulan = 28/29 Feb).
 * Dipakai supaya tanggal perkiraan yang tampil di layar sama persis dengan kapan foto benar-benar dihapus.
 */
function tambahBulan($tanggalISO, $bulan) {
    [$y, $m, $d] = array_map('intval', explode('-', $tanggalISO));
    $totalBulan = $y * 12 + ($m - 1) + (int) $bulan;
    $yBaru = intdiv($totalBulan, 12);
    $mBaru = $totalBulan % 12 + 1;
    $hariMaks = jumlahHariDalamBulan($mBaru, $yBaru);
    return sprintf('%04d-%02d-%02d', $yBaru, $mBaru, min($d, $hariMaks));
}

/** Jumlah hari dalam bulan tanpa bergantung ekstensi calendar (tidak selalu aktif di hosting). */
function jumlahHariDalamBulan($bulan, $tahun) {
    return (int) date('t', mktime(0, 0, 0, $bulan, 1, $tahun));
}

/**
 * Tanggal mulai foto absen seorang mahasiswa dihapus otomatis (Y-m-d), atau null kalau
 * tidak akan dihapus (retensi 0 / tanggal selesai magang belum diisi).
 */
function tanggalHapusFotoAbsen($tanggalSelesai, $retensiMahasiswa) {
    $bulan = retensiFotoBerlaku($retensiMahasiswa);
    if ($bulan <= 0 || empty($tanggalSelesai)) return null;
    return tambahBulan($tanggalSelesai, $bulan);
}

function hapusFotoAbsenKedaluwarsa() {
    // Batasi jalan maksimal 1x per hari per sesi admin, supaya tidak query +
    // scan/hapus file berulang-ulang tiap kali admin pindah halaman.
    // (Flag ini direset saat admin mengubah retensi, supaya perubahan langsung diterapkan.)
    if (($_SESSION['_terakhir_bersihkan_foto'] ?? '') === date('Y-m-d')) {
        return;
    }
    $_SESSION['_terakhir_bersihkan_foto'] = date('Y-m-d');

    $defaultBulan = (int) (ambilPengaturan()['retensi_foto_bulan'] ?? 0);

    // Retensi per mahasiswa (NULL → default). Tidak ada lagi "return" kalau default = 0,
    // karena mahasiswa tertentu bisa saja diatur retensi khusus walau defaultnya selamanya.
    $pdo = getDB();
    $stmt = $pdo->prepare("
        SELECT a.id, a.foto
        FROM absensi a
        JOIN users u ON u.id = a.user_id
        WHERE a.foto IS NOT NULL
          AND u.tanggal_selesai IS NOT NULL
          AND COALESCE(u.retensi_foto_bulan, ?) > 0
          AND DATE_ADD(u.tanggal_selesai, INTERVAL COALESCE(u.retensi_foto_bulan, ?) MONTH) <= CURDATE()
    ");
    $stmt->execute([$defaultBulan, $defaultBulan]);
    $daftarFoto = $stmt->fetchAll();
    if (!$daftarFoto) return;

    $updateNull = $pdo->prepare("UPDATE absensi SET foto = NULL WHERE id = ?");
    foreach ($daftarFoto as $row) {
        $fileFoto = __DIR__ . '/../uploads/' . $row['foto'];
        if (is_file($fileFoto)) @unlink($fileFoto);
        $updateNull->execute([$row['id']]);
    }
}

/**
 * ============================================================
 *  KATEGORI MAGANG (dikelola admin lewat menu Kategori)
 * ============================================================
 * Kategori disimpan di tabel "kategori" (bukan hardcode lagi). Tiap kategori
 * punya nama tampil + prefiks kode username (mis. PKL → PKL001) yang dipakai
 * tombol "Generate Otomatis" di form mahasiswa.
 *
 * Sengaja TIDAK di-cache statis: halaman Kategori mengubah data lalu langsung
 * menampilkan ulang daftar di request yang sama, jadi harus selalu data terbaru.
 */

/**
 * Daftar kategori: [id => nama], urut nama. Dipakai di dropdown & filter.
 */
function daftarKategori() {
    $hasil = [];
    foreach (getDB()->query("SELECT id, nama FROM kategori ORDER BY nama ASC")->fetchAll() as $row) {
        $hasil[(int) $row['id']] = $row['nama'];
    }
    return $hasil;
}

/**
 * Ambil 1 kategori lengkap (id, nama, prefiks_kode) atau null kalau tidak ada.
 */
function ambilKategori($id) {
    if (!$id) return null;
    $stmt = getDB()->prepare("SELECT * FROM kategori WHERE id = ?");
    $stmt->execute([(int) $id]);
    return $stmt->fetch() ?: null;
}

/**
 * Ubah id kategori jadi label tampil. "Belum diatur" kalau mahasiswa belum
 * punya kategori (mis. dulu berkategori Kemnaker yang sudah dihapus).
 */
function labelKategori($id) {
    if (!$id) return 'Belum diatur';
    return daftarKategori()[(int) $id] ?? 'Belum diatur';
}

/**
 * Normalisasi input filter kategori dari URL/form: kembalikan id (int) kalau
 * kategorinya ada, atau '' (= semua kategori) kalau kosong/tidak valid.
 */
function kategoriDariInput($nilai) {
    if (!is_scalar($nilai) || !ctype_digit((string) $nilai)) return '';
    $id = (int) $nilai;
    return array_key_exists($id, daftarKategori()) ? $id : '';
}

/**
 * Validasi prefiks kode username sebuah kategori. Mengembalikan pesan error atau null.
 * Aturan: 2–5 huruf A–Z saja (tanpa angka, supaya tidak rancu dengan nomor urut di
 * belakangnya — mis. prefiks "A1" + nomor 001 akan terbaca sama dengan prefiks "A" + 1001).
 */
function validasiPrefiksKategori($prefiks) {
    if (!preg_match('/^[A-Z]{2,5}$/', $prefiks)) {
        return 'Prefiks kode username wajib 2–5 huruf A–Z (tanpa angka, spasi, atau simbol), mis. PKL.';
    }
    return null;
}

/**
 * Generate kode unik login otomatis untuk kategori tertentu, format PREFIKS + nomor urut
 * 3 digit (mis. PKL001, PKL002, ...). Nomor urut dicari dari username dengan prefiks yang
 * sama yang sudah dipakai, lalu dilanjutkan dari angka terbesar (nomor lebih dari 999
 * otomatis jadi 4 digit). Mengembalikan null kalau kategorinya tidak ditemukan.
 */
function generateKodeUnik($kategoriId) {
    $kategori = ambilKategori($kategoriId);
    if (!$kategori) return null;
    $prefiks = $kategori['prefiks_kode'];

    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT identifier FROM users WHERE identifier LIKE ?");
    $stmt->execute([$prefiks . '%']);
    $maxNomor = 0;
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $id) {
        if (preg_match('/^' . preg_quote($prefiks, '/') . '(\d+)$/i', $id, $m)) {
            $maxNomor = max($maxNomor, (int)$m[1]);
        }
    }
    $nomorBaru = $maxNomor + 1;
    $kode = $prefiks . str_pad($nomorBaru, 3, '0', STR_PAD_LEFT);
    // Jaga-jaga kalau ada bentrok tak terduga
    $cekBentrok = $pdo->prepare("SELECT id FROM users WHERE identifier=?");
    while (true) {
        $cekBentrok->execute([$kode]);
        if (!$cekBentrok->fetch()) break;
        $nomorBaru++;
        $kode = $prefiks . str_pad($nomorBaru, 3, '0', STR_PAD_LEFT);
    }
    return $kode;
}

/**
 * Daftar semua cabang (lokasi absen), diurutkan berdasarkan nama.
 */
function daftarCabang() {
    return getDB()->query("SELECT * FROM cabang ORDER BY nama_cabang ASC")->fetchAll();
}

/**
 * Ambil satu data cabang berdasarkan id. Mengembalikan null kalau tidak ada/dihapus.
 */
function ambilCabang($cabangId) {
    if (!$cabangId) return null;
    $stmt = getDB()->prepare("SELECT * FROM cabang WHERE id = ?");
    $stmt->execute([$cabangId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Hitung berapa banyak mahasiswa yang terdaftar di sebuah cabang.
 * Dipakai untuk mencegah admin menghapus cabang yang masih dipakai.
 */
function jumlahMahasiswaDiCabang($cabangId) {
    $stmt = getDB()->prepare("SELECT COUNT(*) c FROM users WHERE role='mahasiswa' AND cabang_id = ?");
    $stmt->execute([$cabangId]);
    return (int) $stmt->fetch()['c'];
}

/**
 * Jumlah akun pembimbing yang ditempatkan di sebuah cabang.
 * Dipakai untuk mencegah cabang dihapus padahal masih dipakai akun pembimbing.
 */
function jumlahPembimbingDiCabang($cabangId) {
    $stmt = getDB()->prepare("SELECT COUNT(*) c FROM users WHERE role='pembimbing' AND cabang_id = ?");
    $stmt->execute([$cabangId]);
    return (int) $stmt->fetch()['c'];
}

/**
 * Jumlah mahasiswa bimbingan seorang pembimbing: ['total' => int, 'aktif' => int].
 * Dipakai untuk mencegah akun pembimbing dihapus selama masih ada mahasiswa AKTIF
 * yang memakainya (harus dialihkan ke pembimbing lain dulu).
 */
function jumlahBimbingan($pembimbingId) {
    $stmt = getDB()->prepare("SELECT COUNT(*) total, COALESCE(SUM(status='aktif'),0) aktif
                              FROM users WHERE role='mahasiswa' AND pembimbing_id = ?");
    $stmt->execute([(int) $pembimbingId]);
    $row = $stmt->fetch();
    return ['total' => (int) $row['total'], 'aktif' => (int) $row['aktif']];
}

/**
 * Ambil data cabang (lokasi) milik seorang mahasiswa, berdasarkan user_id.
 * Mengembalikan null kalau mahasiswa belum/tidak terdaftar ke cabang manapun
 * (mis. cabangnya sudah dihapus, atau akun sangat lama sebelum fitur ini ada).
 */
function ambilCabangMahasiswa($userId) {
    $stmt = getDB()->prepare("SELECT c.* FROM users u JOIN cabang c ON c.id = u.cabang_id WHERE u.id = ?");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function namaHariID($hariKe) {
    return ['', 'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu'][(int)$hariKe] ?? '-';
}

/**
 * Cek apakah tanggal selesai magang sudah lewat.
 * Kalau tanggal_selesai = 8, maka tanggal 8 masih boleh, baru tanggal 9 dianggap sudah lewat.
 */
function magangSudahSelesai($tanggalSelesai) {
    if (empty($tanggalSelesai)) return false;
    return date('Y-m-d') > $tanggalSelesai;
}

/**
 * Cek apakah masa magang mahasiswa BELUM mulai (tanggal_mulai masih di masa depan).
 * Dipakai untuk mengunci absen sebelum tanggal mulai magangnya tiba, supaya akun
 * yang sudah dibuat lebih awal dari tanggal mulai magang tidak bisa absen duluan.
 */
function magangBelumMulai($tanggalMulai) {
    if (empty($tanggalMulai)) return false;
    return date('Y-m-d') < $tanggalMulai;
}

/**
 * Cek apakah akun mahasiswa (berdasarkan user_id) sudah lewat masa magangnya.
 * Kalau iya dan statusnya masih aktif, otomatis nonaktifkan akunnya di database.
 * Mengembalikan true kalau akun ini SEKARANG nonaktif karena masa magang habis
 * (baik baru saja dinonaktifkan, maupun memang sudah nonaktif karena alasan ini sebelumnya).
 */
function cekDanNonaktifkanJikaMagangSelesai($userId) {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT id, role, status, tanggal_selesai FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $u = $stmt->fetch();
    if (!$u || $u['role'] !== 'mahasiswa' || !magangSudahSelesai($u['tanggal_selesai'])) {
        return false;
    }
    if ($u['status'] === 'aktif') {
        $upd = $pdo->prepare("UPDATE users SET status = 'nonaktif' WHERE id = ?");
        $upd->execute([$u['id']]);
    }
    return true;
}

function redirect($path) {
    header('Location: ' . BASE_URL . $path);
    exit;
}

function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Ubah data PHP menjadi nilai JavaScript yang AMAN ditaruh di dalam blok <script>.
 *
 * json_encode() biasa tidak menyandikan tanda < dan >, sehingga teks seperti
 * "</script><script>..." (mis. dari nama yang diketik pengguna) bisa menutup blok
 * script lalu menjalankan kode penyerang (XSS). Opsi JSON_HEX_* mengubah
 * < > & ' " menjadi \u003C \u003E dst, jadi teks itu tetap tampil sebagai teks biasa.
 */
function jsonUntukScript($data) {
    return json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
}

/**
 * ============================================================
 *  CSRF PROTECTION
 *  Semua form POST di aplikasi ini wajib menyertakan token ini
 *  (pakai csrfField() di dalam <form>), dan setiap handler POST
 *  wajib memanggil verifikasiCsrf() di baris paling awal sebelum
 *  memproses data apapun. Ini mencegah "Cross-Site Request
 *  Forgery" — situs lain menipu admin/mahasiswa yang sedang
 *  login supaya tanpa sadar mengirim aksi (hapus data, approve
 *  izin, dll) lewat link/gambar tersembunyi.
 * ============================================================
 */
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfField() {
    return '<input type="hidden" name="csrf_token" value="' . e(csrfToken()) . '">';
}

/**
 * Cek token CSRF dari form biasa ($_POST['csrf_token']). Kalau tidak cocok,
 * langsung hentikan request dengan pesan error (dipakai di halaman-halaman
 * yang submit lewat <form> biasa, bukan lewat fetch/AJAX JSON).
 */
function verifikasiCsrf() {
    $token = $_POST['csrf_token'] ?? '';
    if ($token === '' || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        die('Sesi tidak valid atau sudah kadaluarsa. Silakan muat ulang halaman ini lalu coba lagi.');
    }
}

/**
 * Versi untuk endpoint JSON/AJAX (mis. absen_proses.php): mengembalikan
 * true/false, bukan langsung menghentikan request, supaya pemanggilnya
 * bisa balas dengan JSON error yang rapi alih-alih halaman putih.
 */
function csrfValidApi($token) {
    return $token !== '' && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}

/**
 * ============================================================
 *  PAGINATION SEDERHANA
 * ============================================================
 */
function paginasi($totalItems, $halamanDiminta, $perHalaman) {
    $totalHalaman = max(1, (int)ceil($totalItems / $perHalaman));
    $halaman = max(1, min((int)$halamanDiminta, $totalHalaman));
    return [
        'halaman' => $halaman,
        'perHalaman' => $perHalaman,
        'offset' => ($halaman - 1) * $perHalaman,
        'totalHalaman' => $totalHalaman,
    ];
}

/**
 * Bikin URL halaman lain, sambil tetap mempertahankan semua filter (?cari=..&kategori=..)
 * yang sedang aktif di query string saat ini.
 */
function urlHalaman($halaman) {
    $q = $_GET;
    $q['halaman'] = $halaman;
    return '?' . http_build_query($q);
}

/**
 * Ubah foto absen menjadi gambar yang DITANAM LANGSUNG di halaman (data URI).
 *
 * Dipakai di laporan cetak (PDF). Sebelumnya tiap foto dimuat lewat file.php,
 * sehingga satu halaman laporan bisa memicu puluhan permintaan PHP sekaligus —
 * di hosting berbagi sebagian permintaan itu gagal/putus, dan fotonya tampil
 * sebagai ikon rusak. Dengan ditanam langsung, tidak ada permintaan tambahan
 * sama sekali, jadi fotonya pasti ikut tercetak.
 *
 * Ukurannya diperkecil dulu (thumbnail) supaya berkas laporannya tetap ringan.
 * Mengembalikan null kalau berkasnya memang tidak ada di server.
 */
function fotoDataUri($pathRelatif, $maksPiksel = 96, $kualitas = 70) {
    if (!$pathRelatif) return null;
    $path = __DIR__ . '/../uploads/' . $pathRelatif;
    if (!is_file($path)) return null;                    // berkas sudah tidak ada

    // Tanpa GD: tanam berkas aslinya apa adanya.
    if (!function_exists('imagecreatefromstring')) {
        $isi = @file_get_contents($path);
        return $isi === false ? null : 'data:image/jpeg;base64,' . base64_encode($isi);
    }

    $isi = @file_get_contents($path);
    if ($isi === false) return null;
    $asli = @imagecreatefromstring($isi);
    if (!$asli) return null;

    $lebar = imagesx($asli);
    $tinggi = imagesy($asli);
    $sisiTerpanjang = max($lebar, $tinggi);
    $skala = $sisiTerpanjang > $maksPiksel ? $maksPiksel / $sisiTerpanjang : 1;
    $lebarBaru = max(1, (int) round($lebar * $skala));
    $tinggiBaru = max(1, (int) round($tinggi * $skala));

    $kecil = imagecreatetruecolor($lebarBaru, $tinggiBaru);
    imagecopyresampled($kecil, $asli, 0, 0, 0, 0, $lebarBaru, $tinggiBaru, $lebar, $tinggi);

    ob_start();
    imagejpeg($kecil, null, $kualitas);
    $data = ob_get_clean();
    imagedestroy($asli);
    imagedestroy($kecil);

    return 'data:image/jpeg;base64,' . base64_encode($data);
}

/**
 * ============================================================
 *  PESAN SEKALI-PAKAI (FLASH)
 * ============================================================
 * Dipakai bersama pola Post/Redirect/Get: setelah data tersimpan, halaman
 * DIALIHKAN lalu pesannya ditampilkan sekali dari sini. Tanpa ini, menekan
 * Refresh akan mengirim ulang formulir sehingga notifikasi muncul lagi
 * (dan data bisa tersimpan dua kali).
 *
 * Dipakai untuk pesan yang tidak boleh lewat URL, mis. kata sandi awal yang
 * baru dibuatkan sistem.
 */
function simpanPesanSekali($pesan, $tipe = 'success') {
    $_SESSION['_pesan_sekali'] = ['pesan' => $pesan, 'tipe' => $tipe];
}

/**
 * Daftar parameter URL yang hanya dipakai untuk menampilkan notifikasi hasil
 * (mis. ?tersimpan=1). Setelah notifikasinya tampil, penanda ini dibersihkan dari
 * alamat di browser (lihat includes/dialog.php) supaya menekan Refresh tidak
 * memunculkan notifikasi yang sama lagi. Filter seperti bulan/status tidak ikut.
 */
function paramPesanUrl() {
    return [
        'tersimpan', 'ditambahkan', 'dihapus', 'terhapus', 'status_diubah', 'level_diubah',
        'diajukan', 'jenis', 'foto', 'sertifikat', 'hasil', 'sandi_diganti',
        'retensi_tersimpan', 'cabang_tersimpan', 'cabang_ditambahkan',
        'libur_ditambahkan', 'libur_dihapus', 'akses_ditolak', 'tolak',
    ];
}

/** Ambil pesan sekali-pakai lalu hapus, supaya tidak muncul lagi saat refresh. */
function ambilPesanSekali() {
    $p = $_SESSION['_pesan_sekali'] ?? null;
    unset($_SESSION['_pesan_sekali']);
    return $p;
}

/**
 * ============================================================
 *  PENGINGAT SERTIFIKAT MAGANG
 * ============================================================
 * Mengingatkan admin & pembimbing untuk menyiapkan sertifikat SEBELUM masa
 * magang mahasiswa berakhir. Setelah sertifikatnya dibuat, mahasiswa ditandai
 * supaya tidak terus muncul di daftar pengingat.
 */

/** Berapa hari sebelum masa magang berakhir pengingat mulai muncul (0 = dimatikan). */
function hariPengingatSertifikat() {
    return (int) (ambilPengaturan()['pengingat_sertifikat_hari'] ?? 14);
}

/**
 * Daftar mahasiswa yang sertifikatnya perlu disiapkan:
 * - masa magangnya berakhir dalam N hari ke depan, ATAU sudah berakhir, DAN
 * - belum ditandai "sertifikat sudah dibuat".
 * Pembimbing otomatis hanya melihat mahasiswa bimbingannya (scopeMahasiswa).
 *
 * Tiap baris memuat 'sisa_hari': 0 = berakhir hari ini, negatif = sudah lewat.
 */
function daftarPengingatSertifikat() {
    $hari = hariPengingatSertifikat();
    if ($hari <= 0) return [];   // pengingat dimatikan admin

    [$sqlScope, $paramScope] = scopeMahasiswa('u');
    $sql = "SELECT u.id, u.nama, u.identifier, u.kampus, u.tanggal_selesai, u.status,
                   DATEDIFF(u.tanggal_selesai, CURDATE()) AS sisa_hari,
                   c.nama_cabang, k.nama AS nama_kategori, p.nama AS nama_pembimbing
            FROM users u
            LEFT JOIN cabang c ON c.id = u.cabang_id
            LEFT JOIN kategori k ON k.id = u.kategori_id
            LEFT JOIN users p ON p.id = u.pembimbing_id
            WHERE u.role = 'mahasiswa'
              AND u.tanggal_selesai IS NOT NULL
              AND u.sertifikat_selesai_tgl IS NULL
              AND DATEDIFF(u.tanggal_selesai, CURDATE()) <= ?
              {$sqlScope}
            ORDER BY u.tanggal_selesai ASC, u.nama ASC";
    $stmt = getDB()->prepare($sql);
    $stmt->execute(array_merge([$hari], $paramScope));
    return $stmt->fetchAll();
}

/**
 * Tandai / batalkan tanda "sertifikat sudah dibuat" untuk seorang mahasiswa.
 * Mengembalikan pesan error, atau null kalau berhasil.
 */
function ubahStatusSertifikat($mahasiswaId, $sudahDibuat) {
    $mahasiswaId = (int) $mahasiswaId;
    if (!bolehAksesMahasiswa($mahasiswaId)) {
        return 'Mahasiswa tidak ditemukan atau bukan wewenangmu.';
    }
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT nama FROM users WHERE id = ? AND role = 'mahasiswa'");
    $stmt->execute([$mahasiswaId]);
    $nama = $stmt->fetchColumn();
    if (!$nama) return 'Mahasiswa tidak ditemukan.';

    if ($sudahDibuat) {
        $pdo->prepare("UPDATE users SET sertifikat_selesai_tgl = CURDATE(), sertifikat_oleh_id = ? WHERE id = ?")
            ->execute([$_SESSION['user_id'] ?? null, $mahasiswaId]);
        simpanArsipSertifikat($mahasiswaId);
        catatAktivitas('sertifikat', 'mahasiswa', $mahasiswaId, $nama, 'Sertifikat ditandai sudah dibuat');
    } else {
        $pdo->prepare("UPDATE users SET sertifikat_selesai_tgl = NULL, sertifikat_oleh_id = NULL WHERE id = ?")
            ->execute([$mahasiswaId]);
        $pdo->prepare("DELETE FROM arsip_sertifikat WHERE user_id = ?")->execute([$mahasiswaId]);
        catatAktivitas('sertifikat', 'mahasiswa', $mahasiswaId, $nama, 'Tanda sertifikat dibatalkan (kembali belum dibuat)');
    }
    return null;
}

/**
 * Salin data sertifikat mahasiswa ke tabel arsip.
 *
 * Arsip ini yang membuat riwayat sertifikat TETAP ADA (dan tetap muncul di rekap
 * Excel) walaupun akun mahasiswanya kelak dihapus — karena isinya salinan teks,
 * bukan sekadar rujukan ke baris users.
 */
function simpanArsipSertifikat($mahasiswaId) {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT u.id, u.pembimbing_id, u.nama, u.identifier, u.kampus,
                                  u.tanggal_mulai, u.tanggal_selesai, u.sertifikat_selesai_tgl,
                                  k.nama AS nama_kategori, c.nama_cabang,
                                  p.nama AS nama_pembimbing, s.nama AS ditandai_oleh
                           FROM users u
                           LEFT JOIN kategori k ON k.id = u.kategori_id
                           LEFT JOIN cabang c ON c.id = u.cabang_id
                           LEFT JOIN users p ON p.id = u.pembimbing_id
                           LEFT JOIN users s ON s.id = u.sertifikat_oleh_id
                           WHERE u.id = ? AND u.role = 'mahasiswa'");
    $stmt->execute([(int) $mahasiswaId]);
    $m = $stmt->fetch();
    if (!$m || !$m['sertifikat_selesai_tgl']) return;

    // Satu baris arsip per mahasiswa; kalau ditandai ulang, datanya diperbarui.
    $pdo->prepare("INSERT INTO arsip_sertifikat
            (user_id, pembimbing_id, nama, identifier, kampus, nama_kategori, nama_cabang,
             nama_pembimbing, tanggal_mulai, tanggal_selesai, sertifikat_tgl, ditandai_oleh)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
          ON DUPLICATE KEY UPDATE
             pembimbing_id = VALUES(pembimbing_id), nama = VALUES(nama), identifier = VALUES(identifier),
             kampus = VALUES(kampus), nama_kategori = VALUES(nama_kategori), nama_cabang = VALUES(nama_cabang),
             nama_pembimbing = VALUES(nama_pembimbing), tanggal_mulai = VALUES(tanggal_mulai),
             tanggal_selesai = VALUES(tanggal_selesai), sertifikat_tgl = VALUES(sertifikat_tgl),
             ditandai_oleh = VALUES(ditandai_oleh)")
        ->execute([
            $m['id'], $m['pembimbing_id'], $m['nama'], $m['identifier'], $m['kampus'],
            $m['nama_kategori'], $m['nama_cabang'], $m['nama_pembimbing'],
            $m['tanggal_mulai'], $m['tanggal_selesai'], $m['sertifikat_selesai_tgl'], $m['ditandai_oleh'],
        ]);
}

/** Teks status sertifikat untuk ditampilkan, mis. "Sudah dibuat · 20 November 2026". */
function labelStatusSertifikat($tanggalSertifikat) {
    return $tanggalSertifikat
        ? 'Sudah dibuat · ' . formatTanggalID($tanggalSertifikat)
        : 'Belum dibuat';
}

/**
 * ============================================================
 *  PENYARING BULAN (untuk daftar yang terus bertambah)
 * ============================================================
 * Halaman yang datanya menumpuk dari bulan ke bulan (riwayat absen, izin,
 * absen manual) secara bawaan hanya menampilkan BULAN BERJALAN, dengan pilihan
 * bulan untuk melihat data lama. Tidak ada data yang dihapus — hanya tampilannya
 * yang dibatasi supaya halaman tidak berat & tidak memanjang.
 */

/**
 * Periode yang sedang dipilih, dibaca dari URL: ?tahun=2026&bln=9
 * (tautan lama ?bulan=2026-09 tetap dikenali). Default: bulan berjalan.
 */
function bulanDipilih($param = 'bulan') {
    $tahun = $_GET['tahun'] ?? '';
    $bln = $_GET['bln'] ?? '';
    if (preg_match('/^\d{4}$/', (string) $tahun) && preg_match('/^\d{1,2}$/', (string) $bln)
        && (int) $bln >= 1 && (int) $bln <= 12) {
        return sprintf('%04d-%02d', (int) $tahun, (int) $bln);
    }
    $bulan = $_GET[$param] ?? '';
    return preg_match('/^\d{4}-\d{2}$/', (string) $bulan) ? $bulan : date('Y-m');
}

/**
 * Daftar tahun untuk dropdown: dari tahun data paling lama sampai TAHUN BERJALAN,
 * terbaru di atas. Karena batas atasnya dihitung dari tanggal hari ini, tahun baru
 * muncul sendiri setiap pergantian tahun tanpa perlu mengubah apa pun.
 */
function daftarTahunPilihan($tahunAwal, $tahunDipilih = null) {
    $sekarang = (int) date('Y');
    $awal = preg_match('/^\d{4}$/', (string) $tahunAwal) ? (int) $tahunAwal : $sekarang;
    if ($awal > $sekarang) $awal = $sekarang;

    $daftar = range($sekarang, $awal);                 // terbaru di atas
    if ($tahunDipilih && !in_array((int) $tahunDipilih, $daftar, true)) {
        $daftar[] = (int) $tahunDipilih;
        rsort($daftar);
    }
    return $daftar;
}

/** Tanggal awal & akhir dari sebuah bulan: ['2026-09-01', '2026-09-30'] */
function rentangBulan($bulan) {
    $awal = $bulan . '-01';
    return [$awal, date('Y-m-t', strtotime($awal))];
}

/**
 * Daftar bulan untuk dropdown: dari $bulanAwal (mis. bulan data paling lama)
 * sampai bulan ini, terbaru di atas. Bulan yang sedang dipilih selalu disertakan.
 */
function daftarBulanPilihan($bulanAwal, $bulanDipilih = null) {
    $bulanAwal = preg_match('/^\d{4}-\d{2}$/', (string) $bulanAwal) ? $bulanAwal : date('Y-m');
    if ($bulanAwal > date('Y-m')) $bulanAwal = date('Y-m');

    $daftar = [];
    for ($b = $bulanAwal; $b <= date('Y-m'); $b = date('Y-m', strtotime($b . '-01 +1 month'))) {
        $daftar[] = $b;
    }
    if ($bulanDipilih && !in_array($bulanDipilih, $daftar, true)) $daftar[] = $bulanDipilih;
    rsort($daftar);
    return $daftar;
}

/** "2026-09" → "September 2026" */
function namaBulanID($bulan) {
    $nama = ['01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April','05'=>'Mei','06'=>'Juni',
             '07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'];
    [$tahun, $bln] = array_pad(explode('-', (string) $bulan), 2, '');
    return ($nama[$bln] ?? $bln) . ' ' . $tahun;
}

/**
 * Potongan HTML dropdown bulan (dipakai di dalam <form method="GET">).
 * Otomatis terkirim saat dipilih, jadi tidak perlu tombol terpisah.
 */
function dropdownBulan($daftarTahun, $dipilih, $label = 'Tampilkan') {
    // Dua kotak terpisah: Tahun & Bulan. Bulan SELALU Januari–Desember, walaupun
    // bulan itu belum ada datanya — halaman tinggal menampilkan keterangan kosong.
    // Daftar tahun dibuat oleh daftarTahunPilihan() dan bertambah otomatis tiap tahun baru.
    $tahunDipilih = (int) substr($dipilih, 0, 4);
    $blnDipilih = (int) substr($dipilih, 5, 2);

    $html = '<div class="row g-2">'
          . '<div class="col-6"><label class="form-label small">' . e($label === 'Tampilkan' ? 'Tahun' : $label . ' (tahun)') . '</label>'
          . '<select name="tahun" class="form-select form-select-sm" onchange="this.form.submit()">';
    foreach ($daftarTahun as $t) {
        $html .= '<option value="' . (int) $t . '"' . ((int) $t === $tahunDipilih ? ' selected' : '') . '>' . (int) $t . '</option>';
    }
    $html .= '</select></div>'
          . '<div class="col-6"><label class="form-label small">Bulan</label>'
          . '<select name="bln" class="form-select form-select-sm" onchange="this.form.submit()">';
    for ($m = 1; $m <= 12; $m++) {
        $html .= '<option value="' . $m . '"' . ($m === $blnDipilih ? ' selected' : '') . '>'
               . e(namaBulanSaja($m)) . '</option>';
    }
    return $html . '</select></div></div>';
}

/** Nama bulan tanpa tahun: 9 → "September" */
function namaBulanSaja($nomor) {
    $nama = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    return $nama[(int) $nomor] ?? (string) $nomor;
}

/**
 * ============================================================
 *  KEAMANAN PASSWORD
 * ============================================================
 */

/**
 * Buat password acak yang aman (bukan string tetap seperti "magang123"),
 * dipakai sebagai password awal/reset default kalau admin mengosongkan
 * kolomnya. Campuran huruf besar, huruf kecil, dan angka — karakter yang
 * gampang tertukar (0/O, 1/l/I) sengaja tidak dipakai supaya lebih mudah
 * diketik ulang manual oleh mahasiswa.
 */
function bikinPasswordAcak($panjang = 12) {
    // Huruf/angka yang mudah tertukar (I, l, O, 0, 1) sengaja tidak dipakai supaya
    // password hasil generate tidak salah ketik saat dicatat/dibacakan admin.
    $besar = 'ABCDEFGHJKMNPQRSTUVWXYZ';
    $kecil = 'abcdefghjkmnpqrstuvwxyz';
    $angka = '23456789';
    $simbol = '!@#$%*?-+';
    $semua = $besar . $kecil . $angka . $simbol;

    if ($panjang < 8) $panjang = 8;

    // Pastikan keempat jenis karakter selalu ada (sesuai validasiKekuatanPassword).
    $karakter = [
        $besar[random_int(0, strlen($besar) - 1)],
        $kecil[random_int(0, strlen($kecil) - 1)],
        $angka[random_int(0, strlen($angka) - 1)],
        $simbol[random_int(0, strlen($simbol) - 1)],
    ];
    for ($i = count($karakter); $i < $panjang; $i++) {
        $karakter[] = $semua[random_int(0, strlen($semua) - 1)];
    }

    // Acak urutannya supaya posisi tiap jenis karakter tidak selalu sama.
    for ($i = count($karakter) - 1; $i > 0; $i--) {
        $j = random_int(0, $i);
        [$karakter[$i], $karakter[$j]] = [$karakter[$j], $karakter[$i]];
    }
    return implode('', $karakter);
}

/**
 * Validasi kekuatan minimal sebuah password. Mengembalikan pesan error
 * (string) kalau tidak memenuhi syarat, atau null kalau sudah oke.
 * Aturan: minimal 8 karakter DAN memuat keempat jenis karakter — huruf besar,
 * huruf kecil, angka, serta simbol — supaya tidak semudah "12345678" atau "mahasiswa1"
 * atau "password" saja.
 */
function validasiKekuatanPassword($password, $minPanjang = 8) {
    if (!is_string($password) || strlen($password) < $minPanjang) {
        return "Kata sandi minimal $minPanjang karakter.";
    }

    $kurang = [];
    if (!preg_match('/[A-Z]/', $password))        $kurang[] = 'huruf besar (A-Z)';
    if (!preg_match('/[a-z]/', $password))        $kurang[] = 'huruf kecil (a-z)';
    if (!preg_match('/[0-9]/', $password))        $kurang[] = 'angka (0-9)';
    if (!preg_match('/[^A-Za-z0-9]/', $password)) $kurang[] = 'simbol (mis. ! @ # $ %)';

    if ($kurang) {
        return 'Kata sandi harus memuat ' . implode(', ', $kurang) . '.';
    }
    return null;
}

/** Teks syarat kata sandi, dipakai di semua form supaya keterangannya seragam. */
function syaratPasswordTeks($minPanjang = 8) {
    return "Minimal $minPanjang karakter, memuat huruf besar, huruf kecil, angka, dan simbol.";
}

/**
 * ============================================================
 *  RATE LIMITING LOGIN (anti brute-force tebak password)
 * ============================================================
 */
function ipSekarang() {
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

/**
 * Cek apakah identifier (NIM/username) ATAU alamat IP ini sedang diblokir
 * sementara karena terlalu banyak percobaan login gagal beruntun.
 * Mengembalikan jumlah menit sisa blokir (0 kalau tidak diblokir).
 */
/**
 * Batas percobaan login dipisah jadi DUA hitungan, supaya satu orang yang lupa
 * password tidak mengunci seluruh kantor (di WiFi bersama, semua pengguna
 * keluar dengan 1 IP publik yang sama):
 *
 * - Per USERNAME : 5 kali gagal / 15 menit → akun itu saja yang diblokir sementara.
 *                  Ini yang menahan penebakan password sebuah akun.
 * - Per IP       : 20 kali gagal / 15 menit → jauh lebih longgar, hanya untuk
 *                  menahan percobaan bertubi-tubi dari satu mesin.
 */
const LOGIN_MAKS_GAGAL_USERNAME = 5;
const LOGIN_MAKS_GAGAL_IP = 20;
const LOGIN_MENIT_BLOKIR = 15;

/**
 * Cek apakah login sedang diblokir. Mengembalikan:
 *   ['menit' => 0]  → tidak diblokir
 *   ['menit' => n, 'jenis' => 'username'|'ip'] → diblokir n menit lagi
 */
function statusBlokirLogin($identifier) {
    $pdo = getDB();
    $batasWaktu = date('Y-m-d H:i:s', strtotime('-' . LOGIN_MENIT_BLOKIR . ' minutes'));

    $hitung = function ($kolom, $nilai) use ($pdo, $batasWaktu) {
        $stmt = $pdo->prepare("SELECT COUNT(*) c, MAX(waktu) w FROM login_attempts WHERE $kolom = ? AND waktu > ?");
        $stmt->execute([$nilai, $batasWaktu]);
        return $stmt->fetch();
    };

    $perUsername = $identifier !== '' ? $hitung('identifier', $identifier) : ['c' => 0, 'w' => null];
    $perIp = $hitung('ip_address', ipSekarang());

    $sisaMenit = function ($waktuTerbaru) {
        $sisa = (int) ceil((strtotime('+' . LOGIN_MENIT_BLOKIR . ' minutes', strtotime($waktuTerbaru)) - time()) / 60);
        return max(1, $sisa);
    };

    if ((int) $perUsername['c'] >= LOGIN_MAKS_GAGAL_USERNAME) {
        return ['menit' => $sisaMenit($perUsername['w']), 'jenis' => 'username'];
    }
    if ((int) $perIp['c'] >= LOGIN_MAKS_GAGAL_IP) {
        return ['menit' => $sisaMenit($perIp['w']), 'jenis' => 'ip'];
    }
    return ['menit' => 0, 'jenis' => null];
}

/** Versi ringkas: sisa menit blokir (0 = tidak diblokir). */
function cekBlokirLogin($identifier) {
    return statusBlokirLogin($identifier)['menit'];
}

function catatLoginGagal($identifier) {
    $pdo = getDB();
    $pdo->prepare("INSERT INTO login_attempts (identifier, ip_address) VALUES (?, ?)")->execute([$identifier, ipSekarang()]);
    // Sekalian bersihkan catatan lama supaya tabel tidak membengkak terus-menerus.
    $pdo->exec("DELETE FROM login_attempts WHERE waktu < DATE_SUB(NOW(), INTERVAL 1 DAY)");
}

/**
 * Dipanggil setelah login BERHASIL. Sengaja hanya menghapus catatan gagal milik
 * username itu — TIDAK menghapus catatan milik IP-nya. Kalau catatan seluruh IP
 * ikut dihapus, orang yang punya akun sendiri bisa memakai login suksesnya untuk
 * mereset hitungan, lalu melanjutkan menebak password akun orang lain tanpa batas.
 */
function hapusCatatanLoginGagal($identifier) {
    getDB()->prepare("DELETE FROM login_attempts WHERE identifier = ?")->execute([$identifier]);
}


/**
 * ============================================================
 *  ROLE & HAK AKSES (admin, pembimbing, mahasiswa)
 * ============================================================
 * - admin      : kendali penuh atas semua data & pengaturan.
 * - pembimbing : dashboard, izin/sakit, absen manual, laporan — tapi HANYA
 *                untuk mahasiswa bimbingannya sendiri (users.pembimbing_id).
 * - mahasiswa  : absen, riwayat, izin, profil miliknya sendiri.
 *
 * Semua pembatasan data untuk pembimbing WAJIB lewat helper di bawah ini,
 * supaya aturannya ada di satu tempat dan tidak ada halaman yang lupa
 * memfilter (mis. pembimbing mengganti ?user_id= di URL untuk mengintip
 * mahasiswa bimbingan orang lain).
 */
function daftarRole() {
    return [
        'admin' => 'Admin',
        'pembimbing' => 'Pembimbing',
        'mahasiswa' => 'Mahasiswa',
    ];
}

function labelRole($role) {
    return daftarRole()[$role] ?? '-';
}

function roleSekarang() {
    return $_SESSION['user_role'] ?? null;
}

function isAdmin() {
    return roleSekarang() === 'admin';
}

/**
 * Super admin = satu-satunya yang boleh MENGELOLA AKUN ADMIN (menambah, menghapus,
 * mereset kata sandi admin, serta mengangkat/menurunkan super admin lain).
 * Selain itu kewenangannya sama dengan admin biasa: mahasiswa, pembimbing,
 * kategori, divisi, izin, absen manual, laporan, log book, pengaturan sistem,
 * Riwayat Aktivitas, dan hapus akun mahasiswa.
 */
function isSuperAdmin() {
    return isAdmin() && (int) ($_SESSION['user_super_admin'] ?? 0) === 1;
}




/**
 * Pagar halaman khusus super admin. Admin biasa dikembalikan ke dashboard
 * dengan penjelasan — dijaga di server, bukan sekadar menu yang disembunyikan.
 */
function requireSuperAdmin() {
    requireLogin('admin');
    if (!isSuperAdmin()) {
        redirect('/admin/dashboard.php?akses_ditolak=1');
    }
}

/** Jumlah super admin yang masih aktif (dipakai untuk mencegah aplikasi terkunci). */
function jumlahSuperAdminAktif() {
    return (int) getDB()->query("SELECT COUNT(*) FROM users WHERE role='admin' AND super_admin=1 AND status='aktif'")->fetchColumn();
}

function isPembimbing() {
    return roleSekarang() === 'pembimbing';
}

/**
 * Folder panel sesuai role yang sedang login: '/admin', '/pembimbing', atau '/mahasiswa'.
 * Dipakai untuk redirect & link navigasi supaya pembimbing selalu berada di URL /pembimbing/...
 */
function panelBase($role = null) {
    $role = $role ?? roleSekarang();
    return match ($role) {
        'admin' => '/admin',
        'pembimbing' => '/pembimbing',
        default => '/mahasiswa',
    };
}

/**
 * Halaman awal setelah login untuk tiap role.
 */
function berandaRole($role = null) {
    $role = $role ?? roleSekarang();
    return match ($role) {
        'admin' => '/admin/dashboard.php',
        'pembimbing' => '/pembimbing/dashboard.php',
        default => '/mahasiswa/absen.php',
    };
}

/**
 * Potongan SQL untuk membatasi data mahasiswa sesuai role yang sedang login.
 * $kolomUser adalah kolom/alias tabel users milik MAHASISWA di query pemanggil
 * (mis. 'u' untuk "users u").
 *
 * - admin      → tidak ada batasan (string kosong).
 * - pembimbing → " AND u.pembimbing_id = ?" + id pembimbing yang login.
 *
 * Contoh:
 *   [$sqlScope, $paramScope] = scopeMahasiswa('u');
 *   $sql .= $sqlScope; $params = array_merge($params, $paramScope);
 */
function scopeMahasiswa($aliasUser = 'u') {
    if (isPembimbing()) {
        $kolom = $aliasUser !== '' ? "$aliasUser.pembimbing_id" : 'pembimbing_id';
        return [" AND $kolom = ?", [(int) $_SESSION['user_id']]];
    }
    return ['', []];
}

/**
 * Id pembimbing yang harus dipakai sebagai filter wajib (null untuk admin).
 */
function idPembimbingScope() {
    return isPembimbing() ? (int) $_SESSION['user_id'] : null;
}

/**
 * Cek apakah user yang sedang login boleh mengakses data 1 mahasiswa tertentu.
 * Admin: semua mahasiswa. Pembimbing: hanya mahasiswa bimbingannya.
 */
function bolehAksesMahasiswa($mahasiswaId) {
    if (!$mahasiswaId) return false;
    [$sqlScope, $paramScope] = scopeMahasiswa('u');
    $stmt = getDB()->prepare("SELECT 1 FROM users u WHERE u.id = ? AND u.role = 'mahasiswa'" . $sqlScope);
    $stmt->execute(array_merge([(int) $mahasiswaId], $paramScope));
    return (bool) $stmt->fetchColumn();
}

/**
 * Daftar akun pembimbing (untuk dropdown admin saat mengatur mahasiswa).
 * $hanyaAktif = true → cuma yang statusnya aktif.
 */
function daftarPembimbing($hanyaAktif = false) {
    $sql = "SELECT u.id, u.nama, u.identifier, u.no_hp, u.status, u.divisi_id, u.cabang_id,
                   d.nama AS nama_divisi, c.nama_cabang
            FROM users u
            LEFT JOIN divisi d ON d.id = u.divisi_id
            LEFT JOIN cabang c ON c.id = u.cabang_id
            WHERE u.role = 'pembimbing'";
    if ($hanyaAktif) $sql .= " AND u.status = 'aktif'";
    $sql .= " ORDER BY u.nama ASC";
    return getDB()->query($sql)->fetchAll();
}

/**
 * ============================================================
 *  DIVISI / BAGIAN (dikelola admin lewat menu Kelola Divisi)
 * ============================================================
 * Dipakai saat membuat/mengedit akun pembimbing: tiap pembimbing bertugas di
 * 1 divisi. Tidak di-cache statis, supaya halaman Kelola Divisi yang mengubah
 * data lalu menampilkan ulang daftarnya selalu memakai data terbaru.
 */

/**
 * Daftar divisi: [id => nama], urut nama. Dipakai di dropdown & filter.
 */
function daftarDivisi() {
    $hasil = [];
    foreach (getDB()->query("SELECT id, nama FROM divisi ORDER BY nama ASC")->fetchAll() as $row) {
        $hasil[(int) $row['id']] = $row['nama'];
    }
    return $hasil;
}

/**
 * Ambil 1 divisi lengkap (id, nama, keterangan) atau null kalau tidak ada.
 */
function ambilDivisi($id) {
    if (!$id) return null;
    $stmt = getDB()->prepare("SELECT * FROM divisi WHERE id = ?");
    $stmt->execute([(int) $id]);
    return $stmt->fetch() ?: null;
}

/**
 * Ubah id divisi jadi label tampil. "Belum diatur" kalau pembimbing belum punya divisi.
 */
function labelDivisi($id) {
    if (!$id) return 'Belum diatur';
    return daftarDivisi()[(int) $id] ?? 'Belum diatur';
}

/**
 * Normalisasi input divisi dari URL/form: id (int) kalau divisinya ada,
 * atau '' kalau kosong/tidak valid.
 */
function divisiDariInput($nilai) {
    if (!is_scalar($nilai) || !ctype_digit((string) $nilai)) return '';
    $id = (int) $nilai;
    return array_key_exists($id, daftarDivisi()) ? $id : '';
}

/**
 * Ambil data 1 akun pembimbing berdasarkan id (null kalau tidak ada / bukan pembimbing).
 */
function ambilPembimbing($id) {
    if (!$id) return null;
    $stmt = getDB()->prepare("SELECT u.id, u.nama, u.identifier, u.no_hp, u.status, u.divisi_id, u.cabang_id,
                                     d.nama AS nama_divisi, c.nama_cabang
                              FROM users u
                              LEFT JOIN divisi d ON d.id = u.divisi_id
                              LEFT JOIN cabang c ON c.id = u.cabang_id
                              WHERE u.id = ? AND u.role = 'pembimbing'");
    $stmt->execute([(int) $id]);
    return $stmt->fetch() ?: null;
}
