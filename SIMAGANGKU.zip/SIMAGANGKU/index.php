<?php
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    redirect(berandaRole());
}
redirect('/login.php' . (!empty($GLOBALS['_sesi_dicabut']) ? '?dicabut=1' : ''));
