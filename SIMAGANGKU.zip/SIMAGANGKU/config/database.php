<?php
/**
 * Koneksi database (PDO).
 * Sesuaikan DB_USER / DB_PASS jika XAMPP kamu bukan default (root, tanpa password).
 */

// Zona waktu WITA (Makassar & sekitarnya, UTC+8). Wajib diatur di sini karena
// PHP defaultnya UTC — tanpa ini, jam absen & status terlambat bisa salah 8 jam.
date_default_timezone_set('Asia/Makassar');

// ============================================================
//  ISI BAGIAN INI SESUAI DATA DARI PANEL HOSTING
// ============================================================
// Keempat nilai database didapat saat membuat database & user di
// cPanel → "MySQL Databases". Nama database & user di hosting biasanya
// berawalan nama akun, contoh: bpjsmks_absensi dan bpjsmks_admin.
define('DB_HOST', 'localhost');
define('DB_NAME', 'sims7973_absensi');
define('DB_USER', 'sims7973_admin');        // ganti sesuai Privileged Users
define('DB_PASS', 'ji3n-z5Jatee7-n;');

// BASE_URL adalah JALUR FOLDER aplikasi, BUKAN alamat lengkap (jangan diisi https://...).
//  - Aplikasi ditaruh langsung di public_html / di subdomain  → isi ''   (kosong, bawaan)
//  - Aplikasi ditaruh di subfolder, mis. public_html/absensi   → isi '/absensi'
define('BASE_URL', '');
// ============================================================

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
            // Samakan timezone koneksi MySQL dengan WITA (+08:00), supaya NOW()/CURRENT_TIMESTAMP
            // di database juga konsisten dengan jam yang dipakai PHP.
            $pdo->exec("SET time_zone = '+08:00'");
        } catch (PDOException $e) {
            // Jangan tampilkan detail exception mentah (bisa membocorkan info host/kredensial
            // ke publik kalau ini kejadian di server production). Detail lengkapnya dicatat
            // ke error log server PHP saja, yang cuma bisa dibaca admin/hosting.
            error_log('Koneksi database gagal: ' . $e->getMessage());
            die('Koneksi database gagal. Pastikan MySQL sudah menyala dan database "absensi_magang" sudah diimport. Kalau ini terjadi di server production, cek error log server untuk detailnya.');
        }
    }
    return $pdo;
}
