<?php
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    redirect(berandaRole());
}

$pengaturan = ambilPengaturan();

$error = '';
$identifierLama = '';

if (isset($_GET['selesai'])) {
    $error = 'Masa magang kamu sudah berakhir, akun otomatis dinonaktifkan. Hubungi admin kalau ada pertanyaan.';
} elseif (isset($_GET['kedaluwarsa']) || !empty($GLOBALS['_sesi_kedaluwarsa'])) {
    $error = 'Kamu otomatis keluar karena tidak ada aktivitas selama ' . MENIT_SESI_MENGANGGUR . ' menit. Silakan login lagi.';
} elseif (isset($_GET['dicabut']) || !empty($GLOBALS['_sesi_dicabut'])) {
    $error = 'Sesi kamu berakhir karena akun dinonaktifkan atau diubah oleh admin. Silakan login ulang atau hubungi admin.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifikasiCsrf();

    $identifier = trim($_POST['identifier'] ?? '');
    $password = $_POST['password'] ?? '';
    $identifierLama = $identifier;

    $blokir = statusBlokirLogin($identifier);
    $sisaMenitBlokir = $blokir['menit'];

    if ($sisaMenitBlokir > 0) {
        // Pesannya dibedakan supaya mahasiswa tidak bingung saat yang kena adalah
        // batas per jaringan (mis. banyak orang salah password di WiFi yang sama).
        $error = $blokir['jenis'] === 'ip'
            ? "Terlalu banyak percobaan login gagal dari jaringan ini. Coba lagi dalam sekitar $sisaMenitBlokir menit, atau hubungi admin."
            : "Terlalu banyak percobaan login gagal untuk akun ini. Coba lagi dalam sekitar $sisaMenitBlokir menit.";
        catatAktivitas('login_diblokir', 'login', null, $identifier !== '' ? $identifier : null,
            'Blokir sementara per ' . ($blokir['jenis'] === 'ip' ? 'jaringan/IP' : 'username') . ", sisa $sisaMenitBlokir menit");
    } elseif ($identifier === '' || $password === '') {
        $error = 'Mohon isi semua kolom terlebih dahulu.';
    } else {
        // Cukup cari berdasarkan identifier saja (username mahasiswa / username admin),
        // karena kolom ini sudah dijamin unik untuk SELURUH tabel users lewat
        // constraint UNIQUE di database — jadi tidak mungkin ada username mahasiswa
        // yang sama persis dengan username admin manapun. Role akun ditentukan
        // otomatis dari data yang ditemukan, bukan dari pilihan di form.
        $stmt = getDB()->prepare("SELECT * FROM users WHERE identifier = ? LIMIT 1");
        $stmt->execute([$identifier]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            catatLoginGagal($identifier);
            $error = 'Username atau kata sandi salah.';
        } else {
            hapusCatatanLoginGagal($identifier);
            $role = $user['role'];

            // Kalau mahasiswa dan masa magangnya sudah lewat, nonaktifkan otomatis sebelum cek status.
            if ($role === 'mahasiswa' && cekDanNonaktifkanJikaMagangSelesai($user['id'])) {
                $user['status'] = 'nonaktif';
            }

            if ($user['status'] !== 'aktif') {
                $error = 'Akun kamu sudah tidak aktif. Hubungi admin.';
            } else {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_nama'] = $user['nama'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['user_identifier'] = $user['identifier'];
                $_SESSION['harus_ganti_password'] = (int) $user['harus_ganti_password'];
                redirect(berandaRole($role));
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<title>Masuk — <?= !empty($pengaturan['nama_instansi']) ? e($pengaturan['nama_instansi']) : 'Absensi Magang' ?></title>
<?php
// Satu-satunya halaman yang boleh muncul di hasil pencarian (lihat includes/head.php).
$halamanPublik = true;
$deskripsiHalaman = 'Aplikasi absensi & log book magang' . (!empty($pengaturan['nama_instansi']) ? ' ' . $pengaturan['nama_instansi'] : '')
                  . '. Absen dengan foto dan lokasi, isi log book harian, ajukan izin/sakit, dan unduh laporan.';
?>
<?php include __DIR__ . '/includes/head.php'; ?>
</head>
<body>
<div class="container">
  <div class="row justify-content-center min-vh-100 align-items-center">
    <div class="col-12 col-sm-8 col-md-5 col-lg-4">
      <div class="card shadow-sm">
        <div class="card-body p-4">
          <div class="text-center mb-4">
            <img src="assets/img/logo-bpjs-kesehatan.png" alt="Logo BPJS Kesehatan Makassar" style="width:64px;height:64px;object-fit:contain;" class="mb-2">
            <p class="text-primary fw-semibold small mb-1">Sistem Absensi Magang</p>
            <h1 class="h4 fw-bold mb-1"><?= !empty($pengaturan['nama_instansi']) ? e($pengaturan['nama_instansi']) : 'Absensi Magang' ?></h1>
            <p class="text-muted small mb-0">Masuk pakai username masing-masing (mahasiswa/pembimbing/admin).</p>
          </div>

          <form method="POST" action="login.php">
            <?= csrfField() ?>
            <div class="mb-3">
              <label class="form-label">Username</label>
              <input type="text" name="identifier" class="form-control" value="<?= e($identifierLama) ?>" placeholder="Username kamu" required autofocus>
            </div>
            <div class="mb-3">
              <label class="form-label">Kata sandi</label>
              <input type="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>

            <?php if ($error): ?>
              <div class="alert alert-danger py-2 small"><?= e($error) ?></div>
            <?php endif; ?>

            <button type="submit" class="btn btn-primary w-100">Masuk</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/foot.php'; ?>
</body>
</html>
